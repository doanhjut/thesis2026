# Kết quả bổ sung và phạm vi kết luận

**Hai pilot AL và fidelity đã chạy thực, huấn luyện mô hình mới và lưu dữ liệu truy vết.** Chúng bổ sung bằng chứng thăm dò; không xác nhận hồi tố Bảng 4.5–4.9 của luận văn. Các bảng cũ còn thiếu liên kết đầy đủ với phép đo gốc, có script xuất số liệu hardcode và có khác biệt công thức–triển khai. Đánh giá chi tiết ở [Danh_gia_bang_chung.md](Danh_gia_bang_chung.md).

Nguồn đầu vào là CSV có sẵn gồm 2.000 dòng, 2.381 đặc trưng, 1.500 nhãn âm và 500 nhãn dương. Nguồn upstream, thời gian, họ mã độc và ý nghĩa ransomware-specific của nhãn 1 chưa được xác minh. Vì vậy, đây là **pilot nội bộ trên dữ liệu cục bộ**, chưa phải benchmark ransomware/zero-day đã xác minh. Không phát hiện vector trùng hoàn toàn; chưa loại trừ near-duplicate.

## 1. AL: cải thiện khả năng xếp hạng ở cùng ngân sách

Split cố định: 1.200 train/pool, 400 validation, 400 test (300 âm, 100 dương). Năm seed ghép cặp 11/22/33/44/55; mỗi seed có cùng 200 nhãn khởi tạo cho mọi phương pháp, rồi truy vấn 5 × 100, kết thúc ở **700 nhãn huấn luyện**. Có thêm 400 nhãn validation; ngân sách 700 không bao gồm nguồn lực này. Mỗi checkpoint huấn luyện LightGBM mới với 60 cây, độ sâu tối đa 4.

U là bất định theo xác suất; H là entropy theo khối lượng SHAP trái dấu; V là phương sai SHAP có dấu. Pilot dùng TreeSHAP thật từ mô hình hiện tại, kiểm tra tính cộng, không có fallback mô phỏng. Trọng số đầy đủ U/H/V = 0,3/0,4/0,3. Ngưỡng lấy từ validation nhằm TPR ≥95%, rồi khóa khi đánh giá test; TPR test được đo, không giả định bằng95%.

| Phương pháp | ROC-AUC | Average precision | FPR (%) | TPR (%) |
|---|---:|---:|---:|---:|
| Random | 0,9634 ± 0,0063 | 0,9194 ± 0,0115 | 21,73 ± 4,59 | 93,80 ± 2,28 |
| Uncertainty | 0,9691 ± 0,0046 | 0,9363 ± 0,0076 | 19,87 ± 4,65 | 95,60 ± 1,14 |
| U+H | 0,9676 ± 0,0031 | 0,9371 ± 0,0015 | 17,20 ± 5,15 | 93,00 ± 2,35 |
| U+V | 0,9692 ± 0,0062 | 0,9392 ± 0,0073 | 28,33 ± 7,23 | 96,40 ± 3,05 |
| XAI đầy đủ | **0,9749 ± 0,0040** | **0,9442 ± 0,0057** | 17,53 ± 4,85 | 95,40 ± 1,52 |

Số ± là **độ lệch chuẩn mẫu giữa năm seed**, không phải khoảng tin cậy quần thể. Các seed cùng một test; không phải năm bộ dữ liệu độc lập. AP là average precision, không thay bằng một định nghĩa diện tích PR khác khi báo cáo.

**So sánh ghép cặp XAI đầy đủ với uncertainty:** AUC tăng trung bình **0,005787**, cao hơn ở **5/5 seed**; AP tăng **0,007915**, cũng cao hơn ở 5/5 seed. FPR giảm trung bình **2,333 điểm phần trăm**, nhưng chỉ thấp hơn ở **2/5 seed**; độ lệch chuẩn chênh lệch FPR là 6,617 điểm. TPR trung bình giảm0,20 điểm. U+H có FPR trung bình thấp hơn XAI đầy đủ nhưng TPR cũng thấp hơn; không chọn riêng cột FPR để tuyên bố thắng.

**Kết luận đủ sức bảo vệ:** “Trong pilot này, phối hợp U/H/V cải thiện ROC-AUC và AP tại cùng ngân sách so với uncertainty. Kết quả chưa cho thấy giảm FPR ổn định và chưa chứng minh tiết kiệm thời gian gán nhãn.” Không suy ra từng thành phần riêng lẻ đều có ích hoặc sự cộng hưởng phổ quát từ một cấu hình đầy đủ đứng đầu.

Thời gian chấm điểm của XAI đầy đủ trung bình0,158 giây cho năm vòng, uncertainty0,0135 giây; số đo gồm dự đoán pool, TreeSHAP, kiểm tra tính cộng và chuẩn hóa, **không gồm** sắp xếp, chuyên gia gán nhãn, huấn luyện và lưu trữ. Đây là chi phí pilot trên máy hiện tại, không phải overhead endpoint/SOC.

## 2. Fidelity: SHAP nhạy hơn random dưới phép thử masking

Pilot này huấn luyện model riêng: 100 cây, train1.200 dòng, seed42. Test ROC-AUC = **0,980167**, AP = **0,955338**. Không so AUC này trực tiếp với AL để suy ra đóng góp, vì ngân sách nhãn và mô hình khác nhau. TreeSHAP giải thích raw score/log-odds; sai số kiểm tra tổng SHAP cộng intercept tối đa7,11×10⁻¹⁵.

Top-k được chọn theo trị tuyệt đối SHAP và thay bằng trung bình **chỉ từ train**. Random chọn cùng k chiều cho từng mẫu, lặp20 lần. Ở **k=25**:

| Phép thử | AUC sau che | AUC giảm |
|---|---:|---:|
| Top-25 SHAP | **0,818533** | **0,161633** |
| Random-25, trung bình20 lần | 0,979910 | 0,000257 |

Khoảng percentile95% của AUC drop top-SHAP qua500 lần paired stratified bootstrap test là **[0,122232; 0,207752]**. Đây là bất định có điều kiện trên một model đã fit; không đo biến động huấn luyện. Random SD qua các mask là một đại lượng khác. Cùng k nghĩa là cùng số chiều được chọn, chưa bảo đảm số tọa độ thực sự thay đổi hoặc độ lớn perturbation bằng nhau.

- **FF thô theo công thức PDF = 2,004518 ở k=25**, vượt1: mẫu số xác suất gốc nhỏ có thể khuếch đại tỷ số. Không tự cắt điểm để trình bày đẹp; cần công khai quy tắc chuẩn hóa trước tổng hợp.
- **EC = 0,304373:** tương quan Pearson giữa cấu trúc tương đồng đặc trưng và SHAP qua hai ma trận cosine; không phải ổn định trước nhiễu. 79.800 cặp chia sẻ mẫu, nên không báo p-value coi chúng độc lập.
- **CF = 0,587352:** khoảng cách hai tâm SHAP chuẩn hóa theo chuẩn SHAP lớn nhất. Đây là mức phân tách lớp trong không gian giải thích, không là chứng minh nhân quả.
- **Không xuất OFS:** định nghĩa PDF và code cũ chưa thống nhất. Các phép đo thành phần và masking đủ để trình bày kết quả pilot mà không tạo điểm tổng hợp thiếu cơ sở.

**Kết luận đủ sức bảo vệ:** “Dưới phép thử masking đã công bố, SHAP xếp cao các đặc trưng ảnh hưởng đến dự đoán của mô hình hơn lựa chọn ngẫu nhiên cùng k.” Chưa khẳng định vector sau che tương ứng PE hợp lệ, giải thích hoàn toàn trung thực hay phản ánh nguyên nhân hành vi ransomware.

## 3. Phần còn cần đo tối thiểu

1. **PID:** lấy hai tín hiệu tĩnh–động thực trên cùng mẫu có nhãn, cùng cổng và cùng chính sách ngưỡng; so fixed-weight với PID. Để xét tương tác với chọn mẫu, dùng ma trận2×2 **fixed-weight/PID × random/XAI-guided**, cùng ngân sách nhãn. Chưa có dữ liệu này thì giữ PID ở mức đóng góp thiết kế/kiểm thử cơ chế, không gắn FPR0,8% cho bằng chứng mới.
2. **Dữ liệu và tính khái quát:** xác minh xuất xứ, nghĩa nhãn, overlap/near-duplicate; thêm đánh giá có metadata nguồn/họ/thời gian trước tuyên bố ransomware hoặc zero-day. AUC cao trên mini bằng model pretrained không khắc phục thiếu nguồn gốc hay nguy cơ train/test overlap.
3. **Fidelity và PE:** thống nhất đặc tả metric–code; bổ sung masking theo quan hệ nhóm/miền hợp lệ nếu muốn bảo vệ tuyên bố PE-aware. Chi phí chuyên gia và độ trễ động/đầu cuối chỉ được kết luận sau đo trực tiếp.

Nguồn số liệu và giới hạn chi tiết: [AL REPORT](experiments/pilot_al/REPORT.md), [AL README](experiments/pilot_al/README.md), [AL summary](experiments/pilot_al/summary.json); [Fidelity README](experiments/pilot_fidelity/README.md), [Fidelity summary](experiments/pilot_fidelity/run_seed42/summary.json). Mô hình, split, truy vấn, dự đoán và cấu hình đi kèm các thư mục thí nghiệm để kiểm tra lại.
