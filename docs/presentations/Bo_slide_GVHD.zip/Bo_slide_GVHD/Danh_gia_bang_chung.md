# Đánh giá bằng chứng và thiết kế đo thay thế tối thiểu

**Phạm vi:** Bảng 4.5–4.9 của `luuvan.pdf`; đối chiếu mã nguồn repository `doanhjut/thesis2026` và hai pilot mới đã hoàn tất. Số trang dưới đây là số in trong luận văn. Báo cáo này đánh giá khả năng bảo vệ các kết luận, không xác nhận đã tái lập những kết quả cũ. Số liệu pilot có trong [Ket_qua_bo_sung.md](Ket_qua_bo_sung.md), [experiments/pilot_al/summary.json](experiments/pilot_al/summary.json) và [experiments/pilot_fidelity/run_seed42/summary.json](experiments/pilot_fidelity/run_seed42/summary.json).

## 1. Kết luận học thuật

**Các bảng cũ 4.5–4.9 chưa đủ để xác nhận PID làm giảm FPR, XAI-guided AL tiết kiệm chi phí gán nhãn và OFS chứng minh độ trung thực của giải thích.** Số liệu xuất từ hằng số không tự chứng minh số liệu ban đầu sai, nhưng script xuất lại chúng cũng không phải thí nghiệm tái lập. Hai pilot mới đã tạo bằng chứng truy nguyên được cho so sánh AL tại cùng ngân sách và phép thử SHAP masking; chúng không xác nhận hồi tố các bảng cũ hoặc chứng minh hiệu quả PID.

Các pilot đã huấn luyện mới, lưu mô hình, split, truy vấn và dự đoán. Chúng đủ cho kết luận thăm dò trong phạm vi dữ liệu cục bộ và thiết lập được công bố. Nguồn upstream và ý nghĩa nhãn riêng cho ransomware vẫn chưa xác minh. Kết quả không được chọn để buộc phương pháp đầy đủ phải thắng.

| Bảng / tuyên bố | Vấn đề và trạng thái hiện tại | Biện pháp tối thiểu |
|---|---|---|
| **4.5, tr.53: hiệu quả dung hợp PID** | Các giá trị tĩnh/động/PID có trong script xuất dữ liệu hardcode [R1]. Chưa có bộ dự đoán tĩnh–động thực ghép theo mẫu đủ để xác nhận bảng. Các cột thời gian khác phạm vi đo. **Chưa đủ bằng chứng hiệu quả thực tế.** | Cùng mẫu có nhãn, hai tín hiệu thực, cùng cổng và ngưỡng được chọn trên validation; so với fixed-weight; lưu FP/FN và thời gian riêng từng tầng. Nếu chỉ có mô phỏng, giới hạn ở kiểm thử cơ chế. |
| **4.6–4.7, tr.54–55: AL cải thiện AUC** | Đường học được gán sẵn trong script [R2]. Giá trị uncertainty cuối trong script là 0,9785, khác 0,9792 của Bảng 4.7; cần xác định đúng phiên bản. **Chưa đủ để kết luận ưu thế hoặc tiết kiệm nhãn.** | Huấn luyện mới; random, uncertainty và XAI-guided dùng cùng split/initial set/ngân sách; lưu ID được truy vấn, metric từng vòng và thời gian. |
| **4.8, tr.55: giảm cảnh báo nhầm** | FP = 48 trên 3.000 benign cho **FPR = 1,6%**, không phải 0,8%. Ma trận cũng được khai báo trực tiếp trong script [R2]. **Có thể kiểm tra phép tính; chưa xác minh nguồn đo.** | Tính confusion matrix từ nhãn và dự đoán test của lần chạy xác định. Không ghép 1,6% và 0,8% thành kết quả cùng hệ thống nếu chưa có cấu hình chứng minh. |
| **4.9, tr.57: Fidelity/OFS** | Các số được xuất từ hằng số [R3]; công thức, định nghĩa metric và triển khai không thống nhất [R4–R5]. **Chưa đủ bằng chứng cho điểm OFS hoặc tính vượt trội của SHAP.** | Khóa đặc tả, baseline từ train, cùng top-k và subset; so SHAP với attribution ngẫu nhiên; báo cáo thành phần và độ thay đổi dự đoán. |

## 2. Tách đúng đóng góp PID và tương tác với AL

Bốn cấu hình `tĩnh / tĩnh+động+PID / tĩnh+AL / tĩnh+động+PID+AL` đồng thời thay đổi thông tin động và cơ chế dung hợp, nên chênh lệch so với tĩnh không tách được lợi ích PID. Thiết kế chính đề nghị là **fixed-weight/PID × random sampling/XAI-guided**, với cùng hai tín hiệu, cùng cổng và cùng ngân sách nhãn. Tĩnh đơn lẻ là đối chứng bổ sung; cấu hình không cập nhật dữ liệu chỉ cần khi nghiên cứu riêng lợi ích cập nhật so với giữ nguyên model.

Với \(F_{pa}\) là FPR của ô PID \(p\in\{0,1\}\), AL \(a\in\{0,1\}\), tương tác trên thang chênh lệch là:

\[
\Delta_{\mathrm{int}}=F_{11}-F_{10}-F_{01}+F_{00}.
\]

Ở đây, mức 0/1 của yếu tố dung hợp là fixed-weight/PID; mức 0/1 của yếu tố chọn mẫu là random/XAI-guided, cùng số nhãn. Giá trị tương tác âm cho thấy mức giảm FPR vượt tổng hai hiệu ứng riêng **trên thang này**; cấu hình đầy đủ tốt nhất chưa đủ chứng minh tương tác. Muốn kết luận phải có dữ liệu thật và độ bất định ghép cặp.

PID không có bảo đảm toán học tự giảm báo động nhầm. Với P-only và quy ước của PDF, \(e=p_d-p_s\), \(w_d=\sigma(K_pe)\):

\[
p_f=\frac{p_s+p_d}{2}+\frac e2\tanh(K_pe/2)\geq\frac{p_s+p_d}{2},\qquad K_p>0.
\]

Nó thiên về xác suất cao hơn, chưa phải ước lượng độ tin cậy của nguồn. Ví dụ toán học, không phải số đo: một mẫu benign với \(p_s=0,7\), \(p_d=0,1\), \(K_p=2\) cho trung bình 0,4 nhưng P-fusion xấp xỉ 0,5611. Ở ngưỡng 0,5, fusion có thể tạo FP. Cần kiểm tra thứ tự mẫu/reset với I, D; trọng số bị chặn không đồng nghĩa hệ ổn định hoặc xác suất được hiệu chuẩn. Mã hiện tại cộng integral mà không clip và không có tham số thời gian rõ ràng [R6], khác mô tả chống windup tại mục 3.2.3, tr.38–39.

**Nếu thiếu tín hiệu động thực ghép cặp:** không thay bằng dự đoán động giả rồi gọi đó là đánh giá ransomware. Giữ PID ở mức thiết kế/kiểm thử cơ chế; ghi rõ hiệu quả thực nghiệm còn cần đo. AL và fidelity vẫn có thể được đánh giá độc lập.

## 3. Pilot thay thế khả thi cho AL và fidelity

**Hai pilot đã hoàn tất** trên CSV cục bộ gồm 2.000 dòng, 2.381 đặc trưng, phân hoạch 1.200 phát triển, 400 validation, 400 test (300 âm, 100 dương). AL dùng năm seed ghép cặp, 200 nhãn khởi tạo và 5 vòng × 100 truy vấn, kết thúc ở 700 nhãn huấn luyện; 400 nhãn validation là tài nguyên bổ sung. Mỗi checkpoint huấn luyện mới. Fidelity huấn luyện một model khác trên cả 1.200 dòng phát triển, seed 42. Test không điều khiển truy vấn, ngưỡng hay điểm dừng. Hai cấu hình khác số nhãn và số cây, nên không so AUC trực tiếp để suy ra lợi ích của một thành phần.

- **AL đã đo:** random, uncertainty, U+H, U+V và XAI đầy đủ, cùng ngân sách và pipeline. Có ROC-AUC, average precision (AP), TPR/FPR và thời gian. XAI đầy đủ có AUC cao hơn uncertainty ở 5/5 seed, chênh lệch trung bình +0,005787; FPR thấp hơn chỉ ở 2/5 seed. Chưa thể kết luận từng thành phần tự cải thiện ổn định hoặc FPR được giảm ổn định.
- **Định nghĩa AL của pilot đã khóa:** H dùng tỷ lệ tổng độ lớn SHAP theo dấu, V dùng phương sai SHAP có dấu, min–max theo pool; trọng số U/H/V = 0,3/0,4/0,3. Không dùng nhãn để xếp hạng hoặc fallback mô phỏng. Code cũ dùng tỷ lệ đếm dấu và phương sai trị tuyệt đối [R7], nên phải phân biệt phiên bản khi cập nhật luận văn. Kiểm tra hậu nghiệm xác nhận query không trùng và metric tính lại từ dự đoán khớp.
- **Fidelity đã đo:** model mới, baseline chỉ từ train; top-k SHAP so với 20 lần random cùng k trên cùng mẫu, k = 10/25/50; lưu mask và dự đoán. Ở k = 25, AUC drop top-SHAP = 0,161633, random trung bình = 0,000257. FF thô = 2,004518, EC = 0,304373 và CF = 0,587352 theo các quy ước được công khai. Không xuất OFS khi công thức PDF và code cũ chưa thống nhất.
- **Tính hợp lệ PE:** chuyển phép thử từ ảnh sang vector PE đòi hỏi giữ kiểu, miền và quan hệ nhóm đặc trưng. Trung vị/giá trị trung bình không tự bảo đảm PE hợp lệ; Gaussian noise trên trường đếm/API có thể mất nghĩa. Nếu chỉ kiểm tra vector, nói rõ chưa tái tạo/chạy tệp PE. CF phân tách nhãn và EC tương quan cấu trúc tương đồng cũng không tự chứng minh faithfulness hay quan hệ nhân quả.

Nguồn dữ liệu pilot được mô tả đúng mức đã biết: CSV có trong Git; nhãn âm/dương và schema đã kiểm tra; chưa xác minh upstream, thời gian hay họ mã độc. Không phát hiện vector trùng hoàn toàn nhưng chưa loại trừ near-duplicate. Vì vậy, kết quả là **pilot nội bộ trên dữ liệu cục bộ**, không thay thế đánh giá ransomware/zero-day trên một bộ dữ liệu chuẩn có nguồn gốc xác minh.

**AUC cao của model pretrained trên mini không phải kết quả thay thế hợp lệ:** chưa biết mini có nằm trong dữ liệu huấn luyện hay cách lấy mẫu trước đó hay không; schema và xuất xứ cũng cần xác nhận. Chạy inference thành công chứng minh khả năng thực thi, không chứng minh khái quát hóa. Huấn luyện mới trên split được khóa tránh dùng trực tiếp model đó để tuyên bố hiệu năng, nhưng không tự giải quyết vấn đề xuất xứ hoặc near-duplicate của dữ liệu.

## 4. Thống kê và chi phí: vừa đủ nhưng đúng

Mỗi seed phải ghép các phương pháp theo cùng split, initial set và pool; mọi ngưỡng/siêu tham số chọn trên validation. Muốn nói giảm FPR mà vẫn giữ phát hiện, chọn ngưỡng theo **cùng TPR mục tiêu trên validation**, khóa trước khi đánh giá test và báo cáo cả TPR thực đạt trên test. Không ép test đạt cùng TPR bằng cách dò lại nhãn test.

Năm seed chỉ là mức kiểm tra độ biến thiên hạn chế, không phải ngưỡng tự động tạo ý nghĩa thống kê. Nếu cùng test, các seed không là năm tập test độc lập. Báo cáo chênh lệch ghép cặp; bootstrap dùng cùng chỉ số mẫu cho hai phương pháp, theo cụm nếu biết quan hệ họ/near-duplicate. Không coi các vòng AL là quan sát độc lập. Tập benign nhỏ có độ phân giải FPR thô: luôn kèm FP và số benign, không báo quá nhiều chữ số hay suy rộng FPR rất thấp.

Tiết kiệm nhãn cần số nhãn để đạt **cùng chất lượng mục tiêu**; AUC cao hơn ở cùng ngân sách là kết quả khác. Chi phí chuyên gia chưa đo thì chỉ báo số truy vấn. Chi phí tính toán gồm chấm pool, SHAP, retrain và vận hành động; tách thời gian khởi tạo/đoán, fusion, sandbox và đầu cuối. Không đổi 15,2 ms fusion thành thời gian toàn hệ thống.

## 5. Cách đưa lên slide đóng góp–bằng chứng

Giữ ba đóng góp làm trục; mỗi đóng góp đi với **cơ chế → phép so sánh → kết quả thật → phạm vi kết luận**. Không biến bài trình bày thành quy trình xin phê duyệt hoặc danh sách lỗi.

| Trạng thái bằng chứng | Câu có thể dùng |
|---|---|
| AL pilot đã chạy, có log | “Trên phân hoạch và ngân sách của pilot, phương pháp đạt [giá trị lấy từ log]. Mức chênh lệch và độ biến thiên được báo cáo; chưa suy rộng tới zero-day.” |
| Masking đã chạy | “Che top-k SHAP làm đầu ra thay đổi [số đo]; đối chứng ngẫu nhiên dùng cùng k. Kết quả đánh giá hành vi mô hình trên vector đặc trưng.” |
| PID chưa có dữ liệu thực ghép cặp | “Đóng góp thiết kế là cơ chế dung hợp có trạng thái. Kiểm thử hiện tại chưa đủ xác nhận PID cải thiện FPR trên dữ liệu động thực.” |
| Số liệu cũ chưa đối soát | Đưa vào phụ lục “số liệu bản thảo cần truy nguyên”, không dùng làm headline kết luận. |

Với OFS, ưu tiên các thành phần và phép thử có thể giải thích. Công thức (3.18), tr.44 là harmonic mean; từ FF=0,3328, EC=0,3008, CF=0,5230 cho khoảng **0,3640**. Script dùng tổng có trọng số 0,5/0,3/0,2, cho **0,36124**, khớp số 0,3612 báo cáo. Đây không phải sai số làm tròn của cùng một công thức. Ghi khác biệt trong phụ lục nguồn và khóa định nghĩa trước tính lại; không chỉ thay một con số trên slide.

## Nguồn đối chiếu

Các đường dẫn R1–R7 tương đối với gốc repository doanhjut/thesis2026, ở bản nguồn đã kiểm tra; số dòng giúp tìm đoạn mã.

- **[R1]** `scripts/run_experiments.py:102`: dữ liệu ablation dung hợp khai báo trực tiếp; so Bảng 4.5, tr.53.
- **[R2]** `scripts/run_experiments.py:233`: đường học gán sẵn; `scripts/run_experiments.py:265`: confusion matrix; so Bảng 4.6–4.8, tr.54–55.
- **[R3]** `scripts/run_experiments.py:408`: hằng số fidelity; so Bảng 4.9, tr.57.
- **[R4]** `scripts/ember/evaluate_xai_fidelity.py:51`: baseline lấy từ X đầu vào; `scripts/ember/evaluate_xai_fidelity.py:63`: FF dựa AUC; `scripts/ember/evaluate_xai_fidelity.py:72`: noise/EC; `scripts/ember/evaluate_xai_fidelity.py:93`: CF dùng hàng xóm Euclidean; `scripts/ember/evaluate_xai_fidelity.py:113`: OFS cộng trọng số. So mục 3.4, tr.43–46; cần xác định X là tập nào trước kết luận rò rỉ.
- **[R5]** `src/fidelity_framework.py:153`: baseline từ X; `src/fidelity_framework.py:279`: noise trên trường nonzero; `src/fidelity_framework.py:426`: OFS cộng trọng số.
- **[R6]** `src/pid_fusion.py:54`: cập nhật integral/derivative và chặn trọng số; so công thức 3.5–3.8 và mục 3.2.3, tr.37–39.
- **[R7]** `src/xai_active_learning.py:139`: SHAP mô phỏng; `src/xai_active_learning.py:154`: phương sai trị tuyệt đối, tỷ lệ đếm dấu và điểm tổng hợp. So công thức 3.9–3.13, tr.40–41.

- **Pilot AL mới:** [REPORT.md](experiments/pilot_al/REPORT.md), [README.md](experiments/pilot_al/README.md), `experiments/pilot_al/summary.json`, `experiments/pilot_al/paired_differences.csv`, `experiments/pilot_al/post_audit.json`.
- **Pilot fidelity mới:** [README.md](experiments/pilot_fidelity/README.md), `experiments/pilot_fidelity/run_seed42/summary.json`; model, split, dự đoán, mask và bootstrap lưu cùng thư mục.
