# Báo cáo dự án — 9 trang

Bản cập nhật 13/10/2026. Bộ slide trình bày dự án, ba đóng góp, bảng/biểu đồ và nội dung tiếp thu góp ý Seminar. Các ghi chú về dữ liệu, đối soát và việc bổ sung thực nghiệm đã tách sang tài liệu làm việc riêng.

## Mở tệp

- `Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pptx`: 9 slide chỉnh sửa được, có lời dẫn trong Notes.
- `Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pdf`: bản trình chiếu/xem nhanh.
- `Ke_hoach_bo_sung_thuc_nghiem.docx`: phiếu công việc chỉnh sửa được.
- `Ke_hoach_bo_sung_thuc_nghiem.pdf`: phiếu công việc 3 trang để đọc/in.
- `Ke_hoach_bo_sung_thuc_nghiem.md`: cùng nội dung dạng Markdown.
- `Loi_dan_thuyet_trinh.md`: lời dẫn của 9 slide.

## Mạch trình bày

1. Giới thiệu dự án.
2. Bài toán và điểm khác biệt của ba đóng góp.
3. Kiến trúc hệ thống.
4. PID Fusion và bảng so sánh báo cáo trong luận văn.
5. Công thức chọn mẫu XAI-Guided AL.
6. Đường học và bảng kết quả AL.
7. Đối chứng masking SHAP và kết quả Fidelity.
8. Nội dung tiếp thu góp ý Seminar.
9. Tổng hợp đóng góp và kết quả chính.

## Nguồn số liệu và hình cần bổ sung

Slide 4 trích Bảng 4.5 của bản thảo; slide 6–7 dùng kết quả pilot đã đo. Trạng thái của từng nguồn, dữ liệu cần thêm, phép đo, tên tệp hình/bảng thay thế và vị trí thay được ghi trong phiếu công việc. Không có phép đo mới trong lần rút gọn slide này.

`Nguon_so_lieu/` chứa bản tổng hợp AL và Fidelity để kiểm tra số trên slide. Mã chạy, toàn bộ dự đoán, mô hình và log của các pilot nằm trong [gói thực nghiệm đã lưu tại commit 526a748](https://github.com/doanhjut/thesis2026/blob/526a748093447a02f680d808ed05a211fb23def3/docs/presentations/Bo_slide_GVHD.zip?raw=true). Tên artifact trong phiếu được hiểu tương đối với `experiments/` của gói đó; các tên đầu ra đề nghị là tệp sẽ tạo khi thực hiện công việc, chưa phải kết quả mới.

`source_slides/build_deck.py` và `source_slides/charts/` là nguồn dựng slide. Chạy Python với python-pptx, Pillow để xuất PowerPoint vào `source_slides/generated/`; xuất PDF bằng LibreOffice hoặc PowerPoint. `manifest_sha256.json` dùng để kiểm tra tính toàn vẹn tệp.
