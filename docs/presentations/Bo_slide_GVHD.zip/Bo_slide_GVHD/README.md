# Slide báo cáo đóng góp và bằng chứng thực nghiệm

Bản cập nhật ngày 12/10/2026. **12 slide chính, 5 slide phụ lục**, thời lượng trình bày khoảng 12–15 phút. Trọng tâm là điểm khác biệt của ba đóng góp, kết quả đo được và việc tiếp thu góp ý Seminar.

## Mở tài liệu

- `Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pptx`: PowerPoint chỉnh sửa được, có lời dẫn trong Notes của từng slide.
- `Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pdf`: bản xem hoặc in, 17 trang.
- `Loi_dan_thuyet_trinh.md`: lời trình bày và nguồn từng slide.
- `Ket_qua_bo_sung.md`: bảng kết quả pilot và kết luận có thể sử dụng.
- `Danh_gia_bang_chung.md`: đánh giá các bảng cũ và gói thực nghiệm bổ sung tối thiểu.

## Những số liệu nào được sử dụng?

Hai pilot đã thực sự chạy, có source, cấu hình, split, seed, mô hình, dự đoán và kiểm tra truy vết trong `experiments/`:

1. **AL:** 5 chiến lược × 5 seed × 6 ngân sách; từ 200 đến 700 nhãn huấn luyện. Ở 700 nhãn, XAI đạt AUC **0,9749 ± 0,0040**, Uncertainty **0,9691 ± 0,0046**. AUC tăng trong 5/5 seed, FPR giảm chỉ trong 2/5 seed. Chưa chứng minh tiết kiệm nhãn hoặc giảm FPR ổn định.
2. **Fidelity:** mô hình khác, huấn luyện trên 1.200 mẫu. Ở k = 25, che top-SHAP làm AUC từ **0,9802 xuống 0,8185**; che ngẫu nhiên cùng k cho trung bình **0,9799**. Đây là phép thử vector masking; chưa xác nhận tệp PE hợp lệ hoặc tính nhân quả. OFS chưa tổng hợp.

Nguồn dữ liệu upstream và ý nghĩa nhãn riêng ransomware của CSV chưa xác minh. Đây là **pilot nội bộ trên dữ liệu có sẵn trong repository**, không phải tái lập benchmark gốc của luận văn. Cùng test không có nghĩa cùng mô hình: không lấy AUC của hai pilot trừ nhau để đo đóng góp.

PID hiện thiếu điểm động thực ghép theo mẫu; số cũ chỉ nằm trong phụ lục đối soát. ZIP **không sử dụng bảng số liệu giả lập** làm bằng chứng và không khẳng định toàn hệ thống đã đủ kiểm chứng để bảo vệ.

## Tái lập

- Repository: https://github.com/doanhjut/thesis2026
- Dữ liệu: `data/processed/real_mini_dataset.csv` (không nhân bản vào ZIP).
- SHA-256 dữ liệu: `c733cc0c3e0950fa1d05d57d34c69d0a034383e0c1a2fde0e6878b9e2e8c3668`.
- Đọc `experiments/pilot_al/README.md` và `experiments/pilot_fidelity/README.md` để chạy lại. Source và config giữ đường dẫn của môi trường đã chạy `/workspace/thesis2026`; trên máy khác cần điều chỉnh đường dẫn và lưu thành một lần chạy mới. Không chạy đè lên artifacts đã phát hành.
- `source_slides/build_deck.py` dựng lại PowerPoint và lời dẫn từ các JSON đo được trong ZIP. Cần Python với `python-pptx`, Pillow, NumPy và matplotlib; PDF được xuất bằng LibreOffice. PowerPoint cũng có thể sửa trực tiếp.
- `manifest_sha256.json` chứa hash các tệp trong bộ phát hành.

Source ứng dụng trong repository chưa bị sửa. Các runner độc lập phục vụ kiểm chứng và không thay thế ngầm các công thức/thuật toán trong luận văn.
