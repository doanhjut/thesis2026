# Lời dẫn trình bày — 9 trang

Bản trình bày dự án; công việc bổ sung thực nghiệm được tách thành Ke_hoach_bo_sung_thuc_nghiem.md/PDF.

## Slide 1: Nội dung dự án

Thưa thầy, em trình bày lại nội dung dự án theo ba đóng góp chính: dung hợp tĩnh–động, chọn mẫu gán nhãn bằng XAI và kiểm tra chất lượng giải thích. Với mỗi phần, em nêu điểm khác biệt của cách tiếp cận và bảng hoặc biểu đồ đánh giá. Phần cuối đối chiếu các nội dung đã bổ sung theo góp ý Seminar. Các việc cần đối soát và bổ sung hình thực nghiệm được tách thành tài liệu làm việc đi kèm.

Nguồn: luuvan.pdf; báo cáo gói thực nghiệm bổ sung

## Slide 2: Vấn đề và phần phát triển

Dự án kế thừa biểu diễn PE, mô hình học máy, PID, active learning và SHAP. Phần phát triển nằm ở cách tích hợp ba cơ chế. Thứ nhất là điều chỉnh trọng số khi kết hợp hai nguồn dự đoán. Thứ hai là dùng cấu trúc giải thích để chọn mẫu cần nhãn. Thứ ba là kiểm tra lời giải thích bằng phép đo thay vì chỉ xem biểu đồ. Các hướng kế thừa ở đây là mốc so sánh phương pháp; không dùng điểm AUC trên bộ dữ liệu khác để tuyên bố vượt nghiên cứu trước.

Nguồn: luuvan.pdf §2.4, §3.2–3.4

## Slide 3: Kiến trúc hệ thống

Đầu tiên mô hình tĩnh cho xác suất. Cổng bất định xác định mẫu nào cần phân tích động. Khi có cả hai tín hiệu, PID xác định trọng số dung hợp. Song song, AL chọn mẫu để chuyên gia hoặc oracle cung cấp nhãn, rồi học lại mô hình trên tập nhãn tích lũy. Khung Fidelity đánh giá giải thích của mô hình tĩnh đang được sử dụng.

Nguồn: luuvan.pdf §3.1–3.4

## Slide 4: PID Fusion

Điểm khác biệt của PID là trọng số thay đổi theo tín hiệu và trạng thái, thay vì cố định cho mọi trường hợp. P phản ứng với bất đồng hiện tại; I và D đưa thông tin về chuỗi vào cơ chế. Bảng bên phải trích Bảng 4.5 đang được báo cáo trong luận văn để trình bày cấu trúc so sánh tĩnh, động và các cách fusion. Bảng này thuộc nguồn bản thảo; công việc tái lập và thay thế bảng/hình được quản lý riêng trong phiếu đính kèm. Không dùng các số này như kết quả của pilot AL hoặc Fidelity mới chạy.

Nguồn: luuvan.pdf §3.2; Bảng 4.5; Ke_hoach_bo_sung_thuc_nghiem.md, mục 1

## Slide 5: Công thức chọn mẫu AL

U đo bất định từ xác suất. H là entropy của tỷ lệ tổng độ lớn SHAP dương và âm; nếu tổng bằng 0 thì H bằng 0. V là phương sai SHAP có dấu trên các chiều, bỏ thành phần bias. Mỗi thành phần được min-max trên pool ở vòng hiện tại. Trọng số 0,3/0,4/0,3 lấy từ cấu hình bản thảo. SHAP được tính lại bằng mô hình vừa huấn luyện của mỗi vòng. Pilot so Random, U, U+H, U+V và XAI đầy đủ ở cùng tập khởi tạo và ngân sách.

Nguồn: pilot_al/config.json; §3.3

## Slide 6: Kết quả AL

Đây là số đo mới của pilot trên CSV trong repository. Tại 700 nhãn, XAI đầy đủ đạt AUC 0,9749±0,0040; Uncertainty đạt 0,9691±0,0046 và Random đạt 0,9634±0,0063. Chênh lệch ghép cặp XAI trừ U là 0,005787 và dương ở cả năm seed. AP cũng tăng từ 0,9363 lên0,9442. Đường học thể hiện trung bình; vùng tô là±1 độ lệch chuẩn, không phải khoảng tin cậy. Bảng cắt bỏ cho biết kết quả cuối của H,V riêng và tổ hợp. Phạm vi dữ liệu, diễn giải FPR, ngân sách validation và các phép đo cần bổ sung nằm trong phiếu công việc.

Nguồn: pilot_al/summary.json; REPORT.md

## Slide 7: Kết quả Fidelity

Khung này bổ sung cách đánh giá định lượng cho lời giải thích. Trong phép thử, che các chiều quan trọng theo SHAP làm AUC giảm mạnh hơn che ngẫu nhiên cùng số chiều. Tại k = 25, AUC giảm từ 0,9802 xuống 0,8185, trong khi random trung bình còn 0,9799. Kết quả hỗ trợ thứ hạng SHAP dưới phép masking đã chọn. EC mô tả tương quan cấu trúc tương đồng giữa PE và SHAP; CF mô tả phân tách hai nhãn trong không gian giải thích. Đây là mô hình Fidelity riêng, không lấy AUC của nó trừ AUC của mô hình AL để suy ra lợi ích. Các điều chỉnh PE-aware, FF và OFS được quản lý trong tài liệu đính kèm.

Nguồn: pilot_fidelity/run_seed42/summary.json; luuvan.pdf §3.4

## Slide 8: Tiếp thu góp ý Seminar

Phần này trả lời trực tiếp các nhận xét trước. Đối với PID, em làm rõ vai trò cổng và dung hợp, đồng thời trình bày các mốc trong bảng so sánh của luận văn. Đối với AL, đã có thí nghiệm mới với năm chiến lược và năm seed ở cùng ngân sách. Với câu hỏi AUC tăng ít, em đưa độ phân tán và chênh lệch ghép cặp thay vì chỉ một số cuối. Với XAI, có phép che top-SHAP và random cùng k cùng baseline. Những đầu việc kiểm chứng tiếp và hình cần thay nằm riêng trong phiếu công việc để tiếp tục hoàn thiện.

Nguồn: góp ý.txt; các báo cáo pilot; phiếu công việc đính kèm

## Slide 9: Kết luận

Ba phần bổ sung cho nhau trong quy trình: PID xử lý kết hợp tín hiệu, AL lựa chọn dữ liệu cần gán nhãn, Fidelity kiểm tra lời giải thích. Điểm số mới rõ nhất là AL tăng AUC tại cùng ngân sách qua năm seed, và thứ hạng SHAP tạo tác động lớn hơn random trong phép masking. Mỗi kết quả gắn với một phép so sánh cụ thể. Tài liệu làm việc riêng giữ các đầu việc đối soát, ảnh cần bổ sung và điều kiện thay bảng để tiếp tục hoàn thiện nội dung.

Nguồn: Bảng 4.5; pilot_al/summary.json; pilot_fidelity/run_seed42/summary.json
