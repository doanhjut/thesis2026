# Lời dẫn trình bày với thầy hướng dẫn

12 slide chính, khoảng 12–15 phút; 5 slide phụ lục để trả lời câu hỏi.

**Phạm vi:** Số mới là kết quả pilot thực sự đã chạy trên CSV trong repository. Chưa xác minh nguồn dữ liệu và nhãn riêng ransomware; không dùng số giả lập làm bằng chứng. Số cũ chỉ nằm trong phụ lục đối soát. Công thức và phần mềm luận văn chưa được tự động sửa theo pilot.

## Slide 01 — Ba đóng góp và bằng chứng thực nghiệm

Thưa thầy, nội dung và phạm vi luận văn đã được thống nhất. Hôm nay em trình bày ba điểm: giải pháp khác các hướng nghiên cứu kế thừa ở đâu; bằng chứng thực nghiệm hiện hỗ trợ được kết luận nào; và các góp ý Seminar đã được xử lý ở phần nào. Trong đợt đối soát này, em đã bổ sung pilot AL và kiểm tra SHAP chạy thật trên dữ liệu mẫu trong repository. Các kết quả này có phạm vi hạn chế và không được gộp với số cũ chưa truy nguyên được. Thời lượng 12–15 phút cho 12 slide chính; 5 slide cuối là phụ lục.

Nguồn: luuvan.pdf; góp ý.txt; kết quả pilot kèm bộ slide

## Slide 02 — Điểm khác biệt so với nghiên cứu kế thừa

EMBER cung cấp biểu diễn PE và baseline học máy; luận văn mở rộng kiến trúc bằng phân tích động có điều kiện và một quy tắc dung hợp thích nghi. PID là kiến thức điều khiển kế thừa, không phải phát minh mới của luận văn; việc ánh xạ độ bất đồng giữa hai xác suất thành trọng số là lựa chọn cần kiểm chứng. Với AL, đóng góp nằm ở điểm truy vấn dùng tín hiệu SHAP, nên phải so với uncertainty cùng ngân sách nhãn. Với XAI, luận văn cụ thể hóa các phép kiểm tra định lượng, nhưng FF/EC/CF/OFS là các định nghĩa của luận văn, không phải nguyên bộ chuẩn của Yeh và cộng sự. Em không dùng điểm AUC của bài báo trên dữ liệu khác để tuyên bố vượt nghiên cứu trước.

Nguồn: §2.4 tr.28–31; §3.2–3.4 tr.36–46; tài liệu tham khảo [2], [3], [14], [21], [27]

## Slide 03 — Kiến trúc và vai trò ba đóng góp

Em tách rõ luồng phát hiện trực tuyến với vòng cập nhật mô hình. Mẫu ngoài vùng bất định có thể được xử lý bằng mô hình tĩnh; mẫu trong vùng bất định được phân tích động rồi dung hợp. PID không quyết định trực tiếp việc kích hoạt sandbox. AL chạy theo vòng: oracle cung cấp nhãn, sau đó mô hình được học lại; AL không tự sinh ra nhãn đúng. Fidelity ở đây kiểm tra giải thích của mô hình tĩnh. Vì SHAP đang giải thích LightGBM, không nên gọi đó là giải thích đầy đủ toàn bộ quyết định PID.

Nguồn: §3.1–3.4; đối chiếu sơ đồ slide Seminar cũ

## Slide 04 — Đóng góp PID: ý nghĩa toán và mức đã kiểm chứng

Công thức trên là dạng rời rạc khái quát đang dùng trong nguyên mẫu, với bước thời gian đơn vị; cần khóa phiên bản có hay không có Δt, anti-windup và cách reset để khớp bản thảo. Vì trọng số nằm trong [0,1] và hai đầu vào là xác suất, đầu ra nằm trong [0,1] do tính chất tổ hợp lồi. Đây là điều chứng minh được về miền giá trị. Không thể từ đó suy ra giảm FPR: sai số e chỉ đo bất đồng, không phải sai số đối với nhãn đúng. I và D còn phụ thuộc thứ tự mẫu, nên phải định nghĩa chuỗi hoặc phiên hợp lý. Bảng 4.5 hiện chưa có log thực đủ để tái lập; log demo trong repo sinh điểm động và độ trễ bằng ngẫu nhiên. Em giữ đóng góp ở mức nguyên mẫu dung hợp cần đánh giá. Đối chứng tối thiểu là cùng các cặp điểm tĩnh–động, giữ cổng và ngưỡng chọn bằng validation, so Fixed, P, PI, PID; static-only và dynamic-only là mốc riêng. Không tuyên bố PID vượt phân tích động ở mọi tiêu chí.

Nguồn: §3.2; src/pid_fusion.py; scripts/live_defense_demo.py; Danh_gia_bang_chung.md kèm bộ slide

## Slide 05 — Phạm vi dữ liệu và giao thức pilot

Dữ liệu có 2.000 dòng, không thiếu giá trị và không có hai vector trùng hệt, nhưng không có hash tệp, thời gian hoặc họ mã độc. Vì vậy chưa xác minh được nguồn, quan hệ cùng họ, cũng như nhãn 1 có riêng ransomware hay malware nói chung. Em chỉ gọi đây là nhãn 0/1 của bộ dữ liệu mẫu. Việc huấn luyện mới tránh dùng mô hình có sẵn có thể từng thấy những mẫu này; tuy nhiên split ngẫu nhiên trong CSV không loại trừ sự gần trùng hoặc liên quan theo họ. Train/pool1200, validation400, test400 dùng chung cho mọi phương pháp. AL bắt đầu200 nhãn, năm vòng thêm100, tổng cuối700; năm seed thay đổi tập khởi tạo và ngẫu nhiên mô hình. Độ lệch chuẩn qua seed không phải khoảng tin cậy cho quần thể triển khai. Tập test có300 nhãn0, nên một FP tương ứng khoảng0,333 điểm phần trăm FPR.

Nguồn: experiments/pilot_al/config.json, splits.json, metrics.csv; experiments/pilot_fidelity/

## Slide 06 — Điểm chọn mẫu và đối chứng thành phần

U đo bất định dự đoán. Với H, q cộng là tổng SHAP dương chia tổng độ lớn SHAP, q trừ là tổng độ lớn phần âm chia cùng mẫu số; mẫu có tổng bằng0 được gán H bằng0. H lớn biểu thị bằng chứng đối nghịch cùng mạnh, không phải xác suất mô hình sai. V là phương sai của SHAP có dấu trên các đặc trưng, trong đơn vị log-odds của mô hình LightGBM; nó không mặc nhiên là bất định nhận thức. Mỗi thành phần được chuẩn hóa min-max trên pool hiện tại, trường hợp hằng số gán0. Trọng số0,3/0,4/0,3 lấy từ cấu hình bản thảo, không tìm lại bằng test. Khi cắt bỏ H hoặc V, chuẩn hóa lại tổng trọng số của các thành phần còn lại về1. Native TreeSHAP dùng model hiện tại, không fallback mô phỏng. Oracle trong pilot tra nhãn có sẵn sau khi đã chọn mẫu; thời gian gán nhãn chuyên gia chưa được đo.

Nguồn: §3.3 tr.39–43; Bảng 4.10; experiments/pilot_al/run_pilot.py

## Slide 07 — AL: kết quả cải thiện tại cùng ngân sách

Ở ngân sách cuối700 nhãn, XAI đầy đủ đạt AUC 0,9749±0,0040, Uncertainty0,9691±0,0046, Random0,9634±0,0063. Chênh lệch XAI trừ Uncertainty là0,005787±0,003904 qua năm seed ghép cặp; cả năm chênh lệch đều dương. Đây là một tín hiệu thực nghiệm thuận lợi, chưa phải khẳng định có ý nghĩa thống kê cho triển khai vì cùng một test và dữ liệu nguồn chưa xác minh. AP tương ứng XAI0,9442 và Uncertainty0,9363. Phần tô trên biểu đồ là±1 độ lệch chuẩn của seed, không phải khoảng tin cậy95%. Nhãn trên trục chỉ gồm200 nhãn huấn luyện ban đầu và nhãn truy vấn; không tính400 nhãn validation dùng chung. Không suy ra tiết kiệm 90% nhãn hoặc phát hiện zero-day từ pilot này.

Nguồn: experiments/pilot_al/summary.json; curves, paired_differences; source runner kèm ZIP

## Slide 08 — AL: cắt bỏ tín hiệu và chi phí thực

Bảng dùng cùng ngân sách700 nhãn và cùng các tập dữ liệu. H hoặc V riêng lẻ không tạo cải thiện AUC rõ so với U ở ngân sách cuối; tổ hợp đầy đủ đạt AUC trung bình cao nhất trong các cấu hình đã thử. Không gọi đây là bằng chứng tương tác nhân quả hay cấu hình tối ưu toàn cục. Về FPR, XAI trung bình17,53% và U19,87%, nhưng chênh lệch ghép cặp−2,33 điểm phần trăm có độ lệch chuẩn6,62 điểm phần trăm và chỉ giảm ở2/5 seed. TPR tương ứng95,4% và95,6%; đó không phải so sánh tại chính xác cùng TPR test. FPR17% cũng không phải mức phù hợp vận hành thực tế. Timing tính điểm trung bình cho pool600–1000 mẫu là31,65ms với XAI và2,71ms với U. Phần tính điểm bao gồm dự đoán, TreeSHAP, kiểm tra additivity và chuẩn hóa, chưa gồm sắp xếp chọn mẫu, lưu file, chuyên gia gán nhãn hay huấn luyện. TreeSHAP riêng khoảng18,82ms. Timing trên máy này mang tính mô tả, không phải độ trễ toàn hệ thống hoặc chi phí SOC. Không dùng tỷ lệ thời gian để suy ra hiệu năng ở pool lớn.

Nguồn: experiments/pilot_al/metrics.csv, summary.json; README.md

## Slide 09 — Fidelity: phù hợp miền và giới hạn

Khác với các pixel, đặc trưng PE có nhóm histogram, thông tin tệp, header, section, imports/exports và data directories với kiểu dữ liệu và ràng buộc phụ thuộc khác nhau. Một vector bất kỳ sau che không nhất thiết tương ứng tệp PE hợp lệ. Pilot này dùng mean baseline từ train và che chiều riêng lẻ, đối chứng random cùng k; đó là phép kiểm tra ban đầu minh bạch, chưa phải toàn bộ chính sách masking theo nhóm được mô tả tại§3.4.4. Phép đo AUC drop là kiểm tra tác động, không đổi tên thành chỉ số FF đã chuẩn hóa. EC dùng Pearson giữa các phần tử tam giác trên hai ma trận cosine; đặc trưng fit mean/std trên train. CF đúng mẫu số max chuẩn SHAP từng mẫu trong công thức 3.17. EC, CF có ý nghĩa riêng, chưa thể coi điểm cao là giải thích đúng. OFS chưa được dùng vì định nghĩa và miền giá trị thành phần chưa thống nhất với code.

Nguồn: §3.4 tr.43–46, Phụ lụcA.4 tr.77–78; experiments/pilot_fidelity/README.md

## Slide 10 — Fidelity: kết quả đo và diễn giải

Mô hình Fidelity được huấn luyện riêng với100 cây trên toàn bộ1200 mẫu train, khác mô hình AL60 cây và700 nhãn. Vì vậy không lấy AUC hai thí nghiệm trừ nhau để đo đóng góp. Trước che AUC 0,980167. Tại k = 25, che top-|SHAP| cho AUC 0,818533, tức giảm0,161633; random20 lần cho trung bình0,979910, giảm0,000257. Hiệu ứng này cũng xuất hiện ởk = 10 và50. Đây là sanity check cho thứ hạng SHAP đối với mô hình hiện tại; random có thể chọn chiều mô hình không dùng, và cùng k không bảo đảm số chiều thật sự thay đổi hay mức perturbation giống nhau. EC0,304373 và CF0,587352 là các giá trị mô tả, chưa có baseline để phân loại tốt/xấu. Công thức FF chia cho xác suất gốc cho giá trị thô2,0045 tại k = 25, lớn hơn1; em không tự clip hay thay định nghĩa để tạo điểm đẹp. Chưa xuất OFS. Khoảng bootstrap trong báo cáo kèm theo chỉ có điều kiện trên một mô hình đã fit, không tính biến động huấn luyện.

Nguồn: experiments/pilot_fidelity/README.md; summary.json; mask_metrics.csv; mask_predictions.csv

## Slide 11 — Việc đã hoàn thiện theo góp ý Seminar

Em trả lời từng góp ý bằng vị trí có thể kiểm tra. Về PID, bản thảo có phần cơ chế và giới hạn, nhưng chưa đánh dấu hoàn tất chứng minh hiệu quả. Về AL, đợt này đã bổ sung runner không fallback, năm chiến lược cùng ngân sách, năm seed, dự đoán và log truy vấn; đây là tiến bộ thực nghiệm cụ thể so với bảng thiếu dấu vết chạy. Về Fidelity, đã có random control và baseline train, đồng thời làm rõ vấn đề công thức FF/OFS và giới hạn masking vector. Về mức cải thiện nhỏ, em báo độ phân tán và FPR/TPR thực tế, không chỉ chọn AUC đẹp nhất. Phần tích hợp toàn hệ thống chưa chạy vì thiếu dữ liệu động thực ghép từng mẫu. Những nội dung đã có ở bản thảo chỉ được gọi là đã trình bày, không khẳng định chính tôi đã chỉnh sửa file PDF trong lần làm việc này.

Nguồn: góp ý.txt; §3.2–3.4; kết quả pilot trong experiments/; đánh giá bằng chứng kèm ZIP

## Slide 12 — Kết luận theo phạm vi đã chứng minh

Báo cáo đã làm rõ điểm khác biệt của ba thành phần và bổ sung bằng chứng thật cho hai phần có thể chạy trên dữ liệu hiện tại. AL cho kết quả thuận lợi về AUC ở cùng ngân sách, nhưng chưa chứng minh ưu thế vận hành hoặc tiết kiệm nhãn. Fidelity cho thấy việc che các đặc trưng SHAP xếp quan trọng làm suy giảm chất lượng nhiều hơn random trong phép thử đã chọn. PID còn là giả thuyết kỹ thuật có nguyên mẫu; hiệu quả cần tín hiệu động thực và đối chứng ghép cặp. Việc cần làm tiếp được giới hạn: truy nguyên dữ liệu, hoàn tất gói PID cùng bảng2×2, rồi đồng bộ công thức–code–bảng. Không đưa số liệu đẹp nhưng chưa truy nguyên vào kết luận, và không tự kết luận toàn bộ luận văn đã đủ điều kiện bảo vệ chỉ dựa trên pilot.

Nguồn: Danh_gia_bang_chung.md; Ket_qua_bo_sung.md; experiments/

## Slide 13 — Đối soát bảng fusion cũ

Bảng này được giữ trong phụ lục để thầy thấy chính xác số nào đang có vấn đề, không dùng làm bằng chứng tăng chất lượng. Nếu phép đo được truy nguyên, PID so fixed-weight có ΔAUC 0,0098 và FPR giảm0,3 điểm phần trăm. Nhưng trong hiện trạng chưa có log đủ để xác nhận đó là kết quả đo của cùng dữ liệu và giao thức. Static so toàn hệ thống còn thêm nguồn thông tin động, không cô lập đóng góp PID. Chính bảng cũ cũng cho dynamic AUC cao hơn và FPR thấp hơn PID, nên không thể nói PID tốt nhất mọi tiêu chí. Độ trễ fusion và độ trễ dynamic đo hai phần khác nhau; muốn nói về vận hành phải đo end-to-end, tỉ lệ kích hoạt dynamic, p50/p95 và timeout.

Nguồn: Bảng 4.5 tr.53; Danh_gia_bang_chung.md

## Slide 14 — Đối soát bảng AL và Fidelity cũ

Không có ý nghĩa thống kê hoặc vận hành chỉ vì AUC tăng từ0,97 lên0,98. Muốn diễn giải cần giao thức, nguồn mẫu, đối chứng và độ bất định. Ma trận FP 135 xuống48 trên3000 âm cho FPR 4,5% xuống1,6%; số0,8% phải được truy nguyên riêng. Bảng OFS không chỉ sai khác làm tròn: code tính trung bình cộng trọng số và định nghĩa EC/CF cũng khác PDF, nên sửa một ô không giải quyết được. Kiểm tra pretrained trên CSV ra AUC khoảng0,9979 nhưng không biết mẫu có từng nằm trong train, do đó không chọn con số đẹp hơn để thay. Pilot mới được trình bày như một thí nghiệm bổ sung với cấu hình và giới hạn riêng.

Nguồn: Bảng 4.6 tr.54;4.7–4.8 tr.55;4.9 tr.57; evidence_audit/model_check.json

## Slide 15 — Gói thí nghiệm tiếp theo vừa đủ

Không cần mở rộng sang nhiều kiến trúc mới. Cần bảng điểm ghép cặp từ dữ liệu động đã quan sát thật của cùng các tệp; p_dynamic không được tạo từ p_static cộng nhiễu. Nguồn và ý nghĩa nhãn phải xác nhận trước. Dùng cùng tập train/validation/test cho cả bốn cấu hình, random cũng được bổ sung cùng số nhãn để tách tiêu chí chọn mẫu khỏi tác động có thêm nhãn. Cổng và ngưỡng chỉ chọn bằng validation. Để cô lập luật dung hợp, trước hết giữ cùng mô hình tĩnh và cặp điểm rồi so Fixed,P,PI,PID; khi đo cả vòng AL, tính lại p_static bằng đúng checkpoint và báo rõ tỉ lệ kích hoạt dynamic. Trạng thái PID phải theo chuỗi có ý nghĩa, khóa thứ tự và quy tắc reset; nếu mẫu độc lập, I/D có thể chỉ phản ánh thứ tự ngẫu nhiên. M là một metric đã chọn trước; dấu cải thiện phụ thuộc metric cao tốt hay thấp tốt. Hệ thống đầy đủ tốt nhất không tự chứng minh tương tác dương. Trên test nhỏ nên báo số đếm FP/FN và khoảng bất định; không cần phô trương mức cải thiện. Nếu chưa có log động thật, chưa thể hoàn tất phần này chỉ bằng checkout hiện có.

Nguồn: Kế hoạch thực nghiệm và Danh_gia_bang_chung.md; chưa có kết quả cho bảng2×2

## Slide 16 — Ý nghĩa toán học và sửa độ đo

FF có thể vượt1 khi p gốc thấp mà p sau che tăng; ví dụ p0,01 và p_mask0,5 cho tỉ số xấp xỉ49. Mean absolute probability change nằm trong[0,1] và có thể báo riêng, nhưng đổi sang đó là thay định nghĩa, cần ghi rõ phiên bản và chạy lại toàn bộ bảng so sánh. EC là tương quan có thể âm; thêm epsilon không biến nó thành thành phần dương phù hợp harmonic mean. Với CF, chuẩn mỗi tâm không lớn hơn chuẩn mẫu lớn nhấtR, nên khoảng cách hai tâm có thể tới 2R và tỉ số có thể tới 2. CF cũng đo phân tách nhãn chứ không chứng minh quan hệ nhân quả của đặc trưng. Trung bình điều hòa có thể nhấn mạnh thành phần yếu khi cả ba cùng dương và thang đo đã hợp lý, nhưng công thức hiện chưa bảo đảm điều kiện đó. Cách sửa tiết kiệm công nhất là dùng bảng thành phần và đối chứng, để OFS ở phần thảo luận cho tới khi khóa và đánh giá độ nhạy định nghĩa; không gọi OFS là chuẩn đo chất lượng lời giải thích được cộng đồng công nhận.

Nguồn: Công thức3.15–3.18 tr.44; pilot_fidelity/README.md

## Slide 17 — Tái lập và nguồn trích dẫn

Bộ ZIP gồm slide chỉnh sửa được, PDF, lời dẫn, báo cáo đánh giá và mã chạy cùng các kết quả chính. Dữ liệu CSV được tham chiếu từ repository để không nhân bản dữ liệu vào mỗi bộ slide. Với AL có150 model/checkpoint,12500 truy vấn,120000 dự đoán gồm validation vàtest; file hash và hậu kiểm được lưu. Với Fidelity có mô hình riêng,3 giá trịk,20 lặp random mỗi k và đầu vào tái tính các độ đo. Tài liệu liên quan: Anderson và Roth, EMBER: An Open Dataset for Training Static PE Malware Machine Learning Models (2018); Åström và Hägglund, The Future of PID Control (2001); Lundberg và Lee, A Unified Approach to Interpreting Model Predictions (2017); Settles, Active Learning Literature Survey (2009); Yeh và cộng sự, On the (In)fidelity and Sensitivity of Explanations (2019). Các tài liệu được dùng để phân định nền tảng và phần thích nghi, không làm bằng chứng vượt AUC của nghiên cứu trước.

Nguồn: README.md và experiments/ trong ZIP; luuvan.pdf tài liệu tham khảo
