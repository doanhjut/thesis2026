from pathlib import Path
from PIL import ImageFont
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement

PKG_ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent/'generated'
OUT.mkdir(parents=True,exist_ok=True)
P=Presentation(); P.slide_width=Inches(13.333); P.slide_height=Inches(7.5)
P.core_properties.title='Dự án phát hiện Ransomware — Báo cáo 9 trang'
P.core_properties.subject='Kết quả thực nghiệm và tiếp thu góp ý Seminar'
P.core_properties.author='Lưu Văn Doanh'
NAVY='102A43'; INK='17324D'; TEAL='007F7A'; MINT='E4F3EF'; GOLD='A66B16'; CREAM='FFF1D9'; BG='F3F6F9'; GRAY='526779'; LIGHT='DCE5EC'; WHITE='FFFFFF'
FONT='DejaVu Sans'
SLIDES=[]

def color(v): return RGBColor.from_string(v)
def rect(s,x,y,w,h,fill=WHITE,line=None,radius=False):
    sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=color(fill)
    if line: sh.line.color.rgb=color(line);sh.line.width=Pt(.7)
    else: sh.line.fill.background()
    if radius:
        try: sh.adjustments[0]=.1
        except Exception: pass
    return sh

def fit_size(text,w,h,size,bold):
    fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    limit_w=max(1,(w-.025)*72); limit_h=max(1,(h-.015)*72)
    for candidate in [size-i*.5 for i in range(max(1,int((size-8)*2)+1))]:
        font=ImageFont.truetype(fontpath,max(1,int(candidate*4)))
        nlines=0
        for para in text.split('\n'):
            words=para.split();current='';nlines+=1
            for word in words:
                trial=(current+' '+word).strip()
                if current and font.getlength(trial)/4>limit_w:
                    nlines+=1;current=word
                else:current=trial
        needed=nlines*candidate*1.29+3*max(0,len(text.split('\n'))-1)
        if needed<=limit_h:return candidate
    return 8

def txt(s,x,y,w,h,text,size=20,bold=False,fg=INK,align=None):
    size=fit_size(text,w,h,size,bold)
    box=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=box.text_frame;tf.clear();tf.word_wrap=True
    tf.margin_left=Inches(.01);tf.margin_right=Inches(.01);tf.margin_top=Inches(.01);tf.margin_bottom=Inches(.01)
    for i,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=line;p.font.name=FONT;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=color(fg)
        p.space_after=Pt(3);p.line_spacing=1.04
        if align is not None:p.alignment=align
    return box

def line(s,x1,y1,x2,y2,fg=TEAL,width=2,arrow=False):
    sh=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    sh.line.color.rgb=color(fg);sh.line.width=Pt(width)
    if arrow:
        el=OxmlElement('a:tailEnd');el.set('type','triangle');sh.line._get_or_add_ln().append(el)
    return sh

def chip(s,x,y,w,text,kind='done'):
    fill,fg=(MINT,TEAL) if kind=='done' else (CREAM,GOLD)
    rect(s,x,y,w,.33,fill,radius=True);txt(s,x+.09,y+.045,w-.18,.24,text,11,True,fg)

def callout(s,text,y=6.12,kind='done',size=18):
    fill,fg=(MINT,TEAL) if kind=='done' else (CREAM,GOLD)
    rect(s,.55,y,12.23,.59,fill,radius=True);txt(s,.73,y+.11,11.86,.42,text,size,True,fg)

def base(kicker,title,subtitle='',source='',backup=False):
    s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color(BG)
    rect(s,0,0,13.333,.1,TEAL)
    txt(s,.55,.29,11.8,.3,kicker.upper(),11,True,TEAL)
    txt(s,.55,.79,12.2,.76,title,29,True)
    if subtitle:txt(s,.55,1.63,12.1,.55,subtitle,16,False,GRAY)
    line(s,.55,6.98,12.78,6.98,LIGHT,1)
    txt(s,.55,7.07,11.75,.23,source or 'Lưu Văn Doanh  •  Báo cáo với GVHD  •  Luận văn thạc sĩ Kỹ thuật phần mềm',9,False,GRAY)
    n=len(P.slides);txt(s,12.03,7.06,.75,.25,f'{n:02d} / 09',10,True,TEAL)
    return s

def notes(s,title,body,source=''):
    full=body+('\n\nNguồn: '+source if source else '')
    s.notes_slide.notes_text_frame.text=full
    SLIDES.append((title,full))

def table(s,x,y,width,cols,rows,col_widths,row_h=.85,header_h=.48,fs=16):
    rect(s,x,y,width,header_h,NAVY,radius=False)
    xx=x
    for head,cw in zip(cols,col_widths):
        txt(s,xx+.12,y+.11,cw-.24,header_h-.15,head,12,True,WHITE);xx+=cw
    yy=y+header_h
    for i,row in enumerate(rows):
        rect(s,x,yy,width,row_h,WHITE if i%2==0 else 'EAF0F5')
        xx=x
        for j,(val,cw) in enumerate(zip(row,col_widths)):
            txt(s,xx+.12,yy+.14,cw-.24,row_h-.2,val,fs,j==0,INK if j!=len(row)-1 else GRAY);xx+=cw
        yy+=row_h
    return yy


import json
AL=json.loads((PKG_ROOT/'Nguon_so_lieu/pilot_al/summary.json').read_text())
FI=json.loads((PKG_ROOT/'Nguon_so_lieu/pilot_fidelity/run_seed42/summary.json').read_text())
def vn(x,n=4):return f'{x:.{n}f}'.replace('.',',')
def av(m,k='test_auc'):return AL['methods'][m][k]['mean']
def std(m,k='test_auc'):return AL['methods'][m][k]['std']
CHARTS=Path(__file__).resolve().parent/'charts'

# 1 — Project
s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color(NAVY)
rect(s,.68,.66,.08,5.98,TEAL)
txt(s,1.00,.72,11.4,.43,'TRƯỜNG ĐẠI HỌC CÔNG NGHỆ — ĐHQGHN',13,True,'9FD4CF')
txt(s,1.00,1.54,11.35,1.56,'Hệ thống phát hiện Ransomware\nbằng phân tích đa tầng',33,True,WHITE)
txt(s,1.03,3.34,11.15,.97,'Dung hợp PID • Học tích cực dựa trên XAI\nĐánh giá độ trung thực của giải thích',23,False,'B9E4DF')
line(s,1.03,4.81,12.01,4.81,'36506A',1)
txt(s,1.03,5.17,11.1,.60,'Ba đóng góp — kết quả thực nghiệm — tiếp thu góp ý Seminar',19,True,WHITE)
txt(s,1.03,6.08,11.2,.81,'Học viên: Lưu Văn Doanh\nGVHD: PGS.TS. Trương Ninh Thuận',18,False,'C8D8E5')
notes(s,'Nội dung dự án','Thưa thầy, em trình bày lại nội dung dự án theo ba đóng góp chính: dung hợp tĩnh–động, chọn mẫu gán nhãn bằng XAI và kiểm tra chất lượng giải thích. Với mỗi phần, em nêu điểm khác biệt của cách tiếp cận và bảng hoặc biểu đồ đánh giá. Phần cuối đối chiếu các nội dung đã bổ sung theo góp ý Seminar. Các việc cần đối soát và bổ sung hình thực nghiệm được tách thành tài liệu làm việc đi kèm.','luuvan.pdf; báo cáo gói thực nghiệm bổ sung')

# 2 — Problem and differentiation
s=base('01 / Bài toán và điểm khác biệt','Ba vấn đề cần giải quyết trong cùng một hệ thống','Mục tiêu: phát hiện có chọn lọc, sử dụng nhãn hiệu quả và kiểm tra được lời giải thích.',source='Nền tảng kế thừa: EMBER (Anderson & Roth, 2018), AL (Settles, 2009), SHAP (Lundberg & Lee, 2017), Yeh và cs. (2019).')
table(s,.55,2.35,12.23,['HƯỚNG TIẾP CẬN KẾ THỪA','PHẦN DỰ ÁN PHÁT TRIỂN','ĐẠI LƯỢNG ĐÁNH GIÁ'],[
 ('Mô hình tĩnh trên đặc trưng PE\nDung hợp với trọng số cố định','① PID Fusion\nĐiều chỉnh trọng số giữa điểm tĩnh và động.','AUC • FPR / TPR\nChi phí từng tầng'),
 ('AL chọn mẫu ngẫu nhiên\nhoặc theo bất định dự đoán','② XAI-Guided AL\nThêm xung đột hướng và phương sai SHAP.','Chất lượng ở cùng số nhãn\nChi phí tính điểm'),
 ('SHAP thể hiện đóng góp\ncủa từng đặc trưng','③ Đánh giá Fidelity\nĐo tác động, tương đồng và phân tách.','Che top-SHAP / random\nEC • CF')
],[3.55,5.35,3.33],row_h=1.10,fs=17)
callout(s,'Đóng góp tập trung vào cách tích hợp và đánh giá các cơ chế trên bài toán phát hiện mã độc.',size=18)
notes(s,'Vấn đề và phần phát triển','Dự án kế thừa biểu diễn PE, mô hình học máy, PID, active learning và SHAP. Phần phát triển nằm ở cách tích hợp ba cơ chế. Thứ nhất là điều chỉnh trọng số khi kết hợp hai nguồn dự đoán. Thứ hai là dùng cấu trúc giải thích để chọn mẫu cần nhãn. Thứ ba là kiểm tra lời giải thích bằng phép đo thay vì chỉ xem biểu đồ. Các hướng kế thừa ở đây là mốc so sánh phương pháp; không dùng điểm AUC trên bộ dữ liệu khác để tuyên bố vượt nghiên cứu trước.','luuvan.pdf §2.4, §3.2–3.4')

# 3 — Architecture
s=base('02 / Kiến trúc dự án','Một luồng phát hiện; hai cơ chế hỗ trợ cải thiện mô hình','Cổng bất định điều phối phân tích động; PID kết hợp hai điểm dự đoán.',source='Nguồn: luuvan.pdf §3.1–3.4; mã nguồn src/pid_fusion.py, src/xai_active_learning.py, src/fidelity_framework.py.')
for x,y,w,h,title,fill in [(.55,2.62,2.22,1.14,'Tệp PE\nLightGBM → pₛ',WHITE),(3.20,2.62,2.3,1.14,'Cổng bất định\n[θ_low, θ_high]',MINT),(9.75,2.27,3.03,.83,'Quyết định tĩnh',WHITE),(6.05,3.41,2.55,1.05,'Phân tích động\n→ p_d',WHITE),(9.75,3.41,3.03,1.05,'① PID: pₛ + p_d\n→ quyết định',MINT)]:
    rect(s,x,y,w,h,fill,LIGHT,True);txt(s,x+.14,y+.18,w-.28,h-.23,title,17,True)
line(s,2.77,3.18,3.20,3.18,arrow=True)
line(s,4.35,2.62,4.35,2.53);line(s,4.35,2.53,9.75,2.53,arrow=True)
txt(s,5.73,2.18,3.9,.29,'Ngoài vùng bất định',13,True,TEAL)
line(s,5.50,3.43,6.05,3.89,arrow=True);line(s,8.60,3.94,9.75,3.94,arrow=True)
txt(s,5.72,3.0,3.9,.29,'Trong vùng bất định',13,True,TEAL)
rect(s,.55,4.87,7.77,1.20,WHITE,LIGHT,True);txt(s,.77,5.08,7.32,.83,'② AL: SHAP → chọn mẫu → chuyên gia gán nhãn\n→ học lại mô hình trên toàn bộ nhãn tích lũy',18,True)
rect(s,8.57,4.87,4.21,1.20,WHITE,LIGHT,True);txt(s,8.79,5.08,3.77,.82,'③ Fidelity: đo chất lượng\ngiải thích của mô hình tĩnh',18,True)
callout(s,'PID xử lý dung hợp • AL cải thiện lựa chọn mẫu • Fidelity đánh giá lời giải thích.',size=18)
notes(s,'Kiến trúc hệ thống','Đầu tiên mô hình tĩnh cho xác suất. Cổng bất định xác định mẫu nào cần phân tích động. Khi có cả hai tín hiệu, PID xác định trọng số dung hợp. Song song, AL chọn mẫu để chuyên gia hoặc oracle cung cấp nhãn, rồi học lại mô hình trên tập nhãn tích lũy. Khung Fidelity đánh giá giải thích của mô hình tĩnh đang được sử dụng.','luuvan.pdf §3.1–3.4')

# 4 — PID, faithfully attributed manuscript table
s=base('03 / Đóng góp 1 — PID Fusion','PID điều chỉnh trọng số giữa hai nguồn dự đoán','Bổ sung trạng thái và phản ứng theo tín hiệu vào cơ chế dung hợp tĩnh–động.',source='Nguồn bảng: luuvan.pdf, Bảng 4.5, tr.53 — số liệu báo cáo trong bản thảo; đối soát tại phiếu công việc đính kèm, mục 1.')
rect(s,.55,2.33,4.66,3.72,WHITE,LIGHT,True)
txt(s,.78,2.57,4.18,.45,'Cơ chế đề xuất',22,True,TEAL)
txt(s,.78,3.23,4.15,.91,'p = wₛpₛ + (1 − wₛ)p_d\nwₛ = clip(sigmoid(u), 0,1; 0,9)',19,True)
txt(s,.78,4.44,4.15,1.29,'P: bất đồng hiện tại\nI: tích lũy qua chuỗi\nD: biến thiên của bất đồng',18,False)
txt(s,5.50,2.36,7.17,.44,'Số liệu báo cáo trong luận văn',21,True,TEAL)
table(s,5.50,3.04,7.28,['CẤU HÌNH','AUC','FPR'],[
 ('Chỉ phân tích tĩnh','0,9420','4,5%'),('Chỉ phân tích động','0,9915','0,2%'),('Trọng số cố định','0,9720','1,1%'),('Gated Fusion','0,9760','1,0%'),('PID Fusion','0,9818','0,8%')
],[3.72,1.90,1.66],row_h=.53,header_h=.47,fs=17)
callout(s,'Đối chiếu PID với trọng số cố định để xem vai trò của luật dung hợp khi có cùng hai tín hiệu.',size=17)
notes(s,'PID Fusion','Điểm khác biệt của PID là trọng số thay đổi theo tín hiệu và trạng thái, thay vì cố định cho mọi trường hợp. P phản ứng với bất đồng hiện tại; I và D đưa thông tin về chuỗi vào cơ chế. Bảng bên phải trích Bảng 4.5 đang được báo cáo trong luận văn để trình bày cấu trúc so sánh tĩnh, động và các cách fusion. Bảng này thuộc nguồn bản thảo; công việc tái lập và thay thế bảng/hình được quản lý riêng trong phiếu đính kèm. Không dùng các số này như kết quả của pilot AL hoặc Fidelity mới chạy.','luuvan.pdf §3.2; Bảng 4.5; Ke_hoach_bo_sung_thuc_nghiem.md, mục 1')

# 5 — AL method
s=base('04 / Đóng góp 2 — XAI-Guided AL','Chọn mẫu cần nhãn bằng bất định và cấu trúc SHAP','So với Uncertainty, điểm truy vấn bổ sung hai tín hiệu từ lời giải thích.',source='Nguồn: luuvan.pdf §3.3, Bảng 4.10; runner pilot_al/run_pilot.py trong gói thực nghiệm.')
for i,(title,formula,meaning) in enumerate([
 ('U — Bất định','U = 1 − 2|p − 0,5|','Mẫu gần ranh giới dự đoán'),
 ('H — Xung đột hướng','H = −Σ q log₂q','Đóng góp dương và âm cùng mạnh'),
 ('V — Phương sai SHAP','V = Var(φ₁,…,φ_d)','Độ phân tán đóng góp đặc trưng')]):
    x=.55+i*4.13;rect(s,x,2.35,3.96,2.48,WHITE,LIGHT,True);txt(s,x+.19,2.64,3.57,.53,title,21,True,TEAL);txt(s,x+.19,3.37,3.56,.64,formula,22,True);txt(s,x+.19,4.24,3.56,.43,meaning,15,False,GRAY)
rect(s,.55,5.06,12.23,.86,MINT,radius=True);txt(s,.81,5.28,11.70,.47,'S = 0,3Û + 0,4Ĥ + 0,3V̂    |    Min–max trên pool của từng vòng',21,True,TEAL)
txt(s,.64,6.20,12.0,.55,'200 nhãn ban đầu → 5 vòng × 100 nhãn → 700 nhãn để so sánh các chiến lược.',19,True)
notes(s,'Công thức chọn mẫu AL','U đo bất định từ xác suất. H là entropy của tỷ lệ tổng độ lớn SHAP dương và âm; nếu tổng bằng0 thì H bằng0. V là phương sai SHAP có dấu trên các chiều, bỏ thành phần bias. Mỗi thành phần được min-max trên pool ở vòng hiện tại. Trọng số 0,3/0,4/0,3 lấy từ cấu hình bản thảo. SHAP được tính lại bằng mô hình vừa huấn luyện của mỗi vòng. Pilot so Random, U, U+H, U+V và XAI đầy đủ ở cùng tập khởi tạo và ngân sách.','pilot_al/config.json; §3.3')

# 6 — AL evidence
s=base('05 / Kết quả đóng góp 2','Cùng 700 nhãn: XAI có AUC cao hơn Uncertainty ở 5/5 seed','Pilot bổ sung: 5 seed ghép cặp; train/pool 1.200, validation 400, test 400 mẫu.',source='Nguồn: kết quả pilot AL đã chạy — summary.json, metrics.csv, predictions.csv.gz. Bảng: trung bình ± SD qua seed.')
rect(s,.55,2.33,7.10,3.83,WHITE,LIGHT,True);s.shapes.add_picture(str(CHARTS/'al_curve.png'),Inches(.69),Inches(2.52),width=Inches(6.82))
table(s,7.88,2.33,4.90,['CHIẾN LƯỢC','AUC ± SD'],[(name,vn(av(m))+' ± '+vn(std(m))) for m,name in [('Random','Random'),('Uncertainty','U'),('U+H','U + H'),('U+V','U + V'),('XAI_full','XAI đầy đủ')]],[1.73,3.17],row_h=.57,header_h=.47,fs=16)
callout(s,'XAI so với U: ΔAUC +0,0058   |   AP: 0,9442 so với 0,9363   |   Cùng ngân sách nhãn.',size=18)
notes(s,'Kết quả AL','Đây là số đo mới của pilot trên CSV trong repository. Tại700 nhãn, XAI đầy đủ đạt AUC0,9749±0,0040; Uncertainty đạt0,9691±0,0046 và Random đạt0,9634±0,0063. Chênh lệch ghép cặp XAI trừ U là0,005787 và dương ở cả năm seed. AP cũng tăng từ0,9363 lên0,9442. Đường học thể hiện trung bình; vùng tô là±1 độ lệch chuẩn, không phải khoảng tin cậy. Bảng cắt bỏ cho biết kết quả cuối của H,V riêng và tổ hợp. Phạm vi dữ liệu, diễn giải FPR, ngân sách validation và các phép đo cần bổ sung nằm trong phiếu công việc.','pilot_al/summary.json; REPORT.md')

# 7 — Fidelity evidence
s=base('06 / Đóng góp 3 — đánh giá Fidelity','Kiểm tra SHAP bằng tác động lên dự đoán của mô hình','Đối chứng: che top-|SHAP| và che ngẫu nhiên cùng k; giá trị thay thế lấy từ train.',source='Nguồn: pilot Fidelity đã chạy, model riêng train 1.200 mẫu / test 400 mẫu; random trung bình 20 lần, mỗi k.')
rect(s,.55,2.34,7.65,3.80,WHITE,LIGHT,True);s.shapes.add_picture(str(CHARTS/'fidelity_curve.png'),Inches(.72),Inches(2.57),width=Inches(7.26))
rect(s,8.43,2.34,4.35,3.80,WHITE,LIGHT,True)
txt(s,8.65,2.61,3.90,.44,'AUC tại k = 25',21,True,TEAL)
txt(s,8.65,3.30,3.90,1.17,'Trước che: 0,9802\nTop-SHAP: 0,8185\nRandom: 0,9799',22,True)
line(s,8.65,4.83,12.51,4.83,LIGHT,1)
txt(s,8.65,5.12,3.90,.73,'EC = 0,3044\nCF = 0,5874',19,True)
callout(s,'Che top-SHAP gây suy giảm lớn hơn random: thứ hạng giải thích gắn với hành vi mô hình.',size=18)
notes(s,'Kết quả Fidelity','Khung này bổ sung cách đánh giá định lượng cho lời giải thích. Trong phép thử, che các chiều quan trọng theo SHAP làm AUC giảm mạnh hơn che ngẫu nhiên cùng số chiều. Tại k25, AUC giảm từ0,9802 xuống0,8185, trong khi random trung bình còn0,9799. Kết quả hỗ trợ thứ hạng SHAP dưới phép masking đã chọn. EC mô tả tương quan cấu trúc tương đồng giữa PE và SHAP; CF mô tả phân tách hai nhãn trong không gian giải thích. Đây là mô hình Fidelity riêng, không lấy AUC của nó trừ AUC của mô hình AL để suy ra lợi ích. Các điều chỉnh PE-aware, FF và OFS được quản lý trong tài liệu đính kèm.','pilot_fidelity/run_seed42/summary.json; luuvan.pdf §3.4')

# 8 — response to seminar
s=base('07 / Tiếp thu góp ý Seminar','Tách rõ đóng góp và bổ sung phép so sánh cho từng phần','Các nhận xét được chuyển thành nội dung trình bày, bảng đối chứng và kết quả thực nghiệm.',source='Nguồn: góp ý Seminar; luuvan.pdf §3.2–3.4, Bảng 4.5; các pilot AL và Fidelity bổ sung.')
table(s,.55,2.32,12.23,['GÓP Ý CỦA HỘI ĐỒNG','NỘI DUNG ĐÃ BỔ SUNG / LÀM RÕ','VỊ TRÍ'],[
 ('Tĩnh / động / kết hợp khác nhau gì?\nVì sao sử dụng PID?','Tách cổng bất định và luật dung hợp;\ntrình bày các mốc so sánh tĩnh–động–fusion.','§3.2, Bảng4.5\nSlide3–4'),
 ('XAI giúp AL như thế nào?\nKết quả gán nhãn cần thuyết phục hơn.','So 5 chiến lược cùng ngân sách;\n5 seed, đường học và ablation U/H/V.','Pilot AL\nSlide5–6'),
 ('AUC tăng ít có ý nghĩa gì?\nCần tách từng thành phần.','Báo chênh lệch ghép cặp, AUC±SD, AP;\nđối chiếu mỗi thành phần và tổ hợp.','ΔAUC +0,0058\nSlide6'),
 ('Độ đo giải thích có phù hợp không?','Kiểm tra top-SHAP / random; baseline train;\nđịnh nghĩa rõ EC và CF.','§3.4; pilot Fidelity\nSlide7')
],[3.81,5.79,2.63],row_h=.94,fs=16)
notes(s,'Tiếp thu góp ý Seminar','Phần này trả lời trực tiếp các nhận xét trước. Đối với PID, em làm rõ vai trò cổng và dung hợp, đồng thời trình bày các mốc trong bảng so sánh của luận văn. Đối với AL, đã có thí nghiệm mới với năm chiến lược và năm seed ở cùng ngân sách. Với câu hỏi AUC tăng ít, em đưa độ phân tán và chênh lệch ghép cặp thay vì chỉ một số cuối. Với XAI, có phép che top-SHAP và random cùng k cùng baseline. Những đầu việc kiểm chứng tiếp và hình cần thay nằm riêng trong phiếu công việc để tiếp tục hoàn thiện.','góp ý.txt; các báo cáo pilot; phiếu công việc đính kèm')

# 9 — takeaways
s=base('08 / Kết quả chính','Ba đóng góp tạo thành một quy trình có thể đánh giá','Từ kết hợp tín hiệu → lựa chọn nhãn → kiểm tra lời giải thích.',source='PID: cơ chế §3.2 và bảng báo cáo trong luận văn. AL / Fidelity: kết quả pilot bổ sung, các mô hình được đánh giá riêng.')
for i,(title,big,body) in enumerate([
 ('① PID Fusion','Dung hợp thích nghi','Thay trọng số cố định bằng\ntrọng số theo tín hiệu và trạng thái.'),
 ('② XAI-Guided AL','+0,0058 AUC','So với Uncertainty, cùng700 nhãn;\nAUC tăng ở cả5 seed của pilot.'),
 ('③ Đánh giá Fidelity','0,1616 AUC drop','Che top-SHAP k25;\nrandom cùng k chỉ giảm0,0003.')]):
    x=.55+i*4.13;rect(s,x,2.42,3.96,3.25,WHITE,LIGHT,True);txt(s,x+.20,2.74,3.54,.52,title,22,True,TEAL);txt(s,x+.20,3.63,3.54,.66,big,25,True);txt(s,x+.20,4.68,3.54,.75,body,17,False,GRAY)
callout(s,'Trọng tâm đánh giá: chất lượng phát hiện, hiệu quả sử dụng nhãn và khả năng kiểm tra giải thích.',size=18)
notes(s,'Kết luận','Ba phần bổ sung cho nhau trong quy trình: PID xử lý kết hợp tín hiệu, AL lựa chọn dữ liệu cần gán nhãn, Fidelity kiểm tra lời giải thích. Điểm số mới rõ nhất là AL tăng AUC tại cùng ngân sách qua năm seed, và thứ hạng SHAP tạo tác động lớn hơn random trong phép masking. Mỗi kết quả gắn với một phép so sánh cụ thể. Tài liệu làm việc riêng giữ các đầu việc đối soát, ảnh cần bổ sung và điều kiện thay bảng để tiếp tục hoàn thiện nội dung.','Bảng4.5; pilot_al/summary.json; pilot_fidelity/run_seed42/summary.json')

fixes={'cùng700':'cùng 700','cả5':'cả 5','giảm0':'giảm 0','k25':'k = 25','Bảng4':'Bảng 4','Slide3':'Slide 3','Slide5':'Slide 5','Slide6':'Slide 6','Slide7':'Slide 7','AUC0':'AUC 0','Tại700':'Tại 700','từ0':'từ 0','xuống0':'xuống 0','còn0':'còn 0','đạt0':'đạt 0','là0':'là 0','bằng0':'bằng 0'}
for slide in P.slides:
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    for a,b in fixes.items():run.text=run.text.replace(a,b)
    tf=slide.notes_slide.notes_text_frame
    for a,b in fixes.items():tf.text=tf.text.replace(a,b)
assert len(P.slides)==9
P.save(OUT/'Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pptx')
md=['# Lời dẫn trình bày — 9 trang','', 'Bản trình bày dự án; công việc bổ sung thực nghiệm được tách thành Ke_hoach_bo_sung_thuc_nghiem.md/PDF.','']
for i,(title,body) in enumerate(SLIDES,1):
    for a,b in fixes.items():body=body.replace(a,b)
    md.extend([f'## Slide {i}: {title}','',body,''])
(OUT/'Loi_dan_thuyet_trinh.md').write_text('\n'.join(md),encoding='utf-8')
print('Built 9 slides with notes.')
