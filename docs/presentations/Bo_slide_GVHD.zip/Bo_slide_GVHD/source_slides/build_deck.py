from pathlib import Path
from PIL import ImageFont
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement

PKG_ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent/'generated'
OUT.mkdir(parents=True,exist_ok=True)
P=Presentation(); P.slide_width=Inches(13.333); P.slide_height=Inches(7.5)
P.core_properties.title='Ba đóng góp và bằng chứng thực nghiệm'
P.core_properties.subject='Kết quả thực nghiệm và tiếp thu góp ý Seminar'
P.core_properties.author='Lưu Văn Doanh'
NAVY='102A43'; INK='17324D'; TEAL='007F7A'; MINT='E4F3EF'; GOLD='A66B16'; CREAM='FFF1D9'; BG='F3F6F9'; GRAY='526779'; LIGHT='DCE5EC'; WHITE='FFFFFF'
FONT='DejaVu Sans'
SLIDES=[]

def color(v): return RGBColor.from_string(v)
def rect(s,x,y,w,h,fill=WHITE,line=None,radius=False):
    sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=color(fill)
    if line: sh.line.color.rgb=color(line);sh.line.width=Pt(.7)
    else: sh.line.fill.background()
    if radius:
        try: sh.adjustments[0]=.1
        except Exception: pass
    return sh

def fit_size(text,w,h,size,bold):
    fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    limit_w=max(1,(w-.025)*72); limit_h=max(1,(h-.015)*72)
    for candidate in [size-i*.5 for i in range(max(1,int((size-8)*2)+1))]:
        font=ImageFont.truetype(fontpath,max(1,int(candidate*4)))
        nlines=0
        for para in text.split('\n'):
            words=para.split();current='';nlines+=1
            for word in words:
                trial=(current+' '+word).strip()
                if current and font.getlength(trial)/4>limit_w:
                    nlines+=1;current=word
                else:current=trial
        needed=nlines*candidate*1.29+3*max(0,len(text.split('\n'))-1)
        if needed<=limit_h:return candidate
    return 8

def txt(s,x,y,w,h,text,size=20,bold=False,fg=INK,align=None):
    size=fit_size(text,w,h,size,bold)
    box=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=box.text_frame;tf.clear();tf.word_wrap=True
    tf.margin_left=Inches(.01);tf.margin_right=Inches(.01);tf.margin_top=Inches(.01);tf.margin_bottom=Inches(.01)
    for i,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=line;p.font.name=FONT;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=color(fg)
        p.space_after=Pt(3);p.line_spacing=1.04
        if align is not None:p.alignment=align
    return box

def line(s,x1,y1,x2,y2,fg=TEAL,width=2,arrow=False):
    sh=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    sh.line.color.rgb=color(fg);sh.line.width=Pt(width)
    if arrow:
        el=OxmlElement('a:tailEnd');el.set('type','triangle');sh.line._get_or_add_ln().append(el)
    return sh

def chip(s,x,y,w,text,kind='done'):
    fill,fg=(MINT,TEAL) if kind=='done' else (CREAM,GOLD)
    rect(s,x,y,w,.33,fill,radius=True);txt(s,x+.09,y+.045,w-.18,.24,text,11,True,fg)

def callout(s,text,y=6.12,kind='done',size=18):
    fill,fg=(MINT,TEAL) if kind=='done' else (CREAM,GOLD)
    rect(s,.55,y,12.23,.59,fill,radius=True);txt(s,.73,y+.11,11.86,.42,text,size,True,fg)

def base(kicker,title,subtitle='',source='',backup=False):
    s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color(BG)
    rect(s,0,0,13.333,.1,TEAL)
    txt(s,.55,.29,11.8,.3,kicker.upper(),11,True,TEAL)
    txt(s,.55,.79,12.2,.76,title,29,True)
    if subtitle:txt(s,.55,1.63,12.1,.55,subtitle,16,False,GRAY)
    line(s,.55,6.98,12.78,6.98,LIGHT,1)
    txt(s,.55,7.07,11.75,.23,source or 'Lưu Văn Doanh  •  Báo cáo với GVHD  •  Luận văn thạc sĩ Kỹ thuật phần mềm',9,False,GRAY)
    n=len(P.slides);txt(s,12.03,7.06,.75,.25,f'{n:02d} / 17',10,True,TEAL)
    return s

def notes(s,title,body,source=''):
    full=body+('\n\nNguồn: '+source if source else '')
    s.notes_slide.notes_text_frame.text=full
    SLIDES.append((title,full))

def table(s,x,y,width,cols,rows,col_widths,row_h=.85,header_h=.48,fs=16):
    rect(s,x,y,width,header_h,NAVY,radius=False)
    xx=x
    for head,cw in zip(cols,col_widths):
        txt(s,xx+.12,y+.11,cw-.24,header_h-.15,head,12,True,WHITE);xx+=cw
    yy=y+header_h
    for i,row in enumerate(rows):
        rect(s,x,yy,width,row_h,WHITE if i%2==0 else 'EAF0F5')
        xx=x
        for j,(val,cw) in enumerate(zip(row,col_widths)):
            txt(s,xx+.12,yy+.14,cw-.24,row_h-.2,val,fs,j==0,INK if j!=len(row)-1 else GRAY);xx+=cw
        yy+=row_h
    return yy


# 01 — cover
s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color(NAVY)
rect(s,.62,.58,.08,5.95,TEAL)
txt(s,.94,.64,11.6,.4,'TRƯỜNG ĐẠI HỌC CÔNG NGHỆ — ĐHQGHN',13,True,'9FD4CF')
txt(s,.94,1.36,11.5,1.55,'Ba đóng góp của luận văn\nvà bằng chứng thực nghiệm',34,True,WHITE)
txt(s,.96,3.19,11.45,.6,'Điểm khác biệt • Kết quả đo • Tiếp thu góp ý Seminar',22,False,'9FD4CF')
txt(s,.96,4.18,11.4,1.04,'Hệ thống phát hiện Ransomware dựa trên Phân tích đa tầng,\ntích hợp Học tích cực & Kiểm chứng độ trung thực XAI',20,False,WHITE)
line(s,.96,5.56,12.05,5.56,'36506A',1)
txt(s,.96,5.93,11.3,.5,'Lưu Văn Doanh  |  GVHD: PGS.TS. Trương Ninh Thuận',18,True,WHITE)
txt(s,.96,6.57,11.3,.38,'Báo cáo kết quả và phạm vi kiểm chứng sau Seminar',14,False,'C8D8E5')
notes(s,'Ba đóng góp và bằng chứng thực nghiệm','Thưa thầy, nội dung và phạm vi luận văn đã được thống nhất. Hôm nay em trình bày ba điểm: giải pháp khác các hướng nghiên cứu kế thừa ở đâu; bằng chứng thực nghiệm hiện hỗ trợ được kết luận nào; và các góp ý Seminar đã được xử lý ở phần nào. Trong đợt đối soát này, em đã bổ sung pilot AL và kiểm tra SHAP chạy thật trên dữ liệu mẫu trong repository. Các kết quả này có phạm vi hạn chế và không được gộp với số cũ chưa truy nguyên được. Thời lượng 12–15 phút cho 12 slide chính; 5 slide cuối là phụ lục.','luuvan.pdf; góp ý.txt; kết quả pilot kèm bộ slide')

# 02 — related work and contributions
s=base('01 / Điểm khác biệt','Kế thừa nền tảng; bổ sung ba cơ chế cụ thể','So sánh về phương pháp; không xếp hạng AUC giữa các nghiên cứu dùng dữ liệu khác nhau.',source='Nguồn: luuvan.pdf §2.4, §3.2–3.4; [2], [3], [14], [21], [27] trong tài liệu tham khảo.')
table(s,.55,2.34,12.23,['NỀN TẢNG KẾ THỪA','PHẦN LUẬN VĂN BỔ SUNG','BẰNG CHỨNG CẦN ĐO'],[
 ('EMBER / LightGBM\nAnderson & Roth, 2018','Dung hợp điểm tĩnh–động bằng trọng số\ncó trạng thái, lấy cảm hứng từ PID.','Cùng hai tín hiệu:\nFixed / P / PI / PID'),
 ('AL + SHAP\nSettles, 2009; Lundberg & Lee, 2017','Chọn mẫu bằng bất định dự đoán,\nxung đột hướng và phương sai SHAP.','Cùng số nhãn:\nRandom / U / XAI'),
 ('Đánh giá giải thích\nYeh và cs., 2019','Cụ thể hóa kiểm tra tác động, tương đồng\nvà phân tách giải thích cho vector PE.','Top-SHAP / Random;\nđộ nhạy và ràng buộc PE')
],[3.05,5.98,3.20],row_h=1.08,fs=17)
callout(s,'Đóng góp ở cách thiết kế và kiểm chứng các thành phần; không coi PID, AL hay SHAP là thuật toán mới.',size=16)
notes(s,'Điểm khác biệt so với nghiên cứu kế thừa','EMBER cung cấp biểu diễn PE và baseline học máy; luận văn mở rộng kiến trúc bằng phân tích động có điều kiện và một quy tắc dung hợp thích nghi. PID là kiến thức điều khiển kế thừa, không phải phát minh mới của luận văn; việc ánh xạ độ bất đồng giữa hai xác suất thành trọng số là lựa chọn cần kiểm chứng. Với AL, đóng góp nằm ở điểm truy vấn dùng tín hiệu SHAP, nên phải so với uncertainty cùng ngân sách nhãn. Với XAI, luận văn cụ thể hóa các phép kiểm tra định lượng, nhưng FF/EC/CF/OFS là các định nghĩa của luận văn, không phải nguyên bộ chuẩn của Yeh và cộng sự. Em không dùng điểm AUC của bài báo trên dữ liệu khác để tuyên bố vượt nghiên cứu trước.','§2.4 tr.28–31; §3.2–3.4 tr.36–46; tài liệu tham khảo [2], [3], [14], [21], [27]')

# 03 — architecture
s=base('02 / Hệ thống tích hợp','Mỗi đóng góp tác động vào một khâu khác nhau','Cổng bất định quyết định chạy động; PID dung hợp; AL cập nhật mô hình; Fidelity kiểm tra giải thích.',source='Nguồn: luuvan.pdf §3.1–3.4; sơ đồ thiết kế được làm rõ sau Seminar.')
for x,y,w,h,title,fill in [(.55,2.62,2.22,1.14,'Tệp PE\nLightGBM → pₛ',WHITE),(3.20,2.62,2.3,1.14,'Cổng bất định\n[θ_low, θ_high]',MINT),(9.75,2.27,3.03,.83,'Quyết định tĩnh',WHITE),(6.05,3.41,2.55,1.05,'Phân tích động\n→ p_d',WHITE),(9.75,3.41,3.03,1.05,'① PID → dung hợp\n→ quyết định',MINT)]:
    rect(s,x,y,w,h,fill,LIGHT,True);txt(s,x+.14,y+.18,w-.28,h-.23,title,17,True)
line(s,2.77,3.18,3.20,3.18,arrow=True)
line(s,4.35,2.62,4.35,2.53);line(s,4.35,2.53,9.75,2.53,arrow=True)
txt(s,5.73,2.18,3.9,.29,'Ngoài vùng bất định',13,True,TEAL)
line(s,5.50,3.43,6.05,3.89,arrow=True);line(s,8.60,3.94,9.75,3.94,arrow=True)
txt(s,5.72,3.0,3.9,.29,'Trong vùng bất định',13,True,TEAL)
rect(s,.55,4.88,7.77,1.17,WHITE,LIGHT,True);txt(s,.77,5.07,7.34,.81,'② AL: mô hình → SHAP → chọn mẫu → oracle\n→ huấn luyện lại trên toàn bộ nhãn tích lũy',18,True)
rect(s,8.57,4.88,4.21,1.17,WHITE,LIGHT,True);txt(s,8.79,5.07,3.77,.81,'③ Fidelity: kiểm tra\ngiải thích của mô hình tĩnh',18,True)
callout(s,'Cải thiện chọn nhãn, chất lượng phát hiện và chất lượng giải thích phải được đánh giá riêng.',size=17)
notes(s,'Kiến trúc và vai trò ba đóng góp','Em tách rõ luồng phát hiện trực tuyến với vòng cập nhật mô hình. Mẫu ngoài vùng bất định có thể được xử lý bằng mô hình tĩnh; mẫu trong vùng bất định được phân tích động rồi dung hợp. PID không quyết định trực tiếp việc kích hoạt sandbox. AL chạy theo vòng: oracle cung cấp nhãn, sau đó mô hình được học lại; AL không tự sinh ra nhãn đúng. Fidelity ở đây kiểm tra giải thích của mô hình tĩnh. Vì SHAP đang giải thích LightGBM, không nên gọi đó là giải thích đầy đủ toàn bộ quyết định PID.','§3.1–3.4; đối chiếu sơ đồ slide Seminar cũ')

# 04 — PID
s=base('03 / Đóng góp 1 — PID Fusion','PID bổ sung khả năng điều chỉnh trọng số có trạng thái','Lý do lựa chọn là giả thuyết kỹ thuật; hiệu quả giảm FPR cần phép đo ghép cặp.',source='Nguồn: luuvan.pdf §3.2, tr.36–39; src/pid_fusion.py. Chưa có kiểm chứng chất lượng bằng log động thật.')
rect(s,.55,2.34,6.01,3.57,WHITE,LIGHT,True)
txt(s,.78,2.59,5.54,.4,'Ý tưởng dung hợp',21,True,TEAL)
txt(s,.78,3.16,5.50,1.20,'eₜ = pₛ,ₜ − p_d,ₜ\nuₜ = Kₚeₜ + KᵢΣe + K_dΔe\nwₜ = clip(sigmoid(uₜ), 0,1; 0,9)',21,True)
txt(s,.78,4.77,5.48,.82,'p_final = wₜpₛ + (1 − wₜ)p_d\n⇒ p_final ∈ [0,1]',22,True)
rect(s,6.80,2.34,5.98,3.57,WHITE,LIGHT,True)
txt(s,7.03,2.59,5.52,.4,'Vai trò và giới hạn',21,True,TEAL)
txt(s,7.03,3.15,5.49,2.48,'P: phản ứng với bất đồng hiện tại.\nI: tích lũy bất đồng qua chuỗi.\nD: phản ứng với biến thiên.\n\nBất đồng không cho biết mô hình nào đúng. Trọng số hợp lệ không bảo đảm AUC hoặc FPR tốt hơn.',18,False,INK)
callout(s,'Hiện đã có nguyên mẫu; chưa đủ bằng chứng thực nghiệm để kết luận PID cải thiện phát hiện.',kind='todo',size=17)
notes(s,'Đóng góp PID: ý nghĩa toán và mức đã kiểm chứng','Công thức trên là dạng rời rạc khái quát đang dùng trong nguyên mẫu, với bước thời gian đơn vị; cần khóa phiên bản có hay không có Δt, anti-windup và cách reset để khớp bản thảo. Vì trọng số nằm trong [0,1] và hai đầu vào là xác suất, đầu ra nằm trong [0,1] do tính chất tổ hợp lồi. Đây là điều chứng minh được về miền giá trị. Không thể từ đó suy ra giảm FPR: sai số e chỉ đo bất đồng, không phải sai số đối với nhãn đúng. I và D còn phụ thuộc thứ tự mẫu, nên phải định nghĩa chuỗi hoặc phiên hợp lý. Bảng 4.5 hiện chưa có log thực đủ để tái lập; log demo trong repo sinh điểm động và độ trễ bằng ngẫu nhiên. Em giữ đóng góp ở mức nguyên mẫu dung hợp cần đánh giá. Đối chứng tối thiểu là cùng các cặp điểm tĩnh–động, giữ cổng và ngưỡng chọn bằng validation, so Fixed, P, PI, PID; static-only và dynamic-only là mốc riêng. Không tuyên bố PID vượt phân tích động ở mọi tiêu chí.','§3.2; src/pid_fusion.py; scripts/live_defense_demo.py; Danh_gia_bang_chung.md kèm bộ slide')

# 05 — experimental basis
s=base('04 / Cơ sở thực nghiệm mới','Pilot nhỏ, có đối chứng và lưu được dấu vết chạy','Huấn luyện mới trên CSV hiện có; không dùng mô hình đã huấn luyện sẵn để thay số trong luận văn.',source='Nguồn: data/processed/real_mini_dataset.csv; cấu hình và split được lưu trong thư mục experiments/ của ZIP.')
for i,(num,label,desc) in enumerate([('2.000','Mẫu trong repository','2.381 đặc trưng\n1.500 nhãn 0 / 500 nhãn 1'),('1.200 / 400 / 400','Train–pool / Val / Test','Split phân tầng cố định\nMọi ngưỡng chọn trên Val'),('5 × 5 × 6','Checkpoint AL','5 chiến lược × 5 seed\n6 mức ngân sách: 200–700 nhãn')]):
    x=.55+i*4.13;rect(s,x,2.45,3.96,2.72,WHITE,LIGHT,True);txt(s,x+.19,2.72,3.57,.70,num,27,True,TEAL);txt(s,x+.19,3.65,3.56,.52,label,17,True);txt(s,x+.19,4.35,3.56,.70,desc,16,False,GRAY)
rect(s,.55,5.42,12.23,1.16,CREAM,radius=True)
txt(s,.77,5.62,11.79,.85,'Chưa xác minh nguồn và ý nghĩa nhãn ransomware của CSV.\nĐây là kiểm chứng nội bộ trên vector PE; chưa là đánh giá khái quát theo họ hoặc thời gian.',17,True,GOLD)
notes(s,'Phạm vi dữ liệu và giao thức pilot','Dữ liệu có 2.000 dòng, không thiếu giá trị và không có hai vector trùng hệt, nhưng không có hash tệp, thời gian hoặc họ mã độc. Vì vậy chưa xác minh được nguồn, quan hệ cùng họ, cũng như nhãn 1 có riêng ransomware hay malware nói chung. Em chỉ gọi đây là nhãn 0/1 của bộ dữ liệu mẫu. Việc huấn luyện mới tránh dùng mô hình có sẵn có thể từng thấy những mẫu này; tuy nhiên split ngẫu nhiên trong CSV không loại trừ sự gần trùng hoặc liên quan theo họ. Train/pool1200, validation400, test400 dùng chung cho mọi phương pháp. AL bắt đầu200 nhãn, năm vòng thêm100, tổng cuối700; năm seed thay đổi tập khởi tạo và ngẫu nhiên mô hình. Độ lệch chuẩn qua seed không phải khoảng tin cậy cho quần thể triển khai. Tập test có300 nhãn0, nên một FP tương ứng khoảng0,333 điểm phần trăm FPR.','experiments/pilot_al/config.json, splits.json, metrics.csv; experiments/pilot_fidelity/')

# 06 — AL mechanism
s=base('05 / Đóng góp 2 — XAI-Guided AL','Dùng cấu trúc giải thích để xếp hạng mẫu cần nhãn','So với Uncertainty: bổ sung xung đột hướng và độ phân tán đóng góp của đặc trưng.',source='Nguồn: luuvan.pdf §3.3, Bảng 4.10; pilot_al/run_pilot.py. SHAP được tính lại bằng mô hình của từng vòng.')
for i,(name,definition,meaning) in enumerate([
 ('U — bất định','U = 1 − 2|p − 0,5|','Mẫu gần ranh giới dự đoán'),
 ('H — hướng SHAP','H = −q₊log₂q₊ − q₋log₂q₋','Hai hướng đóng góp cùng mạnh'),
 ('V — phương sai','V = Var(φ₁,…,φ_d)','Đóng góp phân tán không đều')]):
    x=.55+i*4.13;rect(s,x,2.39,3.96,2.49,WHITE,LIGHT,True);txt(s,x+.19,2.66,3.55,.48,name,22,True,TEAL);txt(s,x+.19,3.38,3.56,.65,definition,19,True);txt(s,x+.19,4.26,3.56,.4,meaning,15,False,GRAY)
rect(s,.55,5.10,12.23,.85,MINT,radius=True);txt(s,.81,5.31,11.7,.46,'S = 0,3Û + 0,4Ĥ + 0,3V̂    |    Min–max trên pool hiện tại',22,True,TEAL)
txt(s,.60,6.18,12.1,.50,'Ablation: Random • U • U+H • U+V • XAI đầy đủ — cùng số nhãn và cùng lịch học lại.',17,True)
notes(s,'Điểm chọn mẫu và đối chứng thành phần','U đo bất định dự đoán. Với H, q cộng là tổng SHAP dương chia tổng độ lớn SHAP, q trừ là tổng độ lớn phần âm chia cùng mẫu số; mẫu có tổng bằng0 được gán H bằng0. H lớn biểu thị bằng chứng đối nghịch cùng mạnh, không phải xác suất mô hình sai. V là phương sai của SHAP có dấu trên các đặc trưng, trong đơn vị log-odds của mô hình LightGBM; nó không mặc nhiên là bất định nhận thức. Mỗi thành phần được chuẩn hóa min-max trên pool hiện tại, trường hợp hằng số gán0. Trọng số0,3/0,4/0,3 lấy từ cấu hình bản thảo, không tìm lại bằng test. Khi cắt bỏ H hoặc V, chuẩn hóa lại tổng trọng số của các thành phần còn lại về1. Native TreeSHAP dùng model hiện tại, không fallback mô phỏng. Oracle trong pilot tra nhãn có sẵn sau khi đã chọn mẫu; thời gian gán nhãn chuyên gia chưa được đo.','§3.3 tr.39–43; Bảng4.10; experiments/pilot_al/run_pilot.py')

# Results are read directly from measured artifacts, not entered as target values.
import json
import os
os.environ.setdefault('MPLCONFIGDIR', str(OUT/'.mpl_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
AL=json.loads((PKG_ROOT/'experiments/pilot_al/summary.json').read_text())
FI=json.loads((PKG_ROOT/'experiments/pilot_fidelity/run_seed42/summary.json').read_text())
def vn(v,n=4):return f'{v:.{n}f}'.replace('.',',')
def avg(m,k='test_auc',n=4):return vn(AL['methods'][m][k]['mean'],n)
def sd(m,k='test_auc',n=4):return vn(AL['methods'][m][k]['std'],n)
def paired(m,b,k):return next(v for v in AL['paired_differences'] if v['method']==m and v['baseline']==b and v['metric']==k)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#17324D','text.color':'#17324D','xtick.color':'#526779','ytick.color':'#526779'})
fig,ax=plt.subplots(figsize=(7.5,3.8),layout='constrained'); fig.patch.set_facecolor('#FFFFFF');ax.set_facecolor('#FFFFFF')
for method,c,label in [('Random','#8B98A5','Random'),('Uncertainty','#3279AD','Uncertainty'),('XAI_full','#007F7A','XAI đầy đủ')]:
    cr=AL['curves'][method]; x=np.array([v['n_labeled'] for v in cr]);y=np.array([v['test_auc']['mean'] for v in cr]);err=np.array([v['test_auc']['std'] for v in cr])
    ax.plot(x,y,'o-',label=label,color=c,lw=2.4,ms=5)
    if method!='Random':ax.fill_between(x,y-err,y+err,color=c,alpha=.11)
ax.set_xlabel('Tổng số nhãn huấn luyện');ax.set_ylabel('ROC-AUC trên test');ax.set_xticks(x);ax.grid(alpha=.18);ax.legend(loc='lower right',fontsize=10)
fig.savefig(OUT/'al_curve.png',dpi=190);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.3,3.4),layout='constrained');fig.patch.set_facecolor('#FFFFFF')
base_auc=FI['baseline_test_roc_auc'];ks=[0]+[v['k'] for v in FI['faithfulness_deletion_comparisons']]
ax.plot(ks,[base_auc]+[v['top_shap_auc_after'] for v in FI['faithfulness_deletion_comparisons']],'o-',color='#007F7A',lw=2.6,label='Che top-|SHAP|')
ax.plot(ks,[base_auc]+[v['random_auc_after_mean'] for v in FI['faithfulness_deletion_comparisons']],'o--',color='#8B98A5',lw=2.4,label='Che ngẫu nhiên (TB 20 lần)')
ax.set_xlabel('Số chiều được chọn để che (k)');ax.set_ylabel('ROC-AUC sau che');ax.set_xticks(ks);ax.grid(alpha=.18);ax.legend(loc='lower left',fontsize=10)
fig.savefig(OUT/'fidelity_curve.png',dpi=190);plt.close(fig)

# 07 — AL measured result
s=base('06 / Kết quả AL — đã chạy','Cùng 700 nhãn: XAI vượt Uncertainty về AUC ở cả 5 seed','Trung bình ± độ lệch chuẩn qua 5 seed, dùng chung một tập test cố định.',source='Nguồn: experiments/pilot_al/summary.json, metrics.csv và predictions.csv.gz; pilot, chưa xác minh nguồn CSV.')
rect(s,.55,2.31,7.53,3.91,WHITE,LIGHT,True);s.shapes.add_picture(str(OUT/'al_curve.png'),Inches(.69),Inches(2.46),width=Inches(7.18))
rect(s,8.31,2.31,4.47,3.91,WHITE,LIGHT,True)
txt(s,8.54,2.58,4.02,.35,'ROC-AUC TẠI 700 NHÃN',13,True,TEAL)
txt(s,8.54,3.13,4.02,.70,f"{avg('XAI_full')} ± {sd('XAI_full')}",26,True,TEAL)
txt(s,8.54,3.82,4.02,.4,'XAI đầy đủ',17,True)
txt(s,8.54,4.38,4.02,.68,f"{avg('Uncertainty')} ± {sd('Uncertainty')}",24,True)
txt(s,8.54,5.06,4.02,.39,'Uncertainty',17,True)
txt(s,8.54,5.64,4.02,.36,f"Δ AUC ghép cặp: +{vn(paired('XAI_full','Uncertainty','test_auc')['mean_difference'])}",16,True,TEAL)
txt(s,.61,6.43,12.0,.37,'Kết quả ủng hộ điểm chọn mẫu trong pilot; chưa suy ra tiết kiệm nhãn hay hiệu quả trên ransomware mới.',16,True)
notes(s,'AL: kết quả cải thiện tại cùng ngân sách',f"Ở ngân sách cuối700 nhãn, XAI đầy đủ đạt AUC{avg('XAI_full')}±{sd('XAI_full')}, Uncertainty{avg('Uncertainty')}±{sd('Uncertainty')}, Random{avg('Random')}±{sd('Random')}. Chênh lệch XAI trừ Uncertainty là{vn(paired('XAI_full','Uncertainty','test_auc')['mean_difference'],6)}±{vn(paired('XAI_full','Uncertainty','test_auc')['sd_difference'],6)} qua năm seed ghép cặp; cả năm chênh lệch đều dương. Đây là một tín hiệu thực nghiệm thuận lợi, chưa phải khẳng định có ý nghĩa thống kê cho triển khai vì cùng một test và dữ liệu nguồn chưa xác minh. AP tương ứng XAI{avg('XAI_full','test_ap')} và Uncertainty{avg('Uncertainty','test_ap')}. Phần tô trên biểu đồ là±1 độ lệch chuẩn của seed, không phải khoảng tin cậy95%. Nhãn trên trục chỉ gồm200 nhãn huấn luyện ban đầu và nhãn truy vấn; không tính400 nhãn validation dùng chung. Không suy ra tiết kiệm90% nhãn hoặc phát hiện zero-day từ pilot này.",'experiments/pilot_al/summary.json; curves, paired_differences; source runner kèm ZIP')

# 08 — AL ablation and overhead
s=base('07 / Cắt bỏ AL và chi phí','Kết hợp H và V cho AUC trung bình cao nhất; FPR còn biến động','Ngưỡng của từng mô hình chọn trên validation với TPR ≥ 95%; TPR test được báo riêng.',source='Nguồn: pilot_al/metrics.csv và summary.json; số là trung bình 5 seed tại 700 nhãn, cùng test 400 mẫu.')
rows=[]
for m,name in [('Random','Random'),('Uncertainty','U'),('U+H','U + H'),('U+V','U + V'),('XAI_full','U + H + V')]:
    rows.append((name,f"{avg(m)} ± {sd(m)}",vn(AL['methods'][m]['test_fpr']['mean']*100,2)+'%',vn(AL['methods'][m]['test_tpr']['mean']*100,2)+'%'))
table(s,.55,2.32,8.35,['CHIẾN LƯỢC','AUC ± SD','FPR','TPR'],rows,[1.66,3.35,1.67,1.67],row_h=.58,header_h=.46,fs=16)
rect(s,9.12,2.32,3.66,3.37,WHITE,LIGHT,True)
txt(s,9.34,2.57,3.20,.41,'Chi phí tính điểm',20,True,TEAL)
txt(s,9.34,3.22,3.18,.98,f"XAI: {vn(AL['methods']['XAI_full']['score_seconds_per_round']['mean']*1000,1)} ms/vòng\nU: {vn(AL['methods']['Uncertainty']['score_seconds_per_round']['mean']*1000,1)} ms/vòng",22,True)
txt(s,9.34,4.49,3.18,.94,'Pool 600–1.000 mẫu\n2 CPU threads\nChưa gồm gán nhãn / học lại',15,False,GRAY)
callout(s,'FPR của XAI chỉ thấp hơn U ở 2/5 seed: chưa kết luận giảm cảnh báo nhầm ổn định.',kind='todo',size=17)
notes(s,'AL: cắt bỏ tín hiệu và chi phí thực',f"Bảng dùng cùng ngân sách700 nhãn và cùng các tập dữ liệu. H hoặc V riêng lẻ không tạo cải thiện AUC rõ so với U ở ngân sách cuối; tổ hợp đầy đủ đạt AUC trung bình cao nhất trong các cấu hình đã thử. Không gọi đây là bằng chứng tương tác nhân quả hay cấu hình tối ưu toàn cục. Về FPR, XAI trung bình17,53% và U19,87%, nhưng chênh lệch ghép cặp−2,33 điểm phần trăm có độ lệch chuẩn6,62 điểm phần trăm và chỉ giảm ở2/5 seed. TPR tương ứng95,4% và95,6%; đó không phải so sánh tại chính xác cùng TPR test. FPR17% cũng không phải mức phù hợp vận hành thực tế. Timing tính điểm trung bình cho pool600–1000 mẫu là{vn(AL['methods']['XAI_full']['score_seconds_per_round']['mean']*1000,2)}ms với XAI và{vn(AL['methods']['Uncertainty']['score_seconds_per_round']['mean']*1000,2)}ms với U. Phần tính điểm bao gồm dự đoán, TreeSHAP, kiểm tra additivity và chuẩn hóa, chưa gồm sắp xếp chọn mẫu, lưu file, chuyên gia gán nhãn hay huấn luyện. TreeSHAP riêng khoảng{vn(AL['methods']['XAI_full']['tree_shap_seconds_per_round']['mean']*1000,2)}ms. Timing trên máy này mang tính mô tả, không phải độ trễ toàn hệ thống hoặc chi phí SOC. Không dùng tỷ lệ thời gian để suy ra hiệu năng ở pool lớn.",'experiments/pilot_al/metrics.csv, summary.json; README.md')

# 09 — Fidelity contribution/adaptation
s=base('08 / Đóng góp 3 — kiểm tra giải thích','Chuyển nguyên tắc XAI sang PE phải kiểm tra phép biến đổi','Pilot hiện kiểm tra vector đặc trưng; phần ràng buộc cấu trúc PE cần đánh giá tiếp.',source='Nguồn: luuvan.pdf §3.4, A.4; Yeh và cs. (2019); pilot_fidelity/run_pilot.py.')
table(s,.55,2.34,12.23,['PHÉP KIỂM TRA','ĐIỀU CHỈNH / CẤU HÌNH ĐÃ CHẠY','KẾT LUẬN CHO PHÉP'],[
 ('Tác động đặc trưng','Che top-|SHAP| so với che ngẫu nhiên\ncùng k; baseline lấy từ train.','Thứ hạng SHAP liên quan\nđặc trưng mô hình sử dụng.'),
 ('Tương đồng — EC','Tương quan cấu trúc tương đồng PE\nvà SHAP; chuẩn hóa chỉ fit trên train.','Mức nhất quán với một\nđịnh nghĩa khoảng cách cụ thể.'),
 ('Phân tách — CF','Khoảng cách hai tâm SHAP, chuẩn hóa\nbằng chuẩn SHAP lớn nhất trong test.','Độ phân tách hai nhãn;\nkhông phải tính nhân quả.')
],[2.66,6.22,3.35],row_h=1.07,fs=17)
callout(s,'Mean masking có thể phá quan hệ giữa trường PE; pilot chưa chứng minh “PE-aware” hoàn chỉnh.',kind='todo',size=17)
notes(s,'Fidelity: phù hợp miền và giới hạn','Khác với các pixel, đặc trưng PE có nhóm histogram, thông tin tệp, header, section, imports/exports và data directories với kiểu dữ liệu và ràng buộc phụ thuộc khác nhau. Một vector bất kỳ sau che không nhất thiết tương ứng tệp PE hợp lệ. Pilot này dùng mean baseline từ train và che chiều riêng lẻ, đối chứng random cùng k; đó là phép kiểm tra ban đầu minh bạch, chưa phải toàn bộ chính sách masking theo nhóm được mô tả tại§3.4.4. Phép đo AUC drop là kiểm tra tác động, không đổi tên thành chỉ số FF đã chuẩn hóa. EC dùng Pearson giữa các phần tử tam giác trên hai ma trận cosine; đặc trưng fit mean/std trên train. CF đúng mẫu số max chuẩn SHAP từng mẫu trong công thức3.17. EC, CF có ý nghĩa riêng, chưa thể coi điểm cao là giải thích đúng. OFS chưa được dùng vì định nghĩa và miền giá trị thành phần chưa thống nhất với code.','§3.4 tr.43–46, Phụ lụcA.4 tr.77–78; experiments/pilot_fidelity/README.md')

# 10 — Fidelity results
s=base('09 / Kết quả Fidelity — đã chạy','Che đặc trưng SHAP quan trọng gây suy giảm lớn hơn random','Mô hình mới: 1.200 mẫu train, test 400 mẫu; baseline trước che AUC = '+vn(base_auc)+'.',source='Nguồn: pilot_fidelity/run_seed42/summary.json, mask_predictions.csv; random lặp 20 lần cho mỗi k.')
rect(s,.55,2.33,7.65,3.82,WHITE,LIGHT,True);s.shapes.add_picture(str(OUT/'fidelity_curve.png'),Inches(.70),Inches(2.52),width=Inches(7.32))
r25=FI['faithfulness_deletion_comparisons'][1]
rect(s,8.43,2.33,4.35,3.82,WHITE,LIGHT,True)
txt(s,8.65,2.58,3.90,.42,'Tại k = 25',22,True,TEAL)
txt(s,8.65,3.22,3.90,1.20,f"Top-SHAP: {vn(r25['top_shap_auc_after'])}\nRandom: {vn(r25['random_auc_after_mean'])}",24,True)
txt(s,8.65,4.77,3.90,.65,f"EC = {vn(FI['ec_thesis_cosine_similarity_matrix_correlation'])}\nCF = {vn(FI['cf_thesis_centroid_separation'])}",18,True)
txt(s,8.65,5.57,3.90,.35,'Không tổng hợp OFS',15,False,GRAY)
callout(s,'Kết quả hỗ trợ thứ hạng SHAP dưới phép che đã chọn; chưa chứng minh giải thích nhân quả.',size=17)
notes(s,'Fidelity: kết quả đo và diễn giải',f"Mô hình Fidelity được huấn luyện riêng với100 cây trên toàn bộ1200 mẫu train, khác mô hình AL60 cây và700 nhãn. Vì vậy không lấy AUC hai thí nghiệm trừ nhau để đo đóng góp. Trước che AUC{vn(base_auc,6)}. Tại k25, che top-|SHAP| cho AUC{vn(r25['top_shap_auc_after'],6)}, tức giảm{vn(r25['top_shap_auc_drop'],6)}; random20 lần cho trung bình{vn(r25['random_auc_after_mean'],6)}, giảm{vn(r25['random_auc_drop_mean'],6)}. Hiệu ứng này cũng xuất hiện ởk10 và50. Đây là sanity check cho thứ hạng SHAP đối với mô hình hiện tại; random có thể chọn chiều mô hình không dùng, và cùng k không bảo đảm số chiều thật sự thay đổi hay mức perturbation giống nhau. EC{vn(FI['ec_thesis_cosine_similarity_matrix_correlation'],6)} và CF{vn(FI['cf_thesis_centroid_separation'],6)} là các giá trị mô tả, chưa có baseline để phân loại tốt/xấu. Công thức FF chia cho xác suất gốc cho giá trị thô2,0045 tại k25, lớn hơn1; em không tự clip hay thay định nghĩa để tạo điểm đẹp. Chưa xuất OFS. Khoảng bootstrap trong báo cáo kèm theo chỉ có điều kiện trên một mô hình đã fit, không tính biến động huấn luyện.",'experiments/pilot_fidelity/README.md; summary.json; mask_metrics.csv; mask_predictions.csv')

# 11 — committee mapping
s=base('10 / Tiếp thu góp ý Seminar','Mỗi nhận xét được gắn với nội dung và bằng chứng cụ thể','“Đã mô tả” và “đã đo trong pilot” là hai mức hoàn thiện khác nhau.',source='Nguồn: góp ý.txt; luuvan.pdf (trang in); hai pilot thực nghiệm bổ sung kèm ZIP.')
table(s,.55,2.27,12.23,['HỘI ĐỒNG YÊU CẦU','ĐÃ LÀM / VỊ TRÍ','MỨC BẰNG CHỨNG HIỆN TẠI'],[
 ('Vì sao cần PID; có/không PID?','Giải thích vai trò, công thức, giới hạn\n§3.2, tr.36–39; slide 4.','Đã mô tả; còn thiếu điểm động thật\nvà so Fixed / P / PI / PID.'),
 ('XAI-AL tạo khác biệt gì?','Chạy 5 chiến lược × 5 seed\nSlide 6–8; pilot_al/.','Đã đo: AUC tăng ở cùng700 nhãn;\nchưa chứng minh tiết kiệm nhãn.'),
 ('Độ đo có phù hợp với PE?','Baseline train; đối chứng random\n§3.4; slide 9–10; pilot_fidelity/.','Đã đo masking vector; còn thiếu\nkiểm tra ràng buộc nhóm PE.'),
 ('AUC tăng ít; chi phí thực tế?','Báo SD, AP, FPR/TPR và timing\nSlide 7–8; metrics.csv.','Có số đo pilot; chưa có latency\nend-to-end và chi phí chuyên gia.'),
 ('Kết hợp cả hệ thống được gì?','Thiết kế ablation PID × AL\nPhụ lục C — slide15.','Chưa đủ dữ liệu để đo tác động\nkết hợp; không dùng số giả lập.')
],[3.09,4.54,4.60],row_h=.79,header_h=.46,fs=15)
notes(s,'Việc đã hoàn thiện theo góp ý Seminar','Em trả lời từng góp ý bằng vị trí có thể kiểm tra. Về PID, bản thảo có phần cơ chế và giới hạn, nhưng chưa đánh dấu hoàn tất chứng minh hiệu quả. Về AL, đợt này đã bổ sung runner không fallback, năm chiến lược cùng ngân sách, năm seed, dự đoán và log truy vấn; đây là tiến bộ thực nghiệm cụ thể so với bảng thiếu dấu vết chạy. Về Fidelity, đã có random control và baseline train, đồng thời làm rõ vấn đề công thức FF/OFS và giới hạn masking vector. Về mức cải thiện nhỏ, em báo độ phân tán và FPR/TPR thực tế, không chỉ chọn AUC đẹp nhất. Phần tích hợp toàn hệ thống chưa chạy vì thiếu dữ liệu động thực ghép từng mẫu. Những nội dung đã có ở bản thảo chỉ được gọi là đã trình bày, không khẳng định chính tôi đã chỉnh sửa file PDF trong lần làm việc này.','góp ý.txt; §3.2–3.4; kết quả pilot trong experiments/; đánh giá bằng chứng kèm ZIP')

# 12 — takeaways
s=base('11 / Kết luận báo cáo','Đã có bằng chứng mới cho AL và kiểm tra SHAP','Mức kết luận bám theo thí nghiệm đã chạy; phần PID cần một gói đo bổ sung tập trung.',source='Nguồn: kết quả đã truy vết; kế hoạch đo bổ sung nằm ở Phụ lục C và báo cáo đánh giá bằng chứng.')
for i,(name,number,claim,status) in enumerate([
 ('① PID Fusion','Nguyên mẫu có sẵn','Trọng số hợp lệ và\ncơ chế có trạng thái.','Cần điểm động thật +\nđối chứng cùng đầu vào.'),
 ('② XAI-Guided AL','ΔAUC +'+vn(paired('XAI_full','Uncertainty','test_auc')['mean_difference']),'Cải thiện so với U\nở cả5 seed của pilot.','Chưa chứng minh giảm FPR\nổn định / tiết kiệm nhãn.'),
 ('③ Fidelity','AUC drop '+vn(r25['top_shap_auc_drop']),'Top-SHAP k25 tác động\nmạnh hơn random.','Cần ràng buộc nhóm PE\nvà thống nhất công thức.')]):
    x=.55+i*4.13;rect(s,x,2.38,3.96,3.80,WHITE,LIGHT,True);txt(s,x+.2,2.63,3.54,.45,name,22,True,TEAL);txt(s,x+.2,3.27,3.54,.6,number,23,True);txt(s,x+.2,4.06,3.54,.82,claim,18,False);line(s,x+.2,5.05,x+3.75,5.05,LIGHT,1);txt(s,x+.2,5.30,3.54,.70,status,16,True,GRAY)
callout(s,'Phần còn lại: xác minh nguồn dữ liệu → đo PID và bảng 2×2 → đồng bộ số liệu, công thức, code.',size=17)
notes(s,'Kết luận theo phạm vi đã chứng minh','Báo cáo đã làm rõ điểm khác biệt của ba thành phần và bổ sung bằng chứng thật cho hai phần có thể chạy trên dữ liệu hiện tại. AL cho kết quả thuận lợi về AUC ở cùng ngân sách, nhưng chưa chứng minh ưu thế vận hành hoặc tiết kiệm nhãn. Fidelity cho thấy việc che các đặc trưng SHAP xếp quan trọng làm suy giảm chất lượng nhiều hơn random trong phép thử đã chọn. PID còn là giả thuyết kỹ thuật có nguyên mẫu; hiệu quả cần tín hiệu động thực và đối chứng ghép cặp. Việc cần làm tiếp được giới hạn: truy nguyên dữ liệu, hoàn tất gói PID cùng bảng2×2, rồi đồng bộ công thức–code–bảng. Không đưa số liệu đẹp nhưng chưa truy nguyên vào kết luận, và không tự kết luận toàn bộ luận văn đã đủ điều kiện bảo vệ chỉ dựa trên pilot.','Danh_gia_bang_chung.md; Ket_qua_bo_sung.md; experiments/')

# 13 — old fusion numbers, audit only
s=base('Phụ lục A / Đối soát số trong bản thảo','Bảng 4.5 chưa đủ căn cứ dùng làm kết quả đã xác nhận','Các số dưới đây chỉ trích nguyên bản thảo; không phải kết quả tái chạy của đợt rà soát.',source='Nguồn: luuvan.pdf Bảng4.5, tr.53; scripts/run_experiments.py; scripts/live_defense_demo.py.',backup=True)
table(s,.55,2.32,7.55,['CẤU HÌNH','AUC','FPR','ĐỘ TRỄ GHI TRONG BẢNG'],[
 ('Static','0,9420','4,5%','2,1 ms — tĩnh'),('Dynamic','0,9915','0,2%','1.205,4 ms — động'),('Fixed-weight','0,9720','1,1%','16,4 ms — fusion'),('Gated','0,9760','1,0%','13,8 ms — fusion'),('PID','0,9818','0,8%','15,2 ms — fusion')
],[2.15,1.27,1.09,3.04],row_h=.60,fs=16)
rect(s,8.34,2.32,4.44,3.70,CREAM,radius=True)
txt(s,8.56,2.58,3.98,.78,'Chưa dùng để khẳng định mức cải thiện',22,True,GOLD)
txt(s,8.56,3.70,3.98,1.98,'Script có kết quả gán sẵn.\nLog demo sinh điểm động và độ trễ ngẫu nhiên.\nThiếu dự đoán từng mẫu và nguồn dữ liệu ghép cặp.',17,False,INK)
callout(s,'15,2 ms fusion không phải latency end-to-end; không so trực tiếp với 1.205,4 ms phân tích động.',kind='todo',size=16)
notes(s,'Đối soát bảng fusion cũ','Bảng này được giữ trong phụ lục để thầy thấy chính xác số nào đang có vấn đề, không dùng làm bằng chứng tăng chất lượng. Nếu phép đo được truy nguyên, PID so fixed-weight có ΔAUC0,0098 và FPR giảm0,3 điểm phần trăm. Nhưng trong hiện trạng chưa có log đủ để xác nhận đó là kết quả đo của cùng dữ liệu và giao thức. Static so toàn hệ thống còn thêm nguồn thông tin động, không cô lập đóng góp PID. Chính bảng cũ cũng cho dynamic AUC cao hơn và FPR thấp hơn PID, nên không thể nói PID tốt nhất mọi tiêu chí. Độ trễ fusion và độ trễ dynamic đo hai phần khác nhau; muốn nói về vận hành phải đo end-to-end, tỉ lệ kích hoạt dynamic, p50/p95 và timeout.','Bảng4.5 tr.53; Danh_gia_bang_chung.md')

# 14 — old AL and fidelity audit
s=base('Phụ lục B / Đối soát kết luận','Các diễn giải cần sửa trước khi dùng lại số cũ','Không tự thay số chưa truy nguyên bằng AUC cao hơn từ mô hình có sẵn.',source='Nguồn: luuvan.pdf Bảng4.6–4.9; results/fidelity_results.csv; model_check.json.',backup=True)
table(s,.55,2.33,12.23,['NỘI DUNG','SỐ ĐANG CÓ','KẾT LUẬN ĐÚNG PHẠM VI'],[
 ('AL và chi phí nhãn','AUC0,9740 → 0,9818\n2.000 → 2.500 nhãn','Không đủ suy ra tiết kiệm90% nhãn.\nCần so đường học đạt cùng mục tiêu.'),
 ('Báo động nhầm','FP135 → 48 trên3.000 mẫu âm\n⇒ FPR4,5% → 1,6%','Không đồng nhất với FPR0,8% của fusion\nkhi chưa xác định đúng thí nghiệm.'),
 ('Điểm OFS','Bảng:0,3612; điều hòa từ FF/EC/CF\nđược in:≈0,3640','Code dùng0,5FF+0,3EC+0,2CF.\nCần thống nhất cả định nghĩa thành phần.'),
 ('Mô hình có sẵn','Kiểm tra trên2.000 mẫu repo:\nAUC≈0,9979','Không biết có trùng dữ liệu đã học.\nKhông dùng làm số thay thế cho luận văn.')
],[2.35,4.55,5.33],row_h=.94,fs=16)
notes(s,'Đối soát bảng AL và Fidelity cũ','Không có ý nghĩa thống kê hoặc vận hành chỉ vì AUC tăng từ0,97 lên0,98. Muốn diễn giải cần giao thức, nguồn mẫu, đối chứng và độ bất định. Ma trận FP135 xuống48 trên3000 âm cho FPR4,5% xuống1,6%; số0,8% phải được truy nguyên riêng. Bảng OFS không chỉ sai khác làm tròn: code tính trung bình cộng trọng số và định nghĩa EC/CF cũng khác PDF, nên sửa một ô không giải quyết được. Kiểm tra pretrained trên CSV ra AUC khoảng0,9979 nhưng không biết mẫu có từng nằm trong train, do đó không chọn con số đẹp hơn để thay. Pilot mới được trình bày như một thí nghiệm bổ sung với cấu hình và giới hạn riêng.','Bảng4.6 tr.54;4.7–4.8 tr.55;4.9 tr.57; evidence_audit/model_check.json')

# 15 — minimal remaining experiment
s=base('Phụ lục C / Thực nghiệm bổ sung vừa đủ','Tách tác động PID, AL và hệ thống kết hợp bằng bảng 2×2','Chỉ chạy sau khi có điểm động thực, đúng ID mẫu; mọi cấu hình dùng cùng ngân sách nhãn.',source='Thiết kế đề xuất, CHƯA CHẠY. Không điền số giả lập; Static-only và Dynamic-only là hai mốc riêng.',backup=True)
table(s,.55,2.33,7.65,['DUNG HỢP','RANDOM AL','XAI-GUIDED AL'],[
 ('Fixed-weight','F–R: đối chứng nền','F–X: tác động AL'),('PID','P–R: tác động PID','P–X: kết hợp')
],[2.08,2.78,2.79],row_h=1.06,fs=18)
rect(s,8.44,2.33,4.34,3.53,WHITE,LIGHT,True);txt(s,8.65,2.58,3.92,.45,'Gói đo tối thiểu',21,True,TEAL)
txt(s,8.65,3.22,3.92,2.26,'1. Cùng cặp pₛ, p_d và nhãn.\n2. Khóa gate, ngưỡng trên Val.\n3. So Fixed / P / PI / PID.\n4. Báo FPR–TPR, FP/FN,\n    AUC và latency p50/p95.',17,False)
txt(s,.68,5.23,7.23,.69,'Nếu nói “cộng hưởng”: cần kiểm tra tương tác\nΔ = (M_PX − M_PR) − (M_FX − M_FR).',18,True)
callout(s,'Đầu vào cần: sample_id, split, label, p_static, p_dynamic, timestamp/session và thời gian đo thật.',size=16)
notes(s,'Gói thí nghiệm tiếp theo vừa đủ','Không cần mở rộng sang nhiều kiến trúc mới. Cần bảng điểm ghép cặp từ dữ liệu động đã quan sát thật của cùng các tệp; p_dynamic không được tạo từ p_static cộng nhiễu. Nguồn và ý nghĩa nhãn phải xác nhận trước. Dùng cùng tập train/validation/test cho cả bốn cấu hình, random cũng được bổ sung cùng số nhãn để tách tiêu chí chọn mẫu khỏi tác động có thêm nhãn. Cổng và ngưỡng chỉ chọn bằng validation. Để cô lập luật dung hợp, trước hết giữ cùng mô hình tĩnh và cặp điểm rồi so Fixed,P,PI,PID; khi đo cả vòng AL, tính lại p_static bằng đúng checkpoint và báo rõ tỉ lệ kích hoạt dynamic. Trạng thái PID phải theo chuỗi có ý nghĩa, khóa thứ tự và quy tắc reset; nếu mẫu độc lập, I/D có thể chỉ phản ánh thứ tự ngẫu nhiên. M là một metric đã chọn trước; dấu cải thiện phụ thuộc metric cao tốt hay thấp tốt. Hệ thống đầy đủ tốt nhất không tự chứng minh tương tác dương. Trên test nhỏ nên báo số đếm FP/FN và khoảng bất định; không cần phô trương mức cải thiện. Nếu chưa có log động thật, chưa thể hoàn tất phần này chỉ bằng checkout hiện có.','Kế hoạch thực nghiệm và Danh_gia_bang_chung.md; chưa có kết quả cho bảng2×2')

# 16 — math metric issues
s=base('Phụ lục D / Toán học các độ đo','OFS cần thống nhất miền giá trị trước khi tổng hợp','Đề xuất trước mắt: báo các thành phần riêng và đối chứng, chưa dùng OFS để xếp hạng chung.',source='Nguồn: luuvan.pdf công thức3.15–3.18; src/fidelity_framework.py; pilot_fidelity/run_seed42/summary.json.',backup=True)
table(s,.55,2.33,12.23,['ĐỘ ĐO','VẤN ĐỀ TOÁN HỌC','ĐIỀU CHỈNH VỪA ĐỦ'],[
 ('FF','Mean |p−p_mask|/(p+ε) không bị chặn1.\nPilot k25 cho FF thô≈2,0045.','Báo AUC drop và mean |Δp| riêng;\nkhóa lại định nghĩa nếu thay FF.'),
 ('EC','Pearson r ∈[−1,1]; có thể âm.\nKhông là “tỉ lệ giải thích đúng”.','Báo r, phép tương đồng và chuẩn hóa;\nkhông coi các cặp là độc lập.'),
 ('CF','||C₁−C₀||/max||φ|| có thể tới2.\nPhân tách lớp không đồng nghĩa fidelity.','Báo như độ phân tách; nếu chuẩn hóa\nphải ghi công thức và lý do.'),
 ('OFS','Trung bình điều hòa cần thành phần\ndương, cùng hướng và thang đo phù hợp.','Chưa tổng hợp khi miền chưa thống nhất;\nkhông clip hậu nghiệm để làm đẹp số.')
],[1.20,5.75,5.28],row_h=.94,fs=16)
notes(s,'Ý nghĩa toán học và sửa độ đo','FF có thể vượt1 khi p gốc thấp mà p sau che tăng; ví dụ p0,01 và p_mask0,5 cho tỉ số xấp xỉ49. Mean absolute probability change nằm trong[0,1] và có thể báo riêng, nhưng đổi sang đó là thay định nghĩa, cần ghi rõ phiên bản và chạy lại toàn bộ bảng so sánh. EC là tương quan có thể âm; thêm epsilon không biến nó thành thành phần dương phù hợp harmonic mean. Với CF, chuẩn mỗi tâm không lớn hơn chuẩn mẫu lớn nhấtR, nên khoảng cách hai tâm có thể tới2R và tỉ số có thể tới2. CF cũng đo phân tách nhãn chứ không chứng minh quan hệ nhân quả của đặc trưng. Trung bình điều hòa có thể nhấn mạnh thành phần yếu khi cả ba cùng dương và thang đo đã hợp lý, nhưng công thức hiện chưa bảo đảm điều kiện đó. Cách sửa tiết kiệm công nhất là dùng bảng thành phần và đối chứng, để OFS ở phần thảo luận cho tới khi khóa và đánh giá độ nhạy định nghĩa; không gọi OFS là chuẩn đo chất lượng lời giải thích được cộng đồng công nhận.','Công thức3.15–3.18 tr.44; pilot_fidelity/README.md')

# 17 — source / reproducibility
s=base('Phụ lục E / Nguồn và tái lập','Số trên slide có cấu hình, dự đoán và log đi kèm','Hai pilot độc lập về mô hình; dùng chung split để dễ kiểm tra, không cộng gộp các mức cải thiện.',source='Nguồn: ZIP kèm PowerPoint/PDF; dữ liệu đầu vào nằm tại doanhnjut/thesis2026 (tên repo đúng: doanhjut/thesis2026).',backup=True)
rect(s,.55,2.33,6.09,3.66,WHITE,LIGHT,True);txt(s,.79,2.61,5.58,.42,'Dấu vết thí nghiệm',22,True,TEAL)
txt(s,.79,3.29,5.55,2.32,'AL: 150 checkpoint / 12.500 truy vấn\n120.000 dự đoán Val và Test.\n\nFidelity: 3 mức k × 20 random masks\nLưu model, SHAP, mask và dự đoán.\n\nCấu hình, split, seed, hash và mã chạy kèm ZIP.',17,False)
rect(s,6.86,2.33,5.92,3.66,WHITE,LIGHT,True);txt(s,7.10,2.61,5.43,.42,'Nghiên cứu kế thừa',22,True,TEAL)
txt(s,7.10,3.29,5.40,2.30,'Anderson & Roth (2018) — EMBER\nÅström & Hägglund (2001) — PID\nLundberg & Lee (2017) — SHAP\nSettles (2009) — Active Learning\nYeh và cs. (2019) — Infidelity / Sensitivity',17,False)
callout(s,'Chưa có hash tệp PE, họ hoặc thời gian nguồn: split theo dòng chưa thay được kiểm chứng theo họ/thời gian.',kind='todo',size=16)
notes(s,'Tái lập và nguồn trích dẫn','Bộ ZIP gồm slide chỉnh sửa được, PDF, lời dẫn, báo cáo đánh giá và mã chạy cùng các kết quả chính. Dữ liệu CSV được tham chiếu từ repository để không nhân bản dữ liệu vào mỗi bộ slide. Với AL có150 model/checkpoint,12500 truy vấn,120000 dự đoán gồm validation vàtest; file hash và hậu kiểm được lưu. Với Fidelity có mô hình riêng,3 giá trịk,20 lặp random mỗi k và đầu vào tái tính các độ đo. Tài liệu liên quan: Anderson và Roth, EMBER: An Open Dataset for Training Static PE Malware Machine Learning Models (2018); Åström và Hägglund, The Future of PID Control (2001); Lundberg và Lee, A Unified Approach to Interpreting Model Predictions (2017); Settles, Active Learning Literature Survey (2009); Yeh và cộng sự, On the (In)fidelity and Sensitivity of Explanations (2019). Các tài liệu được dùng để phân định nền tảng và phần thích nghi, không làm bằng chứng vượt AUC của nghiên cứu trước.','README.md và experiments/ trong ZIP; luuvan.pdf tài liệu tham khảo')

assert len(P.slides)==17
# Correct typography in both editable slides and speaker notes.
fixes={'k25':'k = 25','k10':'k = 10','k50':'k = 50','cùng700':'cùng 700','tiết kiệm90%':'tiết kiệm 90%','trên3.000':'trên 3.000','trên2.000':'trên 2.000','Bảng4':'Bảng 4','slide15':'slide 15','công thức3':'công thức 3','AUC0':'AUC 0','AUC≈':'AUC ≈','FPR4':'FPR 4','FPR0':'FPR 0','FP135':'FP 135','Bảng:0':'Bảng: 0','dùng0':'dùng 0','chặn1':'chặn 1','tới2':'tới 2','thô≈':'thô ≈','cả5':'cả 5','cùng700':'cùng 700','mẫu\n120.000':'mẫu\n120.000','doanhnjut/thesis2026 (tên repo đúng: doanhjut/thesis2026)':'doanhjut/thesis2026','doanhnjut/thesis2026 (tên repo đúng: doanhjut/thesis2026)':'doanhjut/thesis2026'}
for slide in P.slides:
    for shape in slide.shapes:
        if not shape.has_text_frame:continue
        for para in shape.text_frame.paragraphs:
            for run in para.runs:
                for before,after in fixes.items():run.text=run.text.replace(before,after)
path=OUT/'Dong_gop_va_bang_chung_thuc_nghiem_GVHD.pptx';P.save(path)
md=['# Lời dẫn trình bày với thầy hướng dẫn','', '12 slide chính, khoảng 12–15 phút; 5 slide phụ lục để trả lời câu hỏi.', '', '**Phạm vi:** Số mới là kết quả pilot thực sự đã chạy trên CSV trong repository. Chưa xác minh nguồn dữ liệu và nhãn riêng ransomware; không dùng số giả lập làm bằng chứng. Số cũ chỉ nằm trong phụ lục đối soát. Công thức và phần mềm luận văn chưa được tự động sửa theo pilot.', '']
for i,(title,body) in enumerate(SLIDES,1):
    for before,after in fixes.items():body=body.replace(before,after)
    md.extend([f'## Slide {i:02d} — {title}','',body,''])
(OUT/'Loi_dan_thuyet_trinh.md').write_text('\n'.join(md),encoding='utf-8')
print(path)
print('Slides:',len(P.slides),'Speaker notes:',len(SLIDES))
