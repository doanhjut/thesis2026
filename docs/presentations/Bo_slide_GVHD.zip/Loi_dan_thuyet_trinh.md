# Lời dẫn trình bày với thầy hướng dẫn

13 slide chính, khoảng 12–15 phút; 3 slide phụ lục chỉ mở khi cần.

**Cách dùng:** Các nội dung “đã có trong bản thảo” mô tả phiên bản PDF được cung cấp. Các kế hoạch thực nghiệm chưa được trình bày như kết quả đã hoàn tất. Bộ slide không sử dụng bảng số liệu giả lập làm bằng chứng.

## Slide 01 — Mở đầu

Thưa thầy, em báo cáo mức độ hoàn thiện của luận văn sau Seminar, tập trung vào ba đóng góp và việc tiếp thu các nhận xét của Hội đồng. Mục tiêu buổi hôm nay là xin thầy đánh giá phạm vi đóng góp, các nội dung đã được làm rõ trong bản thảo và những bằng chứng cần chốt để xem xét bảo vệ trong đợt này. Trong báo cáo, em phân biệt nội dung đã có trong bản thảo với phần thực nghiệm còn cần đối soát. Thời lượng dự kiến 12–15 phút; 13 slide chính và 3 slide dự phòng.

Nguồn: luuvan.pdf, trang bìa; góp ý.txt

## Slide 02 — Mục tiêu và căn cứ xin xem xét

Hội đồng đã nêu khả năng xem xét bảo vệ với điều kiện chỉnh sửa, nên em tổ chức báo cáo theo đúng các điều kiện cần đáp ứng. Em xin thầy đánh giá ba vấn đề: phạm vi đóng góp có rõ và phù hợp chưa; các phần tiếp thu trong bản thảo đã đáp ứng về mặt trình bày đến đâu; các phép đo tối thiểu nào cần hoàn tất trước khi chốt hồ sơ. Báo cáo này không tự thay thế quyết định đủ điều kiện của thầy và Nhà trường.

Nguồn: góp ý.txt, đoạn kết luận

## Slide 03 — Ba đóng góp của luận văn

Đóng góp thứ nhất liên quan cách dung hợp hai nguồn tín hiệu để cân bằng chất lượng phát hiện và chi phí. Đóng góp thứ hai liên quan chọn mẫu gán nhãn, nên phải so sánh ở cùng ngân sách. Đóng góp thứ ba là khung đánh giá lời giải thích: nó không tự làm tăng AUC của bộ phát hiện. Em tách ba câu hỏi này để tránh quy toàn bộ cải thiện của hệ thống cho một thành phần. Tên kỹ thuật không thay thế được bằng chứng; mỗi đóng góp cần một đối chứng phù hợp.

Nguồn: §3.2, §3.3, §3.4; src/pid_fusion.py, src/xai_active_learning.py, src/fidelity_framework.py

## Slide 04 — Kiến trúc đã làm rõ

Em đã làm rõ trong phần trình bày rằng cổng bất định quyết định có kích hoạt phân tích động hay không. Khi mẫu ở ngoài vùng bất định, hệ thống có thể đưa ra quyết định tĩnh. PID chỉ chạy khi đã có cả hai điểm tĩnh và động. Vòng AL nhận ứng viên và mô hình hiện tại, tính điểm truy vấn, nhận nhãn từ oracle rồi cập nhật mô hình. SHAP ở đây giải thích mô hình tĩnh; muốn giải thích cả quyết định fusion cần thêm đặc tả, không nên khẳng định đã có mặc nhiên. Sơ đồ này sửa cách nối nhánh ở slide Seminar cũ.

Nguồn: §3.1–3.3; đối chiếu slide Seminar cũ trang 5

## Slide 05 — Đóng góp PID và phép chứng minh cần có

Em lựa chọn PID như một cơ chế cập nhật trọng số có trạng thái. Phần toán bảo đảm trọng số và điểm dung hợp nằm trong miền hợp lệ, nhưng không chứng minh tự động giảm báo động nhầm. Vì vậy, đối chứng trực tiếp phải giữ nguyên hai tín hiệu và chỉ đổi quy tắc dung hợp. Bản thảo đã có bảng so sánh fusion; bước cần chốt là truy nguyên kết quả và chạy đối chứng ghép cặp. Nếu PI/PID không hơn P hoặc trọng số cố định, em sẽ giới hạn kết luận theo bằng chứng, thay vì khẳng định mọi thành phần đều cần thiết.

Nguồn: §3.2.2–3.2.3, tr.36–39; Bảng 4.5 tr.53

## Slide 06 — Đóng góp XAI-Guided AL

AL không tự gán nhãn đúng: nó đề xuất mẫu để oracle hoặc chuyên gia trả nhãn. Điểm cần chứng minh là cùng số nhãn, XAI chọn được mẫu hữu ích hơn random và uncertainty. Bản thảo nêu tập khởi tạo 2.000 nhãn, năm vòng thêm 100 mẫu; đây là giao thức trên bộ dữ liệu lớn được mô tả, không phải khả năng của CSV 2.000 mẫu hiện có. Pilot phải dùng ngân sách nhỏ hơn. Để giải thích đóng góp của công thức mới, cần thêm so sánh uncertainty cộng từng thành phần Hdir và variance. Không khẳng định tiết kiệm 90% nhãn nếu chưa có đường cong đạt cùng chất lượng.

Nguồn: §3.3; Bảng 4.6 tr.54; Bảng 4.7–4.8 tr.55

## Slide 07 — Đóng góp khung đánh giá giải thích

Em không xem các chỉ số là một bộ chuẩn có thể chuyển nguyên xi từ ảnh sang PE. Phần kế thừa là nguyên tắc kiểm tra tác động, ổn định và tính phân biệt; phần cần điều chỉnh là phép masking, perturbation và cách xác định mẫu tương đồng. PE gồm nhiều kiểu và nhóm đặc trưng phụ thuộc, nên thay bằng 0 hoặc thêm Gaussian có thể tạo vector vô lý. Bản thảo đã nêu chính sách PE-aware và giới hạn. Phần cần làm rõ bằng thực nghiệm là kiểm tra ràng buộc, đối chứng attribution ngẫu nhiên và độ nhạy. Trong PDF, EC là tương quan giữa cấu trúc tương đồng PE và SHAP, còn code hiện dùng độ ổn định khi thêm nhiễu. Hai định nghĩa này phải được thống nhất; kiểm tra perturbation có thể là phép thử độ nhạy bổ sung. CF trong PDF dùng độ phân tách hai tâm cụm SHAP. OFS phải thống nhất với mã nguồn; nó không biểu diễn xác suất lời giải thích đúng.

Nguồn: §3.4 tr.43–46; Phụ lục A.4 tr.77–78

## Slide 08 — Tiếp thu góp ý về phương pháp

Đây là phần em muốn làm rõ với thầy: bản thảo hiện đã có những nội dung cụ thể đáp ứng từng nhận xét về phương pháp. Em đã trình bày tách cổng điều phối và PID; giải thích vai trò của thông tin SHAP trong chọn mẫu; bổ sung điều kiện masking PE và giới hạn OFS. Tuy nhiên, mức hoàn thiện ở slide này là về nội dung được trình bày trong bản thảo. Sự nhất quán giữa công thức và code, cùng hiệu quả thực nghiệm của các lựa chọn, vẫn cần các kiểm tra được nêu ở các slide tiếp theo.

Nguồn: §3.2.2–3.2.3 tr.36–39; §3.3.4 tr.42–43; §3.4.3–3.4.4 tr.44–46

## Slide 09 — Tiếp thu góp ý về thực nghiệm và kết luận

Bản thảo đã vượt khỏi việc chỉ so hệ thống đầy đủ với static: đã có các baseline fusion và baseline AL, định nghĩa độ trễ, cùng phần hạn chế. Đây là tiến bộ về thiết kế và trình bày đánh giá. Nhưng có bảng trong bản thảo chưa đủ chứng minh phép đo đã được tái lập. Em cần truy nguyên dự đoán từng mẫu, chạy nhiều seed cho AL, đo thời gian bằng đồng hồ thật và xác nhận nguồn dữ liệu. Đối với thuật ngữ zero-day và tiết kiệm nhãn, em giữ kết luận trong phạm vi bằng chứng.

Nguồn: Bảng 4.5 tr.53; Bảng 4.6 tr.54; Bảng 4.7–4.8 tr.55; §4.1.4 tr.50–51; §4.7 tr.63–66; A.5 tr.78

## Slide 10 — Hiện trạng có thể kiểm chứng

Em có bản thảo, code và mô hình để triển khai đánh giá tiếp. Trong môi trường đã chuẩn bị, phần dự đoán trên dữ liệu mẫu, TreeSHAP và thao tác nạp dashboard đã được kiểm tra; đó là kiểm tra chức năng, không phải xác nhận các số AUC/FPR trong luận văn. CSV hiện trong Git có 2.000 mẫu và 2.381 đặc trưng, trong khi bản thảo mô tả bộ 20.000 mẫu và schema 1.024 chiều. Em cần xác định đúng phiên bản dữ liệu và pipeline sinh mỗi bảng. Các log PID hiện có thuộc demo mô phỏng; kết luận về chất lượng fusion cần điểm động từ quan sát thật.

Nguồn: README; data/processed/real_mini_dataset.csv; src/; models/; /workspace/onboarding/validate_thesis.py đã chạy trong phiên

## Slide 11 — Gói thực nghiệm bổ sung

Em đề xuất một gói đo tập trung, không mở rộng đề tài sang quá nhiều mô hình. Fusion cần cùng điểm đầu vào để cô lập PID. AL cần Random và Uncertainty làm đối chứng với cùng ngân sách. Fidelity cần đối chứng attribution ngẫu nhiên và kiểm tra phép biến đổi phù hợp PE. Cuối cùng, bảng 2×2 fixed/PID và random/XAI cho biết hai thành phần riêng và kết hợp đóng góp thế nào. Mọi ngưỡng và lựa chọn tham số dùng validation; test giữ độc lập. Kết quả cần có dự đoán và cấu hình truy vết, không chỉ ảnh biểu đồ.

Nguồn: ke_hoach_thuc_nghiem_ba_dong_gop.md; đây là công việc đề xuất, chưa chạy

## Slide 12 — Các điều kiện cần khép lại

Em xin tập trung hoàn thiện bốn nhóm việc này. Trước hết là khóa đúng thuật toán thực sự chạy, bao gồm mapping đặc trưng và công thức tổng hợp. Sau đó xác nhận dữ liệu, vì thiếu nguồn và split thì kết quả khó bảo vệ. Tiếp theo chạy các đối chứng trọng tâm và báo cả trường hợp không có cải thiện rõ. Cuối cùng, đồng bộ số trong bảng, công thức, code và log. Đây là tiêu chí nghiệm thu phần hoàn thiện; em chưa tự đánh dấu hoàn tất khi chưa có đầu ra đáp ứng các tiêu chí này.

Nguồn: Đối chiếu luuvan.pdf với src/, scripts/, data/ và kế hoạch thực nghiệm

## Slide 13 — Kết thúc và xin ý kiến

Em xin thầy xem xét khả năng bảo vệ trong đợt này trên cơ sở phạm vi khoa học đã trình bày và phần hoàn thiện sau góp ý. Em mong được thống nhất ba điều: cách phát biểu đóng góp phù hợp, các đối chứng tối thiểu cần chốt và đầu ra cụ thể để thầy đánh giá lại trước khi nộp. Em không xin bỏ qua các điểm chưa nhất quán; em đề xuất đóng chúng bằng một kế hoạch đo có giới hạn rõ để hồ sơ bảo vệ có căn cứ và trả lời được các câu hỏi của Hội đồng.

Nguồn: góp ý.txt; các phần đã trình bày

## Slide 14 — Phụ lục: đối soát số liệu

Chỉ dùng slide này nếu thầy hỏi số cụ thể. Các số là nội dung đang ghi trong bản thảo, chưa được tái chạy độc lập trong đợt rà soát này. Phép tính FPR từ confusion matrix là 48/3000=1,6%; 0,8% ở bảng fusion có thể thuộc cấu hình khác nhưng cần log chứng minh. Công thức harmonic mean cho ba giá trị in trong bảng ra khoảng 0,3640, trong khi code hiện dùng trung bình cộng trọng số. Định nghĩa FF/EC/CF cũng cần thống nhất, nên không chỉ sửa một ô OFS. Độ trễ demo được sinh ngẫu nhiên; không sử dụng như bằng chứng đo.

Nguồn: Bảng 4.5 tr.53; Bảng 4.6 tr.54; Bảng 4.8 tr.55; Bảng 4.9 tr.57; scripts/live_defense_demo.py

## Slide 15 — Phụ lục: ma trận ablation

Bốn cấu hình đều có thể dùng hai tín hiệu tĩnh–động. Nhờ đó thay fixed-weight bằng PID không đồng thời thêm một nguồn dữ liệu mới. Các cấu hình Random cũng được bổ sung cùng số nhãn; mô hình đứng yên không phải đối chứng đủ để chứng minh tiêu chí chọn mẫu. Ngoài bốn ô, em giữ static-only và dynamic-only làm mốc. Hệ thống đầy đủ đứng đầu chưa đủ chứng minh cộng hưởng: cần chênh lệch tương tác ghép cặp và khoảng bất định.

Nguồn: Kế hoạch thực nghiệm; chưa có kết quả đo cho bảng này

## Slide 16 — Phụ lục: gợi ý trả lời

Nếu thầy hỏi tính đúng của PID, phân biệt đầu ra hợp lệ về miền giá trị với hiệu quả thực nghiệm. Nếu hỏi AUC tăng ít, nhấn mạnh cần đối chứng và biến động, không cố biến mức tăng nhỏ thành đột phá. Nếu hỏi độ đo chuyển miền, trình bày rõ một thay đổi vector PE có thể phá miền hoặc ngữ nghĩa; các biện pháp có ràng buộc chỉ giảm rủi ro, chưa bảo đảm có tệp PE tương ứng. Các câu trả lời trên nhằm chốt cách chứng minh trong luận văn, không thay thế kết quả đo.

Nguồn: Góp ý chi tiết người dùng cung cấp
