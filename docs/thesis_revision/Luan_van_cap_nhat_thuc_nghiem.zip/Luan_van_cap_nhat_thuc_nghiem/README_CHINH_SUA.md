# Bản nháp luận văn đối chiếu thực nghiệm — 14/10/2026

Gói này gồm bản LaTeX đã chỉnh sửa, PDF biên dịch, ghi chú rà soát bản người dùng gửi và tóm tắt bằng chứng thực nghiệm. Đây là bản để tác giả/GVHD rà soát; việc biên dịch thành công không xác nhận đã hoàn tất kiểm chứng ba đóng góp.

## Nên đọc theo thứ tự

1. `NOTE_CAN_UPDATE_LUAN_VAN.md`: từng vị trí của bản LaTeX gốc cần cập nhật, lý do, mức ưu tiên và trạng thái xử lý trong bản nháp.
2. `THAY_DOI_THUC_NGHIEM.md`: phần đã sửa và đối chiếu góp ý seminar.
3. `VIEC_CAN_BO_SUNG.md`: dữ liệu, phép đo và đầu ra còn cần bổ sung.
4. `thesis.pdf`: bản nháp đã biên dịch (78 trang vật lý).
5. `DOI_CHIEU_VOI_BAN_GUI.diff`: toàn bộ thay đổi các tệp TeX/Bib so với ZIP gốc, đọc bằng trình soạn thảo hoặc công cụ diff.

Tên thư mục không trùng số chương: `chapters/c1/` là Chương 2; `c2/` là Chương 3; `c3/` là Chương 4.

## Các cập nhật chính

- Đồng bộ số chiều, quy trình dữ liệu, công thức và phạm vi kết luận với hai lần đo có artifact: AL năm seed và Fidelity một mô hình cố định.
- Bổ sung bảng đối chứng AL, đường học, chênh lệch ghép cặp; Fidelity top-k/random và khoảng bootstrap; một ví dụ SHAP từ mẫu kiểm thử có truy vết.
- Tách thiết kế PID khỏi kết quả đã kiểm chứng; không suy ra giảm FPR từ tính chất tổ hợp lồi.
- Báo các thành phần Fidelity riêng; không đưa ra điểm OFS khi định nghĩa tổng hợp chưa thống nhất.
- Tóm tắt, kết luận và phụ lục được đồng bộ; các khẳng định về 20.000 tệp/họ ransomware, bảng PID và độ trễ cũ không được tiếp tục dùng khi chưa có artifact tương ứng để kiểm tra.

Phần nghiên cứu liên quan vẫn cần bổ sung các công trình gần nhất cụ thể. Xuất xứ CSV và ngữ nghĩa nhãn ransomware chưa được xác minh. Những điều này không được thay thế bằng việc tăng số chữ hoặc số hình.

## Biên dịch

Mở `thesis.tex`, chọn **XeLaTeX** (không dùng pdfLaTeX). Có thể chạy từ thư mục chứa file:

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error thesis.tex
```

Hoặc dùng XeLaTeX → BibTeX → XeLaTeX → XeLaTeX. Cần TeX Live với các gói thông dụng fontspec, scrextend, natbib, TikZ, listings, tabularx, xurl và latexmk. Không cần Python hoặc chạy mô hình để biên dịch luận văn; các biểu đồ đã xuất PDF sẵn.

Font ưu tiên Times New Roman, sau đó TeX Gyre Termes, cuối cùng Liberation Serif. **PDF đi kèm dùng Liberation Serif** do máy hiện tại không có Times New Roman. Font mã là DejaVu Sans Mono. Khi nộp theo quy định trường, cài font được yêu cầu và biên dịch lại; số trang có thể thay đổi. Không coi fallback là xác nhận phù hợp thể thức của UET.

Kiểm tra trên môi trường hiện tại: không có tham chiếu/trích dẫn chưa xác định, ký tự thiếu hoặc bảng tràn lề (Overfull). Còn cảnh báo thay thế cỡ font toán 13pt và cảnh báo gói định dạng underline; PDF các trang bảng/hình đã được kiểm tra trực quan.

Lời cảm ơn và lời cam đoan giữ ngày tháng của bản người dùng gửi (tháng 06/2026). Tác giả cần rà soát nội dung cam đoan và cập nhật ngày ký trước khi nộp bản mới; không tự thêm chữ ký hoặc xác nhận của GVHD.

## Bằng chứng và tái lập

`evidence/` chứa bản sao nguyên trạng cấu hình, bảng tổng hợp, kiểm tra và mã chạy của hai lần đo. Đây là gói đối soát gọn; không gồm toàn bộ 150 model AL, dự đoán từng mẫu và ma trận SHAP. Bản đầy đủ đã được lưu tại:

https://github.com/doanhjut/thesis2026/blob/526a748093447a02f680d808ed05a211fb23def3/docs/presentations/Bo_slide_GVHD.zip?raw=true

Dữ liệu đầu vào tham chiếu `data/processed/real_mini_dataset.csv` của repository, SHA-256:

`c733cc0c3e0950fa1d05d57d34c69d0a034383e0c1a2fde0e6878b9e2e8c3668`

Mã runner được giữ nguyên để bảo toàn hash. Runner AL chứa đường dẫn môi trường gốc và ghi cạnh chính file script; chỉ chạy từ bản sao trong thư mục đầu ra mới. Runner Fidelity nhận đường dẫn qua tham số. Xem README và config trong từng thư mục để có phiên bản thư viện và điều kiện tái lập. Không chạy ghi đè lên phép đo đã lưu. Hash CSV xác định đầu vào phép đo, không chứng minh nguồn gốc từng tệp PE.

`TEP_KHONG_DUNG_TRONG_BAN_BIEN_DICH.txt` liệt kê các tệp không được gọi trong bản mới, như ảnh kết quả cũ và các chương nguồn không được include. ZIP gốc của người dùng được giữ nguyên; gói mới thay `thesis.pdf` cũ bằng PDF vừa biên dịch và thay README cũ bằng tài liệu này. `SHA256SUMS.txt` kiểm tra tính toàn vẹn các file trong gói, không phải chứng nhận học thuật.
