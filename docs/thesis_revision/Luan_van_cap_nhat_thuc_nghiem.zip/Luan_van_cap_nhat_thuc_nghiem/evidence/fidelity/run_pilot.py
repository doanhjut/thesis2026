#!/usr/bin/env python3
"""Measured, reproducible Fidelity pilot. Does not edit the thesis repository.

Source data provenance is unknown: results are exploratory, not thesis validation.
TreeSHAP is native LightGBM pred_contrib, explaining raw (log-odds) output.
Masking changes feature vectors only; executable PE validity is not established.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import operator
from pathlib import Path
import platform
import subprocess
from time import perf_counter

import lightgbm as lgb
import numpy as np
import pandas as pd
import scipy
from scipy.stats import pearsonr
import sklearn
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import train_test_split


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def number(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mult)):
        op = operator.add if isinstance(node.op, ast.Add) else operator.mul
        return op(number(node.left), number(node.right))
    raise ValueError(f"Unsupported dimension expression: {ast.dump(node)}")


def extract_group_schema(path):
    """Derive default EMBER v2 ordering/dimensions from extractor source, not old map."""
    tree = ast.parse(Path(path).read_text())
    classes = {n.name: n for n in tree.body if isinstance(n, ast.ClassDef)}
    initializer = next(n for n in classes["PEFeatureExtractor"].body
                       if isinstance(n, ast.FunctionDef) and n.name == "__init__")
    feature_dict = next(n.value for n in ast.walk(initializer)
                        if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == "features" for t in n.targets)
                        and isinstance(n.value, ast.Dict))
    ordered_classes = [v.func.id for v in feature_dict.values] + ["DataDirectories"]
    rows, start = [], 0
    for name in ordered_classes:
        dim_node = next(n.value for n in classes[name].body
                        if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == "dim" for t in n.targets))
        dim = int(number(dim_node))
        rows.append({"group": name, "start_inclusive": start,
                     "end_exclusive": start + dim, "dimension": dim})
        start += dim
    assert start == 2381, start
    return rows


def measured_mask_metrics(y, original, masked, before, eps):
    difference = original - masked
    return {
        "auc_before": float(before),
        "auc_after": float(roc_auc_score(y, masked)),
        "auc_drop": float(before - roc_auc_score(y, masked)),
        "mean_absolute_probability_change": float(np.abs(difference).mean()),
        "mean_signed_probability_drop": float(difference.mean()),
        "probability_decrease_fraction": float(np.mean(difference > 1e-12)),
        "probability_increase_fraction": float(np.mean(difference < -1e-12)),
        "probability_unchanged_fraction": float(np.mean(np.abs(difference) <= 1e-12)),
        "thesis_ff_raw_unclipped": float(np.mean(np.abs(difference) / (original + eps))),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("/workspace/thesis2026/data/processed/real_mini_dataset.csv"))
    parser.add_argument("--schema-source", type=Path, default=Path("/workspace/thesis2026/scripts/ember/ember/features.py"))
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "run_seed42")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    out = args.output
    t_start = perf_counter()
    eps, seed, repetitions = 1e-12, 42, 20
    versions = {"python": platform.python_version(), "numpy": np.__version__,
                "pandas": pd.__version__, "scipy": scipy.__version__,
                "sklearn": sklearn.__version__, "lightgbm": lgb.__version__}
    params = dict(n_estimators=100, num_leaves=15, max_depth=4, learning_rate=0.1,
                  min_child_samples=20, n_jobs=2, random_state=seed,
                  deterministic=True, force_col_wise=True, verbosity=-1)
    config = {"seed": seed, "data": str(args.data.resolve()), "data_sha256": sha256(args.data),
              "source_sha256": sha256(__file__), "schema_source": str(args.schema_source.resolve()),
              "schema_source_sha256": sha256(args.schema_source), "versions": versions,
              "model_parameters": params, "k_values": [10, 25, 50],
              "random_repetitions": repetitions, "epsilon": eps,
              "split": "test_size=.2 stratified seed42; validation_size=.25 of remainder stratified seed42",
              "mask_baseline": "Arithmetic mean of 1200 training rows; no test/validation fit",
              "random_control": "Uniform subsets without replacement, independently per test row; same k as SHAP",
              "shap": "Native LightGBM TreeSHAP pred_contrib=True; feature columns only; raw log-odds scale",
              "ec": "Pearson r between upper triangles (excluding diagonal) of cosine similarities of train-standardized X and signed SHAP",
              "cf": "norm(mean(Phi|y=1)-mean(Phi|y=0))/(max_test_row(norm(Phi))+eps), PDF Eq.3.17",
              "thesis_ff": "mean(abs(p_original-p_masked)/(p_original+eps)), PDF Eq.3.15; saved RAW without clipping",
              "ofs": "Not calculated: repository and PDF definitions have not been reconciled",
              "limitations": ["Unknown original source/split and ransomware-specific meaning of label 1",
                              "One trained model, one random split; no estimate of retraining variation",
                              "Only vector masking; not a validated executable PE transformation",
                              "EC pair entries share samples: naive correlation p-values are not reported",
                              "CF is class separation, not a causal or faithfulness proof"]}
    config["repository_commit"] = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd="/workspace/thesis2026", text=True).strip()
    write_json(out / "config.json", config)
    write_json(out / "feature_groups.json", extract_group_schema(args.schema_source))

    df = pd.read_csv(args.data, encoding="utf-8-sig")
    assert len(df) == 2000 and df.shape[1] == 2382, df.shape
    X = df.drop(columns="label").to_numpy(dtype=np.float64)
    y = df["label"].to_numpy(dtype=np.int64)
    assert X.shape[1] == 2381 and np.isfinite(X).all() and set(y) == {0, 1}
    ids = np.arange(len(y))
    remainder, test = train_test_split(ids, test_size=.2, stratify=y, random_state=seed)
    train, validation = train_test_split(remainder, test_size=.25,
                                        stratify=y[remainder], random_state=seed)
    assert (len(train), len(validation), len(test)) == (1200, 400, 400)
    split_names = np.empty(len(y), dtype=object)
    split_names[train], split_names[validation], split_names[test] = "train", "validation", "test"
    feature_row_hash = [hashlib.sha256(np.asarray(row, dtype="<f8").tobytes()).hexdigest() for row in X]
    manifest = pd.DataFrame({"row_id_zero_based": ids, "split": split_names,
                             "label": y, "feature_vector_sha256_not_PE_file_hash": feature_row_hash})
    manifest.to_csv(out / "split_manifest.csv", index=False)
    np.savez_compressed(out / "split_indices.npz", train=train, validation=validation, test=test)
    repeated = manifest.groupby("feature_vector_sha256_not_PE_file_hash").agg(
        n=("split", "size"), n_splits=("split", "nunique"))
    data_audit = {"n_rows": len(y), "n_features": X.shape[1],
                  "counts": manifest.groupby(["split", "label"]).size().to_dict().__str__(),
                  "duplicate_feature_vector_groups": int((repeated.n > 1).sum()),
                  "feature_vector_groups_crossing_splits": int((repeated.n_splits > 1).sum()),
                  "feature_names": df.drop(columns="label").columns.tolist()}
    write_json(out / "data_audit.json", data_audit)

    model = lgb.LGBMClassifier(**params)
    t_train = perf_counter()
    model.fit(X[train], y[train])
    train_seconds = perf_counter() - t_train
    model.booster_.save_model(str(out / "model.txt"))
    mean = X[train].mean(axis=0)
    std = X[train].std(axis=0)
    std[std == 0] = 1.0
    np.savez_compressed(out / "train_baseline.npz", mean=mean, std=std)
    Xt, yt = X[test], y[test]
    p = model.booster_.predict(Xt, num_threads=2)
    t_shap = perf_counter()
    contributions = model.booster_.predict(Xt, pred_contrib=True, num_threads=2)
    shap_seconds = perf_counter() - t_shap
    phi, intercept = contributions[:, :-1], contributions[:, -1]
    raw_scores = model.booster_.predict(Xt, raw_score=True, num_threads=2)
    additivity_error = float(np.max(np.abs(phi.sum(axis=1) + intercept - raw_scores)))
    assert phi.shape == Xt.shape and np.isfinite(phi).all() and additivity_error < 1e-8
    np.savez_compressed(out / "shap_values.npz", row_id=test, phi=phi, intercept=intercept, raw_scores=raw_scores)
    pd.DataFrame({"row_id_zero_based": test, "label": yt, "p_original": p}).to_csv(
        out / "test_predictions.csv", index=False)
    before = roc_auc_score(yt, p)
    top_indices = np.argsort(np.abs(phi), axis=1)[:, ::-1]
    all_metrics, all_predictions, mask_indices, top_predictions = [], [], {}, {}
    rows = np.arange(len(test))[:, None]
    t_mask = perf_counter()
    for k in [10, 25, 50]:
        for method in ["top_abs_treeshap", "uniform_random"]:
            for replicate in range(1 if method == "top_abs_treeshap" else repetitions):
                if method == "top_abs_treeshap":
                    selected = top_indices[:, :k]
                else:
                    rng = np.random.default_rng(np.random.SeedSequence([seed, k, replicate]))
                    selected = np.stack([rng.choice(X.shape[1], k, replace=False) for _ in test])
                masked = Xt.copy()
                masked[rows, selected] = mean[selected]
                masked_p = model.booster_.predict(masked, num_threads=2)
                record = {"method": method, "k": k, "replicate": replicate,
                          **measured_mask_metrics(yt, p, masked_p, before, eps),
                          "mean_actual_changed_coordinates": float(np.mean(np.sum(masked != Xt, axis=1)))}
                all_metrics.append(record)
                key = f"{method}_k{k}_rep{replicate}"
                mask_indices[key] = selected.astype(np.int16)
                if method == "top_abs_treeshap":
                    top_predictions[k] = masked_p
                all_predictions.append(pd.DataFrame({"method": method, "k": k,
                    "replicate": replicate, "row_id_zero_based": test, "label": yt,
                    "p_original": p, "p_masked": masked_p,
                    "signed_probability_drop": p - masked_p,
                    "absolute_probability_change": np.abs(p - masked_p)}))
    mask_seconds = perf_counter() - t_mask
    mask_table = pd.DataFrame(all_metrics)
    mask_table.to_csv(out / "mask_metrics.csv", index=False)
    pd.concat(all_predictions, ignore_index=True).to_csv(out / "mask_predictions.csv", index=False)
    np.savez_compressed(out / "mask_indices.npz", **mask_indices)

    t_similarity = perf_counter()
    Sx = cosine_similarity((Xt - mean) / std)
    Sphi = cosine_similarity(phi)
    triangle = np.triu_indices(len(test), k=1)
    ec = float(pearsonr(Sx[triangle], Sphi[triangle]).statistic)
    class0, class1 = phi[yt == 0].mean(axis=0), phi[yt == 1].mean(axis=0)
    numerator = float(np.linalg.norm(class1 - class0))
    denominator = float(np.linalg.norm(phi, axis=1).max())
    cf = numerator / (denominator + eps)
    np.savez_compressed(out / "ec_cf_inputs.npz", feature_similarity=Sx,
                        shap_similarity=Sphi, class0_centroid=class0, class1_centroid=class1)
    similarity_seconds = perf_counter() - t_similarity

    # Conditional uncertainty on test rows for a fixed fitted model, not across training seeds.
    bootstrap_rng = np.random.default_rng(2026)
    bootstrap_drops = {k: [] for k in top_predictions}
    strata = [np.flatnonzero(yt == label) for label in [0, 1]]
    for _ in range(500):
        b = np.concatenate([bootstrap_rng.choice(s, len(s), replace=True) for s in strata])
        b_before = roc_auc_score(yt[b], p[b])
        for k, masked_p in top_predictions.items():
            bootstrap_drops[k].append(float(b_before - roc_auc_score(yt[b], masked_p[b])))
    np.savez_compressed(out / "paired_test_bootstrap.npz",
                        **{f"top_shap_auc_drop_k{k}": v for k, v in bootstrap_drops.items()})
    comparisons = []
    for k in [10, 25, 50]:
        top = mask_table[(mask_table.k == k) & (mask_table.method == "top_abs_treeshap")].iloc[0]
        random = mask_table[(mask_table.k == k) & (mask_table.method == "uniform_random")]
        comparisons.append({"k": k, "auc_before": float(before),
            "top_shap_auc_after": float(top.auc_after), "top_shap_auc_drop": float(top.auc_drop),
            "top_shap_auc_drop_bootstrap_test_ci95": np.quantile(bootstrap_drops[k], [.025, .975]).tolist(),
            "random_auc_after_mean": float(random.auc_after.mean()),
            "random_auc_drop_mean": float(random.auc_drop.mean()),
            "random_auc_drop_sd_across_masks": float(random.auc_drop.std(ddof=1)),
            "top_shap_mean_absolute_probability_change": float(top.mean_absolute_probability_change),
            "random_mean_absolute_probability_change": float(random.mean_absolute_probability_change.mean()),
            "top_shap_ff_thesis_raw_unclipped": float(top.thesis_ff_raw_unclipped),
            "top_shap_probability_decrease_fraction": float(top.probability_decrease_fraction),
            "top_shap_probability_increase_fraction": float(top.probability_increase_fraction)})
    timings = {"training_seconds": train_seconds, "native_treeshap_400_seconds": shap_seconds,
               "mask_predict_63_batches_seconds": mask_seconds,
               "ec_cf_seconds": similarity_seconds, "total_seconds": perf_counter() - t_start}
    summary = {"status": "MEASURED_EXPLORATORY_PILOT_NOT_THESIS_VALIDATION",
               "baseline_test_roc_auc": float(before),
               "baseline_test_average_precision": float(average_precision_score(yt, p)),
               "native_treeshap_raw_score_additivity_max_error": additivity_error,
               "feature_vector_duplicate_groups": data_audit["duplicate_feature_vector_groups"],
               "feature_vector_groups_crossing_splits": data_audit["feature_vector_groups_crossing_splits"],
               "faithfulness_deletion_comparisons": comparisons,
               "ec_thesis_cosine_similarity_matrix_correlation": ec,
               "ec_pair_count": len(triangle[0]), "cf_thesis_centroid_separation": cf,
               "cf_numerator": numerator, "cf_denominator_max_sample_shap_norm": denominator,
               "ofs": None, "ofs_reason": config["ofs"], "timings": timings,
               "limitations": config["limitations"]}
    write_json(out / "summary.json", summary)
    write_json(out / "timings.json", timings)
    print(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
