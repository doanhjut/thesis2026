# Fidelity pilot — phép đo thực, phạm vi thăm dò

Pilot dùng `real_mini_dataset.csv` trong Git, 2.000 mẫu và 2.381 đặc trưng. Nguồn gốc từng mẫu và ý nghĩa ransomware-specific của nhãn 1 chưa được xác nhận. Không dùng mô hình pretrained để suy ra chất lượng trên tập huấn luyện chưa biết: pilot huấn luyện một LightGBM mới trên 1.200 mẫu; validation 400; test 400 (300 nhãn 0, 100 nhãn 1).

## Chạy lại

```bash
/workspace/thesis2026/.venv/bin/python /workspace/academic-review/pilot_fidelity/run_pilot.py --output /workspace/academic-review/pilot_fidelity/reproduction_seed42
```

Thư mục đầu ra phải chưa tồn tại, tránh ghi đè phép đo trước. Mọi tham số, phiên bản thư viện, SHA-256 nguồn dữ liệu/script/schema, commit, split và model nằm trong đầu ra. `row_id_zero_based` và hash vector không phải hash tệp PE.

## Kết quả đo

LightGBM mới: 100 cây, 15 lá, độ sâu tối đa 4, seed 42, 2 CPU threads. ROC-AUC trên test là **0,980167**; average precision là **0,955338**. Không phát hiện vector đặc trưng trùng hoàn toàn hoặc trùng xuyên split. Điều này không loại trừ near-duplicates hay tương quan nguồn/họ.

TreeSHAP dùng trực tiếp `pred_contrib=True`, giải thích raw score (log-odds), không phải xác suất. Tổng SHAP cộng intercept khớp raw score với sai số tối đa 7,11×10⁻¹⁵. Chọn top-k theo trị tuyệt đối SHAP và thay bằng trung bình chỉ từ train. Random control chọn đều không hoàn lại k chiều cho từng mẫu, độc lập trong 20 lần lặp. Hai cách có cùng ngân sách chiều được chọn; mức thay đổi thực tế của vector không nhất thiết bằng nhau, nên đã lưu số tọa độ thật sự thay đổi.

| k | AUC trước che | AUC sau che top-SHAP | AUC sau che random (trung bình 20 lần) | AUC drop top-SHAP | AUC drop random |
|---|---:|---:|---:|---:|---:|
| 10 | 0,980167 | 0,913933 | 0,979867 | 0,066233 | 0,000300 |
| 25 | 0,980167 | 0,818533 | 0,979910 | 0,161633 | 0,000257 |
| 50 | 0,980167 | 0,671200 | 0,979263 | 0,308967 | 0,000903 |

Khoảng percentile 95% của AUC drop top-SHAP bằng 500 lần paired stratified bootstrap test: k=10 [0,039044; 0,097026], k=25 [0,122232; 0,207752], k=50 [0,253428; 0,373968]. Đây là độ bất định có điều kiện trên **một mô hình đã fit**, không đo biến động giữa các lần huấn luyện. Độ lệch chuẩn random trong `summary.json` là biến động giữa các mask, không phải khoảng tin cậy do chọn mẫu test.

Độ thay đổi xác suất tuyệt đối trung bình: top-SHAP lần lượt 0,174411; 0,201862; 0,212254; random lần lượt 0,002571; 0,005092; 0,010177. Che đặc trưng có thể làm điểm tăng hoặc giảm; không diễn giải mọi đặc trưng top-|SHAP| là bằng chứng dương cho nhãn 1.

## EC, CF và OFS

- **EC = 0,304373**: Pearson correlation giữa các phần tử tam giác trên (bỏ đường chéo) của ma trận cosine similarity đặc trưng và ma trận cosine similarity SHAP có dấu. Đặc trưng được chuẩn hóa bằng mean/std từ train. 79.800 cặp chia sẻ mẫu, vì vậy không báo p-value Pearson giả định các cặp độc lập. Đây là một lựa chọn cụ thể cho phép tương đồng trong công thức 3.16 của PDF, không phải cosine ổn định trước Gaussian noise ở code cũ.
- **CF = 0,587352**: khoảng cách giữa tâm SHAP của hai nhãn chia cho **chuẩn SHAP lớn nhất của một mẫu test**, đúng công thức 3.17 PDF. Tử số 1,337352; mẫu số 2,276919. Đây là phân tách lớp trong không gian giải thích, không là kiểm chứng quan hệ nhân quả.
- **FF thô theo công thức 3.15 PDF**: 1,039404; 2,004518; 2,148306 ở k=10/25/50. Chỉ số chia thay đổi xác suất tuyệt đối cho xác suất gốc có thể vượt 1 và bị khuếch đại khi xác suất gốc thấp. Không tự cắt/chọn công thức để tạo điểm đẹp.
- **Không xuất OFS**: các định nghĩa trong PDF và repository cần được thống nhất trước khi sử dụng một điểm tổng hợp. EC/CF ở đây được ghi đúng tên và định nghĩa, không gộp lẫn các phiên bản code cũ.

## Cách trình bày trước hội đồng

“Trong pilot kiểm tra mô hình vừa huấn luyện, che đặc trưng SHAP xếp quan trọng làm AUC giảm nhiều hơn che ngẫu nhiên cùng k. Kết quả cho thấy thứ hạng SHAP phản ánh các đặc trưng mô hình đang sử dụng dưới phép thử masking này. Chúng em chưa coi đây là bằng chứng rằng vector sau che tương ứng tệp PE hợp lệ, hay giải thích là quan hệ nhân quả của hành vi ransomware.”

Giải thích trung thực với mô hình vẫn có thể chỉ ra một tương quan giả mà mô hình đã học. Pilot chỉ sửa vector đặc trưng, không biến đổi hoặc thực thi tệp nhị phân. Vì vậy, chưa chứng minh khả năng áp dụng an toàn ngoài thực tế hay hoàn tất kiểm chứng PE-aware. Thử nhóm phụ thuộc/miền hợp lệ cần một thí nghiệm riêng với schema, phép biến đổi và ngân sách so sánh được quy định trước.

## Tệp truy vết

- `run_pilot.py`: toàn bộ nguồn phép đo.
- `run_seed42/config.json`, `data_audit.json`, `feature_groups.json`: cấu hình, dữ liệu và group schema suy từ EMBER source, không dùng mapping cũ trong fidelity module.
- `split_manifest.csv`, `split_indices.npz`, `model.txt`, `train_baseline.npz`: split, model mới và thống kê train.
- `test_predictions.csv`, `shap_values.npz`: dự đoán gốc và TreeSHAP.
- `mask_indices.npz`, `mask_predictions.csv`, `mask_metrics.csv`: mask và kết quả từng mẫu/từng lần lặp.
- `ec_cf_inputs.npz`, `paired_test_bootstrap.npz`: đầu vào các phép đo và bootstrap.
- `summary.json`, `timings.json`: tổng hợp phép đo thực. Thời gian phụ thuộc máy và tải khi chạy; không phải overhead toàn hệ thống.
