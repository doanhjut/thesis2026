#!/usr/bin/env python3
"""Post-run artifact audit and presentation summaries; never retrains/tunes."""
import os
os.environ['MPLCONFIGDIR'] = '/workspace/onboarding/mpl'
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score

OUT = Path(__file__).resolve().parent
METHODS = ['Random','Uncertainty','U+H','U+V','XAI_full']
config = json.loads((OUT/'config.json').read_text())
split = json.loads((OUT/'splits.json').read_text())
audit = json.loads((OUT/'audit.json').read_text())
metrics = pd.read_csv(OUT/'metrics.csv')
queries = pd.read_csv(OUT/'queries.csv')
predictions = pd.read_csv(OUT/'predictions.csv.gz')
learning = pd.read_csv(OUT/'learning_curve_summary.csv')
assert len(metrics) == 150 and len(queries) == 12500 and len(predictions) == 120000
assert hashlib.sha256((OUT/'run_pilot.py').read_bytes()).hexdigest() == config['runner_sha256']
for (seed,method),g in queries.groupby(['seed','method']):
    assert g.row_id.nunique() == 500
    assert not set(g.row_id) & (set(split['validation']) | set(split['test']))
    assert not set(g.row_id) & set(split['initial_labeled'][str(seed)])
for (seed,method,rnd),g in predictions[predictions.split=='test'].groupby(['seed','method','round']):
    row = metrics[(metrics.seed==seed)&(metrics.method==method)&(metrics['round']==rnd)].iloc[0]
    assert abs(roc_auc_score(g.label,g.probability)-row.test_auc)<1e-12
    assert abs(average_precision_score(g.label,g.probability)-row.test_ap)<1e-12
    assert g.row_id.nunique()==400
    assert set(g.row_id)==set(split['test'])
    assert len(g[g.label==0])==300 and len(g[g.label==1])==100
    assert np.isfinite(g.probability).all()
for seed,g in metrics[metrics['round']==0].groupby('seed'):
    for name in ['test_auc','test_ap','test_fpr','test_tpr','threshold']:
        assert g[name].nunique()==1

final = metrics[metrics['round']==5]
summary = {
    'study': 'Real-feature active-learning pilot; unknown upstream provenance and class-1 ransomware semantics',
    'final_total_training_labels': 700,
    'initial_training_labels': 200,
    'additional_queried_labels': 500,
    'n_seeds': 5,
    'seeds': config['seeds'],
    'fixed_test': {'negative':300,'positive':100},
    'threshold_policy': config['threshold'],
    'dispersion': 'sample SD (ddof=1) across paired seeds on one shared fixed test set; not population confidence interval',
    'runtime_seconds': audit['elapsed_seconds'],
    'methods':{}, 'curves':{}, 'paired_differences':[],
    'timing_note': 'query_seconds measures acquisition-score computation including pool prediction, TreeSHAP, raw-score additivity audit and normalization; excludes lexsort, annotation, storage and training. tree_shap_seconds is the native pred_contrib call only. Not endpoint or SOC latency.',
    'warnings': config['warnings'],
    'post_audit': 'passed: artifact counts, row exclusion, no repeated queries, recomputed AUC/AP, initial models identical, runner hash'
}
for method in METHODS:
    g = final[final.method==method]
    lc = learning[learning.method==method]
    summary['methods'][method] = {k:{'mean':float(g[k].mean()),'std':float(g[k].std(ddof=1)),
                                    'values':g[k].tolist()}
                                  for k in ['test_auc','test_ap','test_fpr','test_tpr']}
    for key in ['normalized_test_auc_aulc','normalized_test_ap_aulc','query_seconds','train_seconds']:
        summary['methods'][method][key] = {'mean':float(lc[key].mean()),'std':float(lc[key].std(ddof=1))}
    timing = metrics[(metrics.method==method)&(metrics['round']>0)]
    summary['methods'][method]['tree_shap_seconds_per_round'] = {'mean':float(timing.tree_shap_seconds.mean()),
                                                              'std':float(timing.tree_shap_seconds.std(ddof=1))}
    summary['methods'][method]['score_seconds_per_round'] = {'mean':float(timing.query_seconds.mean()),
                                                           'std':float(timing.query_seconds.std(ddof=1))}
    summary['curves'][method] = []
    for n,g in metrics[metrics.method==method].groupby('n_labeled'):
        summary['curves'][method].append(dict(n_labeled=int(n),**{key:{'mean':float(g[key].mean()),'std':float(g[key].std(ddof=1))}
                                                                for key in ['test_auc','test_ap','test_fpr','test_tpr']}))
paired=pd.read_csv(OUT/'paired_differences.csv')
summary['paired_differences']=paired.to_dict('records')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
metrics.to_csv(OUT/'perroundmetrics.csv',index=False)

fig,axes=plt.subplots(1,2,figsize=(12,4.3),layout='constrained')
colors={'Random':'#737373','Uncertainty':'#2474B5','U+H':'#D08A22','U+V':'#9B59B6','XAI_full':'#15866F'}
for ax,metric,title in zip(axes,['test_auc','test_ap'],['ROC-AUC','Average precision (AP)']):
    for method in METHODS:
        c=summary['curves'][method]
        xx=np.array([r['n_labeled'] for r in c]); yy=np.array([r[metric]['mean'] for r in c]); ss=np.array([r[metric]['std'] for r in c])
        ax.plot(xx,yy,marker='o',lw=2,label=method,color=colors[method],markersize=4)
        if method in ['Uncertainty','XAI_full']:
            ax.fill_between(xx,yy-ss,yy+ss,alpha=.10,color=colors[method])
    ax.set_title(title); ax.set_xlabel('Total training labels (200 initial + queries)'); ax.grid(alpha=.2)
axes[0].legend(fontsize=8,loc='lower right')
fig.suptitle('Real-feature pilot: paired 5-seed means on a fixed 400-row test set\nShading: ±1 sample SD for Uncertainty / XAI_full; not confidence intervals',fontsize=11)
fig.savefig(OUT/'learning_curves.png',dpi=180)
fig.savefig(OUT/'learning_curves.pdf')
plt.close(fig)

lines=['# Pilot AL trên đặc trưng thật — kết quả kiểm chứng', '',
       'Đây là pilot trên CSV có sẵn, chưa phải benchmark held-out gốc đã xác minh của luận văn. Nguồn dữ liệu upstream và ý nghĩa nhãn 1 riêng cho ransomware chưa được xác minh.', '',
       'Train/pool 1.200; validation 400; test 400 (300 âm, 100 dương). Khởi tạo 200 nhãn, truy vấn thêm 5×100; năm seed ghép cặp. Mỗi checkpoint huấn luyện LightGBM mới từ toàn bộ nhãn đã có. Ngưỡng chọn trên validation để TPR ≥95%; TPR test có thể khác.', '',
       '| Phương pháp | ROC-AUC | AP | FPR (%) | TPR (%) |', '|---|---:|---:|---:|---:|']
for method in METHODS:
    vals=[]
    for key,scale,digits in [('test_auc',1,4),('test_ap',1,4),('test_fpr',100,2),('test_tpr',100,2)]:
        v=summary['methods'][method][key]; vals.append(f"{v['mean']*scale:.{digits}f} ± {v['std']*scale:.{digits}f}")
    lines.append('| '+method+' | '+' | '.join(vals)+' |')
lines += ['', 'Các giá trị ± là độ lệch chuẩn mẫu giữa năm seed chung một test, không phải khoảng tin cậy tổng thể.', '',
          '## Đối chiếu ghép cặp XAI đầy đủ − Uncertainty', '']
for item in summary['paired_differences']:
    if item['method']=='XAI_full' and item['baseline']=='Uncertainty':
        lines.append(f"- {item['metric']}: {item['mean_difference']:+.6f} ± {item['sd_difference']:.6f}; năm chênh lệch = "+', '.join(f"{item[f'seed_{s}']:+.6f}" for s in config['seeds'])+'.')
lines += ['', '## Thời gian và phạm vi', '', f"Tổng runner: {audit['elapsed_seconds']:.2f} giây. Chỉ đo chi phí thí nghiệm trên máy hiện tại; không phải độ trễ SOC/endpoint.",
          '', summary['timing_note'], '',
          'Không sử dụng test để chọn truy vấn, chọn ngưỡng, dừng sớm hoặc chỉnh siêu tham số. Không fallback sang SHAP/mô hình/chỉ số mô phỏng. Chưa đo tiết kiệm thời gian gán nhãn chuyên gia.', '',
          'Kiểm tra hậu nghiệm: số artifact đúng; query không trùng; train/pool/val/test tách row; ROC-AUC và AP tính lại từ predictions khớp; initial metrics giống nhau giữa methods; hash runner khớp.']
(OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
print((OUT/'REPORT.md').read_text())
