# Strict active-learning pilot

This directory is outside the repository. No repository source or dataset was edited.

Read **REPORT.md** for results and limits, **summary.json** for slide-ready numbers, and **learning_curves.png** for the figure. Results are measurements, not simulated or selected to make XAI win.

## What was run

- Data: `data/processed/real_mini_dataset.csv`, 2,000 rows × 2,381 feature columns; 1,500 negative and 500 positive labels. No exact duplicate feature vectors were found.
- Fixed stratified split with `random_state=42`: 1,200 train/pool, 400 validation, 400 test. Test has 300 negative and 100 positive rows.
- Paired seeds 11, 22, 33, 44, 55. For each seed, every method starts with the same 200 labeled rows and queries 5 batches of 100 rows. Final training budget: 700 labels. Validation labels are additional and do not count toward this training budget.
- Methods: Random, Uncertainty, U+H, U+V, XAI_full. LightGBM is freshly trained on all cumulatively labeled rows after every query batch, with 60 trees, depth ≤4, ≤15 leaves, and 2 CPU threads.
- U = `1 - 2 * abs(p - 0.5)`. H is base-2 entropy of positive/negative absolute TreeSHAP mass; zero total mass maps to zero entropy. V is population variance of **signed** attributions across features. All signals use min-max normalization over the current unlabeled pool; constant signals map to zero.
- Full weights U/H/V = .3/.4/.3. U+H renormalizes .3/.4; U+V renormalizes .3/.3. Contributions come from current-model native LightGBM TreeSHAP on raw margins; the bias contribution is excluded. Additivity is explicitly checked. No simulated fallback is available.
- Threshold is the highest finite validation-positive score achieving validation TPR ≥95%, with prediction `p >= threshold`. The resulting test TPR is measured, not assumed. Test data never controls training, querying, threshold selection or stopping.

## Caveats

Upstream data provenance, chronology, family identities and whether class 1 is specifically ransomware remain unverified. This is a local row-disjoint pilot, **not** the verified original held-out thesis benchmark. Use “positive/negative” until label semantics are established.

Five repetitions share the same test set; reported ± values are sample standard deviations over seed choices, not population confidence intervals. Test FPR resolution is 1/300 (0.333 percentage points) and TPR resolution is 1/100 (1 percentage point). These results do not establish zero-day detection or FPR 0.8%.

There is no pre-trained 1M-row model in this experiment. All models are fitted from the pilot's seed set and queried labels. This differs from the thesis's full-scale setting and must be labeled accordingly.

The experiment measures quality at equal training-label budgets. It does not directly measure saved analyst time or prove a number of labels saved to reach a target. Threshold calibration uses 400 additional known labels.

## Artifact map

| File | Purpose |
|---|---|
| `run_pilot.py` | Complete executable experiment, fixed protocol |
| `summarize_pilot.py` | Post-run independent metric and split checks; summaries and figures |
| `config.json` | Formulas, weights, versions, parameters, source/data hashes and warnings |
| `splits.json` | Original CSV row indices for every partition and initial seed set |
| `models/` | All 150 saved LightGBM checkpoints |
| `metrics.csv`, `perroundmetrics.csv` | Identical full round-by-round metric/timing tables |
| `predictions.csv.gz` | 120,000 validation/test per-row prediction records |
| `queries.csv` | 12,500 queried row IDs, query ranks, actual labels and acquisition signals |
| `final_summary.csv` | Final mean and sample SD by method |
| `paired_differences.csv` | Per-seed method differences, mean difference and sample SD |
| `learning_curve_summary.csv` | Normalized AULC (trapezoid over labels / 500) and timing per seed/method |
| `audit.json` | Runtime checks, counts and maximum SHAP additivity error |
| `post_audit.json` | Independent post-run checks and runner-artifact checksum verification |
| `artifact_sha256.json` | Original runner artifact hashes; excludes running log and itself |
| `all_artifact_sha256.json` | Final directory manifest including presentation artifacts |
| `summary.json`, `REPORT.md` | Summaries for reporting |
| `learning_curves.png`, `learning_curves.pdf` | Exportable figure with mean and selected ±SD bands |

`query_seconds` is acquisition-score computation time (pool prediction, TreeSHAP, raw-score additivity check and normalization). It excludes sorting, human annotation, model training and storage. `tree_shap_seconds` is only the native `pred_contrib=True` call. Neither metric is endpoint/SOC end-to-end latency. Random also evaluates the pool predictions for consistent trace instrumentation, although random sampling itself does not require them.

## Reproduce

The current files are a frozen run. Copy both Python scripts to a fresh output directory before executing to preserve these measurements; each script writes beside itself. The input path is fixed in `run_pilot.py` and its SHA-256 is recorded in `config.json`.

```bash
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 /workspace/thesis2026/.venv/bin/python /path/to/fresh-output/run_pilot.py
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 /workspace/thesis2026/.venv/bin/python /path/to/fresh-output/summarize_pilot.py
```

Inspect `config.json` for exact library versions and the repository commit observed during the run. Dataset partitions, acquisition policy and model parameters must remain unchanged to reproduce this particular pilot.
