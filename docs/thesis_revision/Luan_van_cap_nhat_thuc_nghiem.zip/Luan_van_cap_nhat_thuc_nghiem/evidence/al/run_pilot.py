#!/usr/bin/env python3
"""Strict, reproducible real-feature AL pilot; no simulation or test tuning."""
import os
os.environ['OMP_NUM_THREADS'] = '2'
os.environ['OPENBLAS_NUM_THREADS'] = '2'
os.environ['MPLCONFIGDIR'] = '/workspace/onboarding/mpl'
import csv
import gzip
import hashlib
import json
import math
import platform
import subprocess
import sys
import time
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import average_precision_score, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split

OUT = Path(__file__).resolve().parent
DATA = Path('/workspace/thesis2026/data/processed/real_mini_dataset.csv')
SEEDS = [11, 22, 33, 44, 55]
METHODS = ['Random', 'Uncertainty', 'U+H', 'U+V', 'XAI_full']
WEIGHTS = {
    'Uncertainty': {'U': 1.0},
    'U+H': {'U': 0.3 / 0.7, 'H': 0.4 / 0.7},
    'U+V': {'U': 0.5, 'V': 0.5},
    'XAI_full': {'U': 0.3, 'H': 0.4, 'V': 0.3},
}
BASE_PARAMS = dict(objective='binary', metric='auc', learning_rate=0.05,
                   num_leaves=15, max_depth=4, min_data_in_leaf=10,
                   num_threads=2, deterministic=True, force_col_wise=True,
                   feature_fraction=1.0, bagging_fraction=1.0, bagging_freq=0,
                   verbosity=-1)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def dump_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def normalize(values):
    values = np.asarray(values, dtype=np.float64)
    assert np.isfinite(values).all()
    low, high = float(values.min()), float(values.max())
    return (values - low) / (high - low) if high > low else np.zeros_like(values)


def shap_signals(phi):
    """Entropy of signed attribution mass; population variance of signed phi."""
    positive = np.maximum(phi, 0).sum(axis=1)
    negative = -np.minimum(phi, 0).sum(axis=1)
    total = positive + negative
    q = np.divide(positive, total, out=np.zeros_like(positive), where=total > 0)
    h = np.zeros_like(q)
    mixed = (q > 0) & (q < 1) & (total > 0)
    h[mixed] = -(q[mixed] * np.log2(q[mixed]) + (1-q[mixed]) * np.log2(1-q[mixed]))
    return h, np.var(phi, axis=1)


def self_audit_math():
    h, v = shap_signals(np.array([[0., 0.], [1., -1.], [100., -1.], [1., 1.]]))
    assert h[0] == 0 and h[1] == 1 and 0.079 < h[2] < 0.081 and h[3] == 0
    assert v[1] == 1 and v[0] == 0 and v[3] == 0
    assert np.array_equal(normalize(np.ones(4)), np.zeros(4))
    assert np.allclose(normalize(np.array([2., 3., 4.])), [0, .5, 1])
    assert all(abs(sum(w.values()) - 1) < 1e-12 for w in WEIGHTS.values())


def choose_threshold(y_val, p_val, target=0.95):
    positive = np.sort(p_val[y_val == 1])[::-1]
    assert len(positive) > 0
    threshold = float(positive[math.ceil(target * len(positive)) - 1])
    assert np.isfinite(threshold)
    assert np.mean(p_val[y_val == 1] >= threshold) >= target
    return threshold


def evaluate(y_true, probs, threshold):
    tn, fp, fn, tp = confusion_matrix(y_true, probs >= threshold, labels=[0, 1]).ravel()
    return dict(auc=float(roc_auc_score(y_true, probs)),
                ap=float(average_precision_score(y_true, probs)),
                fpr=float(fp/(fp+tn)), tpr=float(tp/(tp+fn)),
                tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp))


def get_scores(model, x_pool, method, rng):
    start = time.perf_counter()
    probs = model.predict(x_pool, num_threads=2)
    inference_seconds = time.perf_counter()-start
    shap_seconds = 0.0
    u = 1 - 2 * np.abs(probs - .5)
    signals = {'U': u}
    additivity_error = None
    if method in ['U+H', 'U+V', 'XAI_full']:
        shap_start = time.perf_counter()
        contrib = model.predict(x_pool, pred_contrib=True, num_threads=2)
        shap_seconds = time.perf_counter()-shap_start
        raw = model.predict(x_pool, raw_score=True, num_threads=2)
        additivity_error = float(np.max(np.abs(contrib.sum(axis=1) - raw)))
        assert contrib.shape == (len(x_pool), x_pool.shape[1]+1)
        assert np.isfinite(contrib).all() and additivity_error < 1e-8
        h, v = shap_signals(contrib[:, :-1])
        signals.update(H=h, V=v)
    scaled = {name: normalize(value) for name, value in signals.items()}
    scores = rng.random(len(x_pool)) if method == 'Random' else sum(
        weight * scaled[name] for name, weight in WEIGHTS[method].items())
    assert np.isfinite(scores).all()
    timing = dict(query_seconds=time.perf_counter()-start,
                  pool_inference_seconds=inference_seconds,
                  tree_shap_seconds=shap_seconds)
    return scores, signals, scaled, timing, additivity_error


def main():
    start_all = time.perf_counter()
    self_audit_math()
    (OUT/'models').mkdir(exist_ok=True)
    frame = pd.read_csv(DATA)
    assert 'label' in frame.columns and set(frame['label'].unique()) == {0, 1}
    feature_names = [c for c in frame.columns if c != 'label']
    x = frame[feature_names].to_numpy(dtype=np.float64)
    y = frame.label.to_numpy(dtype=np.int64)
    assert x.shape == (2000, 2381) and np.isfinite(x).all()
    # Exact feature duplicates would invalidate row-disjoint evaluation.
    assert not frame[feature_names].duplicated().any(), 'Duplicate vectors need grouped splitting.'
    dev, test = train_test_split(np.arange(len(y)), test_size=400,
                                random_state=42, stratify=y)
    train_pool, val = train_test_split(dev, test_size=400,
                                     random_state=42, stratify=y[dev])
    assert not (set(train_pool) & set(val) or set(train_pool) & set(test) or set(val) & set(test))
    assert len(train_pool) == 1200 and len(val) == 400 and len(test) == 400
    initial = {}
    remaining = {}
    for seed in SEEDS:
        pool, labeled = train_test_split(train_pool, test_size=200, random_state=seed,
                                         stratify=y[train_pool])
        initial[seed], remaining[seed] = labeled, pool
        assert len(pool) == 1000 and len(labeled) == 200
    code_sha = sha256(Path(__file__))
    repo_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                                          cwd='/workspace/thesis2026', text=True).strip()
    config = dict(dataset=str(DATA), data_sha256=sha256(DATA), runner_sha256=code_sha,
                  repo_commit=repo_commit, python=platform.python_version(),
                  versions=dict(lightgbm=lgb.__version__, numpy=np.__version__,
                                pandas=pd.__version__, sklearn=sklearn.__version__),
                  seeds=SEEDS, methods=METHODS, split_seed=42,
                  n_train_pool=1200, n_validation=400, n_test=400,
                  initial_labels=200, query_rounds=5, query_size=100,
                  num_boost_round=60, lightgbm_params=BASE_PARAMS,
                  weights=WEIGHTS, normalization='Per current unlabeled pool min-max; constant signal maps to zero',
                  U='1-2*abs(p-0.5)',
                  H='Base-2 entropy of positive and negative absolute TreeSHAP attribution masses; all zero -> 0',
                  V='Population variance of SIGNED TreeSHAP contributions across features; bias excluded',
                  shap='Native LightGBM pred_contrib=True, current model, raw-margin output; no external background',
                  oracle='Labels read only for selected indices; no pseudo-labels',
                  threshold='Highest finite validation positive score achieving validation TPR>=0.95; prediction >= threshold',
                  tie_break='Ascending global row index for equal query scores',
                  warnings=['Pilot on a 2,000-row available feature subset; upstream data provenance and pre-existing model overlap unverified.',
                            'Class 1 ransomware-specific semantics are unverified; use positive/negative terminology.',
                            'Test is a local row-disjoint holdout, not a verified original thesis benchmark.',
                            '5 seed repetitions share one test set, not five independent datasets.',
                            'Label count excludes validation labels and is not measured human annotation time.',
                            'High validation TPR does not guarantee high test TPR.'])
    dump_json(OUT/'config.json', config)
    dump_json(OUT/'splits.json', dict(train_pool=train_pool.tolist(), validation=val.tolist(),
                                    test=test.tolist(), initial_labeled={str(s): a.tolist() for s,a in initial.items()},
                                    initial_pool={str(s): a.tolist() for s,a in remaining.items()},
                                    class_counts={name: {str(k): int(np.sum(y[ix]==k)) for k in [0,1]}
                                                  for name,ix in [('train_pool',train_pool),('validation',val),('test',test)]}))
    rows = []
    queries = []
    maximum_additivity_error = 0.0
    pred_fields = ['seed','method','round','n_labeled','split','row_id','label','probability','threshold','prediction']
    with gzip.open(OUT/'predictions.csv.gz', 'wt', newline='') as pred_file:
        writer = csv.DictWriter(pred_file, fieldnames=pred_fields)
        writer.writeheader()
        for seed in SEEDS:
            for method in METHODS:
                labeled = initial[seed].copy()
                pool = remaining[seed].copy()
                rng = np.random.default_rng(seed)
                timing = dict(query_seconds=0.0,pool_inference_seconds=0.0,tree_shap_seconds=0.0)
                for rnd in range(6):
                    if rnd:
                        scores, signals, scaled, timing, error = get_scores(model, x[pool], method, rng)
                        if error is not None:
                            maximum_additivity_error = max(maximum_additivity_error, error)
                        order = np.lexsort((pool, -scores))
                        positions = order[:100]
                        chosen = pool[positions]
                        assert len(set(chosen)) == 100 and not set(chosen) & set(labeled)
                        assert not set(chosen) & (set(val) | set(test))
                        for rank, (position, ix) in enumerate(zip(positions,chosen), 1):
                            queries.append(dict(seed=seed, method=method, round=rnd, row_id=int(ix),
                                                rank=rank, score=float(scores[position]),
                                                label=int(y[ix]),
                                                **{f'{name}_raw': float(a[position]) for name,a in signals.items()},
                                                **{f'{name}_normalized': float(a[position]) for name,a in scaled.items()}))
                        labeled = np.concatenate([labeled,chosen])
                        keep = np.ones(len(pool), dtype=bool)
                        keep[positions] = False
                        pool = pool[keep]
                    assert len(labeled) == 200 + 100*rnd and len(set(labeled)) == len(labeled)
                    assert len(labeled) + len(pool) == 1200
                    assert not set(labeled) & (set(val) | set(test))
                    params = dict(BASE_PARAMS, seed=seed, data_random_seed=seed, feature_fraction_seed=seed)
                    t0 = time.perf_counter()
                    model = lgb.train(params, lgb.Dataset(x[labeled], label=y[labeled],
                                                        feature_name=feature_names), num_boost_round=60)
                    train_seconds = time.perf_counter()-t0
                    model.save_model(str(OUT/'models'/f'seed{seed}_{method.replace("+","_")}_round{rnd}.txt'))
                    t0 = time.perf_counter()
                    p_val = model.predict(x[val], num_threads=2)
                    threshold = choose_threshold(y[val],p_val)
                    p_test = model.predict(x[test], num_threads=2)
                    validation_metrics = evaluate(y[val],p_val,threshold)
                    test_metrics = evaluate(y[test],p_test,threshold)
                    evaluation_seconds = time.perf_counter()-t0
                    rows.append(dict(seed=seed, method=method, round=rnd, n_labeled=len(labeled),
                                     n_added=100*rnd, threshold=threshold, **timing,
                                     train_seconds=train_seconds, evaluation_seconds=evaluation_seconds,
                                     **{f'val_{k}':v for k,v in validation_metrics.items()},
                                     **{f'test_{k}':v for k,v in test_metrics.items()}))
                    for split,indices,probs in [('validation',val,p_val),('test',test,p_test)]:
                        for ix,prob in zip(indices,probs):
                            writer.writerow(dict(seed=seed,method=method,round=rnd,n_labeled=len(labeled),
                                                 split=split,row_id=int(ix),label=int(y[ix]),probability=float(prob),
                                                 threshold=threshold,prediction=int(prob>=threshold)))
                    pd.DataFrame(rows).to_csv(OUT/'metrics.csv',index=False)
                print(json.dumps(dict(seed=seed,method=method,final={k:rows[-1][k] for k in ['test_auc','test_ap','test_fpr','test_tpr']},
                                      elapsed_seconds=round(time.perf_counter()-start_all,2))), flush=True)
    metrics = pd.DataFrame(rows)
    pd.DataFrame(queries).to_csv(OUT/'queries.csv',index=False)
    metrics.to_csv(OUT/'metrics.csv',index=False)
    final = metrics[metrics['round']==5]
    summary = final.groupby('method')[['test_auc','test_ap','test_fpr','test_tpr']].agg(['mean','std'])
    summary.to_csv(OUT/'final_summary.csv')
    paired = []
    for method in ['Uncertainty','U+H','U+V','XAI_full']:
        for baseline in ['Random','Uncertainty']:
            if method == baseline:
                continue
            a = final[final.method==method].set_index('seed')
            b = final[final.method==baseline].set_index('seed')
            for metric in ['test_auc','test_ap','test_fpr','test_tpr']:
                diff = a[metric]-b[metric]
                paired.append(dict(method=method,baseline=baseline,metric=metric,
                                   mean_difference=float(diff.mean()),sd_difference=float(diff.std(ddof=1)),
                                   **{f'seed_{s}':float(diff[s]) for s in SEEDS}))
    pd.DataFrame(paired).to_csv(OUT/'paired_differences.csv',index=False)
    curves = []
    for (seed,method),g in metrics.groupby(['seed','method']):
        g = g.sort_values('n_labeled')
        curves.append(dict(seed=int(seed),method=method,
                           normalized_test_auc_aulc=float(np.trapezoid(g.test_auc,g.n_labeled)/500),
                           normalized_test_ap_aulc=float(np.trapezoid(g.test_ap,g.n_labeled)/500),
                           query_seconds=float(g.query_seconds.sum()), train_seconds=float(g.train_seconds.sum())))
    pd.DataFrame(curves).to_csv(OUT/'learning_curve_summary.csv',index=False)
    runtime = time.perf_counter()-start_all
    dump_json(OUT/'audit.json',dict(status='passed',elapsed_seconds=runtime,
                                  checkpoints=len(rows),query_records=len(queries),prediction_records=len(rows)*800,
                                  exact_feature_duplicates=0,max_tree_shap_additivity_error=maximum_additivity_error,
                                  checks=['Disjoint train/pool/validation/test row IDs',
                                          'Every selected row unique and only from current pool',
                                          'No labels of unselected pool rows read by acquisition',
                                          'Current model rebuilt from scratch on cumulative labeled data each round',
                                          'No test-based threshold, model selection, early stopping, or acquisition',
                                          'TreeSHAP sums checked against raw margins on each acquisition batch',
                                          'Entropy mass and signed variance mathematical checks passed',
                                          'Identical initial models across methods within each seed required by post-audit']))
    initial_metrics = metrics[metrics['round']==0]
    for seed,g in initial_metrics.groupby('seed'):
        for name in ['test_auc','test_ap','test_fpr','test_tpr','threshold']:
            assert g[name].nunique() == 1, (seed,name,g[name].tolist())
    dump_json(OUT/'artifact_sha256.json',{str(p.relative_to(OUT)):sha256(p) for p in sorted(OUT.rglob('*'))
                                        if p.is_file() and p.name not in ['artifact_sha256.json','run.log']})
    print('COMPLETE',runtime,flush=True)
    print(summary.to_string(),flush=True)


if __name__ == '__main__':
    main()
