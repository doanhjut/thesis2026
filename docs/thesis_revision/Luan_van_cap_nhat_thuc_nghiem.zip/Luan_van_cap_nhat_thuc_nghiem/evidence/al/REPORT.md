# Pilot AL trên đặc trưng thật — kết quả kiểm chứng

Đây là pilot trên CSV có sẵn, chưa phải benchmark held-out gốc đã xác minh của luận văn. Nguồn dữ liệu upstream và ý nghĩa nhãn 1 riêng cho ransomware chưa được xác minh.

Train/pool 1.200; validation 400; test 400 (300 âm, 100 dương). Khởi tạo 200 nhãn, truy vấn thêm 5×100; năm seed ghép cặp. Mỗi checkpoint huấn luyện LightGBM mới từ toàn bộ nhãn đã có. Ngưỡng chọn trên validation để TPR ≥95%; TPR test có thể khác.

| Phương pháp | ROC-AUC | AP | FPR (%) | TPR (%) |
|---|---:|---:|---:|---:|
| Random | 0.9634 ± 0.0063 | 0.9194 ± 0.0115 | 21.73 ± 4.59 | 93.80 ± 2.28 |
| Uncertainty | 0.9691 ± 0.0046 | 0.9363 ± 0.0076 | 19.87 ± 4.65 | 95.60 ± 1.14 |
| U+H | 0.9676 ± 0.0031 | 0.9371 ± 0.0015 | 17.20 ± 5.15 | 93.00 ± 2.35 |
| U+V | 0.9692 ± 0.0062 | 0.9392 ± 0.0073 | 28.33 ± 7.23 | 96.40 ± 3.05 |
| XAI_full | 0.9749 ± 0.0040 | 0.9442 ± 0.0057 | 17.53 ± 4.85 | 95.40 ± 1.52 |

Các giá trị ± là độ lệch chuẩn mẫu giữa năm seed chung một test, không phải khoảng tin cậy tổng thể.

## Đối chiếu ghép cặp XAI đầy đủ − Uncertainty

- test_auc: +0.005787 ± 0.003904; năm chênh lệch = +0.003967, +0.001000, +0.011633, +0.005800, +0.006533.
- test_ap: +0.007915 ± 0.004659; năm chênh lệch = +0.007310, +0.001323, +0.013368, +0.006363, +0.011210.
- test_fpr: -0.023333 ± 0.066165; năm chênh lệch = +0.016667, +0.043333, -0.076667, +0.010000, -0.110000.
- test_tpr: -0.002000 ± 0.019235; năm chênh lệch = +0.000000, +0.020000, +0.010000, -0.010000, -0.030000.

## Thời gian và phạm vi

Tổng runner: 49.64 giây. Chỉ đo chi phí thí nghiệm trên máy hiện tại; không phải độ trễ SOC/endpoint.

query_seconds measures acquisition-score computation including pool prediction, TreeSHAP, raw-score additivity audit and normalization; excludes lexsort, annotation, storage and training. tree_shap_seconds is the native pred_contrib call only. Not endpoint or SOC latency.

Không sử dụng test để chọn truy vấn, chọn ngưỡng, dừng sớm hoặc chỉnh siêu tham số. Không fallback sang SHAP/mô hình/chỉ số mô phỏng. Chưa đo tiết kiệm thời gian gán nhãn chuyên gia.

Kiểm tra hậu nghiệm: số artifact đúng; query không trùng; train/pool/val/test tách row; ROC-AUC và AP tính lại từ predictions khớp; initial metrics giống nhau giữa methods; hash runner khớp.
