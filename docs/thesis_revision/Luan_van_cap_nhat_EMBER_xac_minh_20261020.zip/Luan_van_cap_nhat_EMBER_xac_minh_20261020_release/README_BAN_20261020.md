# Bản luận văn cập nhật kết quả xác nhận EMBER

Bản này được biên dịch ngày 20/10/2026 từ kết quả xác nhận trong `results/confirmatory_20261019_ember_identity`.

Các thay đổi chính:

- thay provenance chưa xác minh bằng manifest EMBER đã đối chiếu theo nhãn, SHA-256, chỉ số nguồn và hash vector;
- thay kết quả Active Learning pilot một split bằng 5 outer folds × 5 seed, ngân sách 200–1.200 nhãn;
- báo ROC/AP-AULC, ngân sách đạt target, vùng FPR thấp và overhead;
- thay Fidelity một mô hình bằng 25 mô hình, mean/median baseline, random control và stability;
- cập nhật minh họa TreeSHAP bằng mẫu có định danh SHA-256;
- không tổng hợp OFS khi chưa có chuẩn hóa và trọng số đã kiểm định;
- giữ PID ở mức thiết kế và giao thức vì chưa có behavior trace ghép cặp.

Kiểm tra biên dịch:

- XeLaTeX/latexmk hoàn tất, không có reference hoặc citation chưa giải quyết;
- PDF gồm 71 trang A4;
- các trang Chương 4 và Kết luận đã được kiểm tra trực quan.

Các tệp ghi chú của bản trước được giữ ngoài gói phát hành này để tránh lẫn số liệu pilot cũ.
